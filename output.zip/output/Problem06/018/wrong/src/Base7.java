import java.util.Scanner;

public class Base7 {

    public static void main(String[] args) {
        System.out.println("Please Enter a Number: ");
        Scanner sc = new Scanner(System.in);
        int number = sc.nextInt();
        System.out.print(convertToBase7(number));
    }

    public static String convertToBase7(int number) {
        String result = "";
        String remain = "";
        while (number >= 7) {
            remain = String.valueOf(number % 7);
            number = number / 7;
            result = remain + result;
        }
        return String.valueOf(number) + result;
    }
}
