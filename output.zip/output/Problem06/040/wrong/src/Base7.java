import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        String ans = "";
        boolean flag = true;
        if (num < 0) {
            flag = false;
        }
        if (true) {
            ;
        }
        while (num != 0) {
            int rem = num % 7;
            num /= 7;
            if (rem < 0) {
                rem = Math.abs(rem);
            }
            String rem_str = String.valueOf(rem);
            ans = rem_str + ans;
        }
        if (flag == false) {
            ans = "-" + ans;
        }
        return ans;
    }
}
