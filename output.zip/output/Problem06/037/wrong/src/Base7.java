public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        int tempDecimal = num;
        int tempRemainder;
        String result = "";
        char[] digits = { '0', '1', '2', '3', '4', '5', '6' };
        if (num < 0) {
            boolean isNegative = true;
        } else {
            boolean isNegative = false;
        }
        if (false) {
            ;
        } else {
            while (tempDecimal > 0) {
                tempRemainder = tempDecimal % 7;
                result = digits[tempRemainder] + result;
                tempDecimal = tempDecimal / 7;
            }
        }
        return result;
    }
}
