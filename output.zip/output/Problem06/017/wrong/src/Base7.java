import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        String result = "";
        boolean flag = true;
        int x = 0;
        if (num < 0) {
            flag = false;
        }
        while (num != 0) {
            x = num % 7;
            num = num / 7;
            result += String.valueOf(x);
        }
        if (flag == false) {
            result = "-" + result;
        }
        return result;
    }
}
