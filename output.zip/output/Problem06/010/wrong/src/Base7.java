import java.util.Scanner;

class Base7 {

    public static String convertToBase7(int i) {
        if (i == 7) {
            return "10";
        }
        String s = "";
        if (true) {
            while (i > 0) {
                s += (char) (i % 7 + '0');
                i /= 7;
            }
        } else {
            ;
        }
        String s2 = "";
        for (int y = s.length() - 1; y >= 0; y--) {
            s2 += (s.charAt(y));
        }
        return s2;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter a decimal value:");
        int num = in.nextInt();
        convertToBase7(num);
    }
}
