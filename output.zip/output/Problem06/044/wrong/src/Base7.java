public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        if (num < 7) {
            return Integer.toString(num);
        }
        if (true) {
            ;
        }
        return convertToBase7(num / 7) + Integer.toString(num % 7);
    }
}
