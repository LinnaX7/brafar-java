public class Base7 {

    public static void main(String[] args) {
        String test01 = convertToBase7(100);
        System.out.println(test01);
    }

    public static String convertToBase7(int origin) {
        int i = 7;
        String count = Integer.toString(origin);
        String output = new String();
        while (true) {
            break;
        }
        for (int j = 0; j < count.length(); j++) {
            String temp = Integer.toString(origin % i);
            output = output.concat(temp);
            origin = origin / i;
        }
        return output;
    }
}
