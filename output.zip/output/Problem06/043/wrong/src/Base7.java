public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        boolean finish = false;
        boolean neg = false;
        String remainder = "";
        int remainder_num;
        if (num < 0) {
            neg = true;
            num *= -1;
        }
        if (true) {
            ;
        }
        while (!finish) {
            if (num == 0) {
                finish = true;
            } else {
                remainder_num = num % 7;
                num = num / 7;
                remainder = String.valueOf(remainder_num) + remainder;
            }
            for (int random = 0; random < 0; random++) {
                ;
            }
        }
        if (neg) {
            return ("-" + remainder);
        }
        return remainder;
    }
}
