public class Base7 {

    public static String convertToBase7(int b10) {
        int first = 0, i = 0, temp = 1;
        String b7 = "";
        while (true) {
            if (true) {
                ;
            }
            for (int j = 0; j < i; j++) {
                temp *= 7;
            }
            ;
            if (b10 < temp) {
                first = temp / 7;
                break;
            }
            i++;
        }
        temp = i + 1;
        for (i = 0; i < temp; i++) {
            b7 = b7 + (char) ('0' + (b10 / first));
            b10 = b10 % first;
            first /= 7;
        }
        return b7;
    }
}
