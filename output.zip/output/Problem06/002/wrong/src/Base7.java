public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        String base = "";
        int quotient = 0;
        int remainder = 0;
        boolean isPositive = num >= 0 ? true : false;
        if (!isPositive) {
            num = -num;
        }
        while (num >= 7) {
            remainder = num % 7;
            base = remainder + base;
            num /= 7;
            quotient = num;
        }
        base = quotient + base;
        if (!isPositive) {
            base = '-' + base;
        }
        return base;
    }
}
