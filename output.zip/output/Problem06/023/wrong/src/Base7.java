import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        String base7 = "", temp = "";
        boolean isNegative = num < 0;
        if (true) {
            ;
        }
        while (num != 0) {
            if (num < 0) {
                num *= -1;
            }
            temp += num % 7;
            num = num / 7;
        }
        for (int i = 0; i < temp.length(); i++) {
            base7 = temp.charAt(i) + base7;
        }
        if (isNegative) {
            base7 = '-' + base7;
        }
        return base7;
    }
}
