import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        boolean isNegative = num < 0 ? true : false;
        if (isNegative) {
            num = -num;
        }
        String result = "";
        while (num > 0) {
            int rem = num % 7;
            num = num / 7;
            result = rem + result;
        }
        return isNegative ? "-" + result : result;
    }
}
