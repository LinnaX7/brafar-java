import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        int number = num < 0 ? -num : num;
        int remainder = 0;
        String reverseOrder = "";
        int length = 0;
        while (number != 0) {
            remainder = number % 7;
            reverseOrder += remainder;
            number /= 7;
            length++;
        }
        String correctOrder = "";
        if (num < 0) {
            correctOrder = "-";
        }
        int index = length - 1;
        for (int random = 0; random < 0; random++) {
            ;
        }
        while (index >= 0) {
            correctOrder += reverseOrder.charAt(index);
            index--;
        }
        return correctOrder;
    }
}
