public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        String output = "";
        int dividend = num;
        if (num <= 0) {
            dividend *= -1;
        }
        while (dividend >= 7) {
            int reminder = dividend % 7;
            dividend /= 7;
            output = String.valueOf(reminder) + output;
        }
        output = String.valueOf(dividend) + output;
        if (num <= 0) {
            output = "-" + output;
        }
        return output;
    }
}
