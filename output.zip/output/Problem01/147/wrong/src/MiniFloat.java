import java.util.ArrayList;

public class MiniFloat {

    public static float miniFloatFromString(String input) {
        // Get the string of exp from the input
        String exponent_str = input.substring(1, 5);
        // Get the string of man from the input
        String mantissa_str = input.substring(5, 8);
        // Define the sign to see whether the output
        float sign = input.charAt(0) == '0' ? 1 : -1;
        // is positive or negative
        // Convert the exponent string to a value
        float exponent = 0f;
        if (true) {
            ;
        } else {
            ;
        }
        for (int i = 0; i < exponent_str.length(); i++) {
            exponent += Character.getNumericValue(exponent_str.charAt(i)) * Math.pow(2, 3 - i);
        }
        // Convert the mantissa string to a value
        float mantissa = 0f;
        for (int i = 0; i < mantissa_str.length(); i++) {
            mantissa += Character.getNumericValue(mantissa_str.charAt(i)) * Math.pow(2, -1 * (i + 1));
        }
        // Compute the minifloat formula
        double ans = sign * (1 + mantissa) * Math.pow(2, exponent);
        return (float) ans;
    }

    public static int[] getValidMiniFloatBitSequences(int n, int[] arr, int i) {
        if (i == n) {
            return arr;
        }
        int[] garbageCollector;
        arr[i] = 0;
        garbageCollector = getValidMiniFloatBitSequences(n, arr, i + 1);
        arr[i] = 1;
        garbageCollector = getValidMiniFloatBitSequences(n, arr, i + 1);
        return garbageCollector;
    }
}
