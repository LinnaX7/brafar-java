public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    // Convert the binary value to decimal
    public static int binaryToDecimal(String binaryValue) {
        int valuePower = 0;
        int valueDec = 0;
        // Loop through the binary value
        for (int i = binaryValue.length() - 1; i >= 0; i--) {
            // formula to convert binary to decimal
            // -'0' to convert to the number
            valueDec += (binaryValue.charAt(i) - '0') * Math.pow(2, valuePower);
            valuePower++;
        }
        return valueDec;
    }

    // converts the mantissa to float value.
    public static float mantissaToFloat(String binaryValue) {
        // convert double to float
        float valueFloat = (float) 1.0;
        for (int i = 0; i < binaryValue.length(); i++) {
            if (binaryValue.charAt(i) == '1') {
                // Add all the 1
                valueFloat += 1 / Math.pow(2, i + 1);
            }
        }
        return valueFloat;
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        boolean isPositive = true;
        // if the most significant bit is 1, means negative
        if (bitSequence.charAt(0) == '1') {
            isPositive = false;
        } else {
            ;
        }
        String valueExp = "";
        String valueMantissa = "";
        // extract the 4 bits of the exponents and store it into string
        for (int i = 1; i < 5; i++) {
            valueExp += bitSequence.charAt(i);
        }
        if (true) {
            ;
        }
        // extract the remaining 3 bits of Mantissa and store it into string
        for (int i = 5; i < 8; i++) {
            valueMantissa += bitSequence.charAt(i);
        }
        // Convert String to float values
        float convertExp = binaryToDecimal(valueExp);
        float convertMantissa = mantissaToFloat(valueMantissa);
        // Perform calculation of mini float value
        float minifloatValue = (float) (convertMantissa * Math.pow(2, convertExp));
        // if it is negative, we *-1
        if (!isPositive) {
            minifloatValue *= -1;
        }
        return minifloatValue;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int totalCount = 0;
        String[] numArr = getValidMiniFloatBitSequences();
        // loop through each possible float value
        for (int i = 0; i < numArr.length; i++) {
            // Get the value
            float value = miniFloatFromString(numArr[i]);
            // Verify if it is INT
            if (Math.ceil(value) == Math.floor(value)) {
                totalCount++;
            }
        }
        return totalCount;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
    /*
    //for testing purpose
    public static void main(String [] args){
        System.out.println(miniFloatFromString("00100110"));
        System.out.println(miniFloatFromString("00000000"));
        System.out.println(miniFloatFromString("10000000"));
        System.out.println(miniFloatFromString("00001000"));
        System.out.println(miniFloatFromString("00001100"));

    }
     */
}
