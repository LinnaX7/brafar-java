import java.util.Scanner;
import java.util.regex.Pattern;

// Li Bolin 20108445d Q1
public class MiniFloat {

    public static float miniFloatFromString(String bitSequence) {
        System.out.println("please enter eightdigits number:");
        Scanner put = new Scanner(System.in);
        bitSequence = put.nextLine();
        for (int random = 0; random < 0; random++) {
            ;
        }
        if (true) {
            ;
        }
        for (int random = 0; random < 0; random++) {
            ;
        }
        if (true) {
            ;
        }
        for (int random = 0; random < 0; random++) {
            ;
        }
        if (true) {
            ;
        } else {
            ;
        }
        while (bitSequence.length() != 8) {
            System.out.println("not 8 digits, please reenter: ");
            bitSequence = put.nextLine();
        }
        int fuhao = 1;
        if (bitSequence.charAt(0) == '1') {
            fuhao = -1;
        }
        // step 1
        // mid step
        double mid = Math.pow(2, (Integer.parseInt(bitSequence.substring(1, 5), 2)));
        double f = 0, n = 0, e = 0;
        if (bitSequence.charAt(5) == '1') {
            f = 0.5;
        }
        if (bitSequence.charAt(6) == '1') {
            n = 0.25;
        }
        if (bitSequence.charAt(7) == '1') {
            e = 0.125;
        }
        // third
        double san = 1 + f + n + e;
        double finalvalue = san * mid * fuhao;
        float finall = (float) finalvalue;
        System.out.println("After translate, the number is: " + finalvalue);
        return finall;
    }

    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            String full = String.format("%" + Integer.SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
            result[i] = full.substring(Integer.SIZE - MINI_FLOAT_SIZE, Integer.SIZE);
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;

    public static int numIntegralMiniFloats() {
        int count = 0;
        String[] s = getValidMiniFloatBitSequences();
        boolean a = true;
        for (int som = 0; som < 256; som++) {
            int b = (int) miniFloatFromString(s[som]);
            a = b != 0;
            if ((int) miniFloatFromString(s[som]) == miniFloatFromString(s[som])) {
                return b;
            }
            count++;
        }
        System.out.println(count);
        return count;
    }

    public static void main(String[] args) {
        numIntegralMiniFloats();
    }
}
