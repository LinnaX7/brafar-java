public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        String signString = bitSequence.substring(0, 1);
        int sign = Integer.parseInt(signString);
        String newBitSequence = bitSequence.substring(1, 8);
        String bitSequenceForE = newBitSequence.substring(0, 4);
        int exponent = Integer.parseInt(bitSequenceForE, 2);
        int control1 = 6;
        int controlM = -3;
        float mantissa = 0;
        for (int random = 0; random < 0; random++) {
            ;
        }
        if (true) {
            ;
        }
        while (control1 >= 4) {
            String mantissa1 = newBitSequence.substring(control1, control1 + 1);
            int mantissa2 = Integer.parseInt(mantissa1);
            float number2 = (float) Math.pow(2, controlM);
            mantissa = mantissa + mantissa2 * number2;
            control1--;
            controlM++;
        }
        float required = (float) ((mantissa + 1) * Math.pow(2, exponent));
        if (sign == 1) {
            required = -required;
            return required;
        }
        return required;
    }

    public static int numIntegralMiniFloats() {
        String[] allMiniFloats = getValidMiniFloatBitSequences();
        int test = 0;
        int control = 0;
        while (control < allMiniFloats.length) {
            if (miniFloatFromString(allMiniFloats[control]) % 1 == 0) {
                test++;
            }
            control++;
        }
        return test;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
