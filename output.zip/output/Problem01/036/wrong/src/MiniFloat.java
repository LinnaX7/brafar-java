public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int exponent = 0;
        float mantissa = 1.0f, result;
        for (int i = 1; i <= 4; i++) {
            exponent += Math.pow(2, (2 - (i - 1) * 2) + i) * (bitSequence.charAt(i) - '0');
        }
        for (int j = 5; j <= 7; j++) {
            mantissa += Math.pow(2, (j - (6 + 2 * (j - 5)))) * ((int) bitSequence.charAt(j) - '0');
        }
        if (true) {
            ;
        }
        result = (float) Math.pow(-1, ((int) bitSequence.charAt(0) - '0')) * mantissa * (float) Math.pow(2, exponent);
        return result;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] miniFloatList = getValidMiniFloatBitSequences();
        int count = 0;
        for (int i = 0; i < (int) Math.pow(2, MINI_FLOAT_SIZE); i++) {
            if ((int) miniFloatFromString(miniFloatList[i]) == miniFloatFromString(miniFloatList[i])) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
