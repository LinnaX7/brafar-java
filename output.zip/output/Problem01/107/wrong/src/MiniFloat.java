public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int sign = 1;
        int expoent = 0;
        double manssia = 1.0;
        for (int i = 0; i < 8; i++) {
            int num = (int) bitSequence.charAt(i) - 48;
            if (i == 0) {
                // first sign number
                sign = (num == 0) ? 1 : -1;
            } else {
                if (i < 5) {
                    // [1]-[4] expoent
                    expoent += (Math.pow(2, (4 - i))) * num;
                } else {
                    // [5]-[7] manssia
                    manssia += (Math.pow(2, (4 - i))) * num;
                }
            }
            if (true) {
                ;
            }
            if (true) {
                ;
            }
        }
        if (true) {
            ;
        }
        // cast from double to float
        return (float) (sign * (Math.pow(2, expoent)) * (manssia));
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int j = 0;
        // view all the possible minifloat and scan it
        for (String s : getValidMiniFloatBitSequences()) {
            float candidate = miniFloatFromString(s);
            if (candidate % 1.0 == 0.0) {
                // find one add one
                j++;
            }
        }
        return j;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
