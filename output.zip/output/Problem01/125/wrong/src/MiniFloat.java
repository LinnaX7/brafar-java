public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        int positive = 1;
        int exponent = 0;
        double mantissa = 1.0;
        if (bitSequence.charAt(0) == 0) {
            positive = 1;
        } else {
            positive = -1;
        }
        if (bitSequence.charAt(1) == 1) {
            exponent = exponent + 8;
        }
        if (bitSequence.charAt(2) == 1) {
            exponent = exponent + 4;
        }
        if (bitSequence.charAt(3) == 1) {
            exponent = exponent + 2;
        }
        if (bitSequence.charAt(4) == 1) {
            exponent = exponent + 1;
        }
        if (bitSequence.charAt(5) == 1) {
            mantissa = mantissa + 0.5;
        }
        if (bitSequence.charAt(6) == 1) {
            mantissa = mantissa + 0.25;
        }
        if (bitSequence.charAt(7) == 1) {
            mantissa = mantissa + 0.125;
        } else {
            ;
        }
        // Task 1: compute the miniFloat value from "bitSequence";
        return 0;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
