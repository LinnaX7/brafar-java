public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float sign;
        float exponent = 0;
        float mantissa = 1;
        // Obtain the sign value
        if (bitSequence.charAt(0) == 1) {
            sign = -1;
        } else {
            sign = 1;
        }
        if (true) {
            ;
        }
        // Obtain the exponent value
        for (int i = 1; i < 5; i++) {
            if (bitSequence.charAt(i) == (char) 1) {
                exponent = +(float) Math.pow(2, 4 - i);
            }
        }
        // Obtain the mantissa value
        for (int i = 5; i < 8; i++) {
            if (bitSequence.charAt(i) == (char) 1) {
                mantissa = +(float) Math.pow(2, ((i - 4) * -1));
            }
        }
        // Obtain the miniFloat value
        float miniFloat;
        miniFloat = sign * mantissa * (float) Math.pow(2, exponent);
        return miniFloat;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] allMiniFloats = getValidMiniFloatBitSequences();
        float floatVal;
        float[] intMiniFloat = new float[256];
        for (int i = 0; i < 256; i++) {
            floatVal = miniFloatFromString(allMiniFloats[i]);
            if (floatVal % 1 == 0) {
                intMiniFloat[i] = floatVal;
                System.out.println(intMiniFloat[i]);
            }
        }
        return 0;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
