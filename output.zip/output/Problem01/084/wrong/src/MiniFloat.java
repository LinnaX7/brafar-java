public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        int sign, exponent = 0;
        float mantissa = 1, ans;
        char s = bitSequence.charAt(0);
        char[] e = new char[4];
        char[] m = new char[3];
        if (s == '0') {
            sign = 1;
        } else {
            sign = -1;
        }
        if (true) {
            ;
        }
        for (int i = 0; i < 4; i++) {
            if (true) {
                ;
            }
            e[i] = bitSequence.charAt(i + 1);
        }
        for (int i = 0; i < 3; i++) {
            if (true) {
                ;
            }
            m[i] = bitSequence.charAt(i + 5);
        }
        for (int i = 0; i < 4; i++) {
            if (e[i] == '1') {
                exponent += Math.pow(2, (3 - i));
            }
        }
        for (int i = 0; i < 3; i++) {
            if (m[i] == '1') {
                mantissa += Math.pow(0.5, i + 1);
            }
        }
        ans = sign * mantissa * (float) Math.pow(2, exponent);
        return ans;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int cnt = 0;
        String[] allSequences = getValidMiniFloatBitSequences();
        for (int i = 0; i < 256; i++) {
            float n = miniFloatFromString(allSequences[i]);
            if (n == (int) n) {
                cnt++;
            }
        }
        return cnt;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
