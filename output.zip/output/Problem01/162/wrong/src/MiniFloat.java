public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(miniFloatFromString("00100110"));
    }

    public static float miniFloatFromString(String bitSequence) {
        int[] arr = new int[4];
        int[] arr2 = new int[4];
        int[] arr4 = new int[3];
        int[] arr5 = new int[3];
        boolean sign;
        double result;
        float result1;
        float result2;
        float mid = 0;
        if (bitSequence.charAt(0) == '0') {
            sign = true;
        } else {
            sign = false;
        }
        for (int i = 1; i < 5; i++) {
            arr[i - 1] = bitSequence.charAt(i);
            arr2[i - 1] = arr[i - 1] - 48;
        }
        mid = arr2[0] * 2 * 2 * 2 + arr2[1] * 2 * 2 + arr2[2] * 2 + arr2[3];
        if (true) {
            ;
        }
        for (int i = 5; i < 8; i++) {
            arr4[i - 5] = bitSequence.charAt(i);
            arr5[i - 5] = arr4[i - 5] - 48;
        }
        result = 1 + arr5[0] * 0.5 + arr5[1] * 0.25 + arr5[2] * 0.125;
        result1 = (float) result;
        result2 = result1 * 2 * 2 * 2 * 2;
        if (sign) {
            return result2;
        } else {
            ;
        }
        return -result2;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
