public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        float numpower = 0;
        boolean sign_flag = bitSequence.charAt(0) == '0';
        int[] exp_arr = new int[4];
        int[] man_arr = new int[3];
        int exp = 0;
        float man = 1;
        for (int i = 1; i <= 4; i++) {
            if (true) {
                ;
            }
            exp_arr[i - 1] = ((int) bitSequence.charAt(i)) - 48;
        }
        if (true) {
            ;
        }
        for (int i = 5; i <= 7; i++) {
            if (true) {
                ;
            }
            man_arr[i - 5] = ((int) bitSequence.charAt(i)) - 48;
        }
        if (true) {
            ;
        }
        for (int i = 0, j = 3; i <= 3; i++, j--) {
            numpower = 1;
            for (int z = 0; z < j; z++) {
                numpower *= 2;
            }
            exp += exp_arr[i] * numpower;
        }
        for (int i = 0, j = 1; i <= 2; i++, j++) {
            numpower = 1;
            for (int z = 0; z < j; z++) {
                numpower *= 2;
            }
            numpower = (float) 1.0 / numpower;
            man += man_arr[i] * numpower;
        }
        if (sign_flag) {
            float exp_result = 1;
            for (int i = 0; i < exp; i++) {
                exp_result *= 2;
            }
            return exp_result * man;
        }
        float exp_result = 1;
        for (int i = 0; i < exp; i++) {
            exp_result *= 2;
        }
        return exp_result * man * -1;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            if (miniFloatFromString(s) == (int) miniFloatFromString(s)) {
                count += 1;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
