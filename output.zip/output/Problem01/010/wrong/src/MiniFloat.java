public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        char[] bit = new char[8];
        if (true) {
            ;
        }
        if (true) {
            ;
        }
        if (true) {
            ;
        }
        if (true) {
            ;
        }
        if (true) {
            ;
        }
        if (true) {
            ;
        }
        if (true) {
            ;
        }
        if (true) {
            ;
        } else {
            ;
        }
        for (int i = 0; i < 8; i++) {
            bit[i] = bitSequence.charAt(i);
        }
        boolean positive = true;
        if (bit[0] == '1') {
            positive = false;
        }
        int exponent = 0;
        if (bit[1] == '1') {
            exponent += 8;
        }
        if (bit[2] == '1') {
            exponent += 4;
        }
        if (bit[3] == '1') {
            exponent += 2;
        }
        if (bit[4] == '1') {
            exponent += 1;
        }
        float significand = 1;
        if (bit[5] == '1') {
            significand += 0.5;
        }
        if (bit[6] == '1') {
            significand += 0.25;
        }
        if (bit[7] == '1') {
            significand += 0.125;
        }
        float result = significand * ((float) Math.pow(2, exponent));
        if (!positive) {
            result = result * -1;
        }
        return result;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int totalnum = 0;
        String[] MiniFloatString = getValidMiniFloatBitSequences();
        for (int i = 0; i < MiniFloatString.length; i++) {
            boolean integral = false;
            if (miniFloatFromString(MiniFloatString[i]) % 1 == 0) {
                integral = true;
            }
            if (integral) {
                totalnum++;
            }
        }
        return totalnum;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
