public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        if (Integer.parseInt(String.valueOf(bitSequence.charAt(0))) == 0) {
            double exponent = Integer.parseInt(String.valueOf(bitSequence.charAt(1))) * Math.pow(2, 3) + Integer.parseInt(String.valueOf(bitSequence.charAt(2))) * Math.pow(2, 2) + Integer.parseInt(String.valueOf(bitSequence.charAt(3))) * Math.pow(2, 1) + Integer.parseInt(String.valueOf(bitSequence.charAt(4))) * Math.pow(2, 0);
            double significand = Integer.parseInt(String.valueOf(bitSequence.charAt(5))) * Math.pow(2, -1) + Integer.parseInt(String.valueOf(bitSequence.charAt(6))) * Math.pow(2, -2) + Integer.parseInt(String.valueOf(bitSequence.charAt(7))) * Math.pow(2, -3) + 1;
            return new Float(Math.pow(2, exponent) * significand);
        } else {
            ;
        }
        double exponent = Integer.parseInt(String.valueOf(bitSequence.charAt(1))) * Math.pow(2, 3) + Integer.parseInt(String.valueOf(bitSequence.charAt(2))) * Math.pow(2, 2) + Integer.parseInt(String.valueOf(bitSequence.charAt(3))) * Math.pow(2, 1) + Integer.parseInt(String.valueOf(bitSequence.charAt(4))) * Math.pow(2, 0);
        double significand = Integer.parseInt(String.valueOf(bitSequence.charAt(5))) * Math.pow(2, -1) + Integer.parseInt(String.valueOf(bitSequence.charAt(6))) * Math.pow(2, -2) + Integer.parseInt(String.valueOf(bitSequence.charAt(7))) * Math.pow(2, -3) + 1;
        return new Float(Math.pow(2, exponent) * significand * (-1));
        // Task 1: compute the miniFloat value from "bitSequence";
    }

    public static int numIntegralMiniFloats() {
        int number = 0;
        for (int a = 0; a <= 1; a++) {
            for (int b = 0; b <= 1; b++) {
                for (int c = 0; c <= 1; c++) {
                    for (int d = 0; d <= 1; d++) {
                        for (int e = 0; e <= 1; e++) {
                            for (int f = 0; f <= 1; f++) {
                                for (int g = 0; g <= 1; g++) {
                                    for (int h = 0; h <= 1; h++) {
                                        String x = String.valueOf(a) + String.valueOf(b) + String.valueOf(c) + String.valueOf(d) + String.valueOf(e) + String.valueOf(f) + String.valueOf(g) + String.valueOf(h);
                                        if (Math.round(miniFloatFromString(x)) == miniFloatFromString(x)) {
                                            number += 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // Task 2: return the number of integral miniFloat values
        }
        return number;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
