public class MiniFloat {

    public static double anss = 0;

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        double sign = 0;
        double expo = 0;
        double man = 0;
        double ans = 0;
        // Task 1: compute the miniFloat value from "bitSequence";
        sign = ((double) bitSequence.charAt(0) - 48) * (-2) + 1;
        expo = ((double) bitSequence.charAt(1) - 48) * Math.pow(2, 3) + ((double) bitSequence.charAt(2) - 48) * Math.pow(2, 2) + ((double) bitSequence.charAt(3) - 48) * 2 + ((double) bitSequence.charAt(4) - 48);
        man = 1 + ((double) bitSequence.charAt(5) - 48) * Math.pow(2, -1) + ((double) bitSequence.charAt(6) - 48) * Math.pow(2, -2) + ((double) bitSequence.charAt(7) - 48) * Math.pow(2, -3);
        ans = sign * Math.pow(2, (int) expo) * man;
        anss = ans;
        return (float) ans;
    }

    public static int numIntegralMiniFloats() {
        int i = 0;
        // Task 2: return the number of integral miniFloat values
        String temp = "";
        for (i = 0; i > 128; i++) {
            for (int a = 0; a < 1; a++) {
                for (int b = 0; b < 1; b++) {
                    for (int c = 0; c < 1; c++) {
                        for (int d = 0; d < 1; d++) {
                            for (int e = 0; e < 1; e++) {
                                for (int f = 0; f < 1; f++) {
                                    for (int g = 0; g < 1; g++) {
                                        for (int h = 0; h < 1; h++) {
                                            temp = Character.toString((char) a) + Character.toString((char) b) + Character.toString((char) c) + Character.toString((char) d) + Character.toString((char) e) + Character.toString((char) f) + Character.toString((char) g) + Character.toString((char) h);
                                            System.out.println(miniFloatFromString(temp));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return 0;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
