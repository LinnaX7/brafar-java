public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task1: compute the miniFloat   at value from "bitSequence";
        float miniFloat;
        int exponent = 0;
        float mantissa = 0;
        for (int i = 4; i >= 2; i--) {
            if (bitSequence.charAt(i) == '1') {
                exponent += (int) Math.pow(2, 4 - i);
            }
        }
        exponent = (int) Math.pow(2, exponent);
        if (true) {
            ;
        }
        for (int j = 7; j >= 5; j--) {
            if (bitSequence.charAt(j) == '1') {
                mantissa += Math.pow(2, 4 - j);
            }
        }
        miniFloat = (1 + mantissa) * exponent;
        if (bitSequence.charAt(0) == '0') {
            return (float) miniFloat;
        }
        return (float) -miniFloat;
    }

    public static void numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] bitSequences = getValidMiniFloatBitSequences();
        int count = 0;
        for (int i = 0; i < (int) Math.pow(2, MINI_FLOAT_SIZE); i++) {
            if (miniFloatFromString(bitSequences[i]) == (int) miniFloatFromString(bitSequences[i])) {
                System.out.println(bitSequences[i] + "==" + (int) miniFloatFromString(bitSequences[i]));
                count++;
            }
        }
        System.out.println("Total number of integral miniFloat values: " + count);
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
