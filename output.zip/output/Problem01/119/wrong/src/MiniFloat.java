public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        float miniFloat;
        double exponent, mantissa;
        // Task 1: compute the miniFloat value from "bitSequence";
        exponent = Integer.parseInt((bitSequence.substring(1, 5)), 2);
        mantissa = convertMantissa(bitSequence.substring(5, 8));
        miniFloat = (float) (mantissa * (Math.pow(2, exponent)));
        return ((bitSequence.substring(0, 1)).equals("1")) ? miniFloat * (-1) : miniFloat;
    }

    public static double convertMantissa(String stringMantissa) {
        double result = (1 * Math.pow(2, 0));
        char[] ch = stringMantissa.toCharArray();
        int count = -1;
        for (char i : ch) {
            int temp = Character.getNumericValue(i);
            result += (temp * Math.pow(2, count));
            count += -1;
        }
        return result;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] bitSequence = getValidMiniFloatBitSequences();
        int count = 0;
        for (String sequence : bitSequence) {
            float miniFloat = miniFloatFromString(sequence);
            if ((Math.round(miniFloat) == miniFloat)) {
                count = count + 1;
            }
        }
        System.out.println(count);
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    public static void main(String[] args) {
        System.out.println(miniFloatFromString("10100110"));
    }
}
