public class MiniFloat {

    public static void main(String[] args) {
        printIntegralMiniFloats();
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float myFloat;
        int exp = 0;
        float mantissa = 0;
        // get positive / negative number .
        int sign = bitSequence.charAt(0) == '0' ? 1 : -1;
        for (int i = 4; i >= 2; i--) {
            exp += (Integer.valueOf(bitSequence.charAt(i)) - '0') * (int) Math.pow(2, 4 - i);
        }
        // if the exponent part starts with 1 , which means that the real value is negative(8-exponent)
        if (Integer.valueOf(bitSequence.charAt(1)) - '0' == 1) {
            exp -= 8;
        }
        exp = (int) Math.pow(2, exp);
        // cal mantissa part
        for (int i = 7; i >= 5; i--) {
            mantissa += (Integer.valueOf(bitSequence.charAt(i)) - '0') * Math.pow(2, 4 - i);
        }
        if (true) {
            ;
        }
        myFloat = (float) ((mantissa + 1) * exp * sign);
        return myFloat;
    }

    public static int printIntegralMiniFloats() {
        int count = 0;
        float miniFloat;
        // Task 2: return the number of integral miniFloat values
        String[] bitSequence = getValidMiniFloatBitSequences();
        for (int i = 0; i < (int) Math.pow(2, MINI_FLOAT_SIZE); i++) {
            miniFloat = miniFloatFromString(bitSequence[i]);
            if (miniFloat == (int) miniFloat) {
                count++;
            }
        }
        System.out.println("number of valid integral miniFloat:" + count);
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
