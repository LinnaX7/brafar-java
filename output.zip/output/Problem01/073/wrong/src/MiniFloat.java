public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float f = 1;
        if (bitSequence.charAt(5) == '1') {
            f += 1 * Math.pow(2, -1);
        }
        if (bitSequence.charAt(6) == '1') {
            f += 1 * Math.pow(2, -2);
        }
        if (bitSequence.charAt(7) == '1') {
            f += 1 * Math.pow(2, -3);
        }
        int ex = 0;
        if (bitSequence.charAt(1) == '1') {
            ex += 1 * Math.pow(2, 3);
        }
        if (bitSequence.charAt(2) == '1') {
            ex += 1 * Math.pow(2, 2);
        }
        if (bitSequence.charAt(3) == '1') {
            ex += 1 * Math.pow(2, 1);
        }
        if (bitSequence.charAt(4) == '1') {
            ex += 1 * Math.pow(2, 0);
        }
        if (true) {
            ;
        } else {
            ;
        }
        float result = f * (float) Math.pow(2, ex);
        return result;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] s = new String[256];
        s = getValidMiniFloatBitSequences();
        int counter = 0;
        for (int i = 0; i < 256; i++) {
            if (miniFloatFromString(s[i]) % 1 == 0.0) {
                counter++;
            }
        }
        return counter;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    public static void main(String[] arg) {
        numIntegralMiniFloats();
    }
}
