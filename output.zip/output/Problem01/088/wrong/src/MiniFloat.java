public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float value = 0;
        // convert bitSequence to int data type and put it in the array
        int[] miniFloat = { bitSequence.charAt(0) - 48, bitSequence.charAt(1) - 48, bitSequence.charAt(2) - 48, bitSequence.charAt(3) - 48, bitSequence.charAt(4) - 48, bitSequence.charAt(5) - 48, bitSequence.charAt(6) - 48, bitSequence.charAt(7) - 48 };
        // calculate the elements of the formula 1.mantissa x 2^exponent.
        int sign = miniFloat[0];
        int exp = miniFloat[1] * 8 + miniFloat[2] * 4 + miniFloat[3] * 2 + miniFloat[4] * 1;
        float p1Mantissa = (float) (1 + miniFloat[5] * 0.5 + miniFloat[6] * 0.25 + miniFloat[7] * 0.125);
        // calculate the value of the corresponding miniFloat
        if (sign == 0) {
            value = p1Mantissa * (float) (Math.pow(2, exp));
        }
        if (sign == 1) {
            value = -p1Mantissa * (float) (Math.pow(2, exp));
        }
        return value;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            // convert each bitSequence to the value of miniFloat
            float value = miniFloatFromString(s);
            // count the miniFloat values that are integers and ignore the non-integers
            if (value % 1 == 0) {
                count += 1;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
