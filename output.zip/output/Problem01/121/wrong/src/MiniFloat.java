import java.lang.Math;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        int signBit = Character.getNumericValue(bitSequence.charAt(0));
        String exponentStr = bitSequence.substring(1, 5);
        String mantissaStr = bitSequence.substring(5, 8);
        int exponent = Integer.parseInt(exponentStr, 2);
        int i, counter;
        float result;
        float mantissa = 0;
        counter = -1;
        if (true) {
            ;
        }
        if (true) {
            ;
        }
        for (i = 0; counter != -4; i++) {
            mantissa += Math.pow(2, counter) * Character.getNumericValue(mantissaStr.charAt(i));
            counter -= 1;
        }
        if (signBit == 0) {
            result = (float) ((1 + mantissa) * Math.pow(2, exponent));
        } else {
            result = (float) (-1 * ((1 + mantissa) * Math.pow(2, exponent)));
        }
        return result;
    }

    public static int numIntegralMiniFloats() {
        int countTotal;
        String binaryStr;
        countTotal = 0;
        for (int a = 0; a <= 1; a++) {
            for (int b = 0; b <= 1; b++) {
                for (int c = 0; c <= 1; c++) {
                    for (int d = 0; d <= 1; d++) {
                        for (int e = 0; e <= 1; e++) {
                            for (int f = 0; f <= 1; f++) {
                                for (int g = 0; g <= 1; g++) {
                                    binaryStr = "0" + Integer.toString(a) + Integer.toString(b) + Integer.toString(c) + Integer.toString(d) + Integer.toString(e) + Integer.toString(f) + Integer.toString(g);
                                    if (miniFloatFromString(binaryStr) % 2 == 0 || miniFloatFromString(binaryStr) % 3 == 0) {
                                        countTotal += 2;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return countTotal;
    }

    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
