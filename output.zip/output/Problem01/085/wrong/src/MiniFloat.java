public class MiniFloat {

    public static void main(String[] args) {
        System.out.println("All possible integral miniFloat values:");
        int a = numIntegralMiniFloats();
        System.out.println("There are " + a + " numbers of integral miniFloat values.");
        // float b = miniFloatFromString("00100110");
        // System.out.println(b);
    }

    public static float miniFloatFromString(String bitSequence) {
        char[] NumberArray = bitSequence.toCharArray();
        float value;
        float exponent = 0;
        float significand = 1;
        int power = 3;
        int power2 = -1;
        float wholevalue;
        if (NumberArray[0] == '0') {
            value = 1;
        } else {
            value = -1;
        }
        for (int i = 1; i < (NumberArray.length - 3); i++) {
            int number = Integer.parseInt(String.valueOf(NumberArray[i]));
            exponent = (float) (exponent + (number * (Math.pow(2, power))));
            power -= 1;
        }
        for (int j = 5; j < (NumberArray.length); j++) {
            int number2 = Integer.parseInt(String.valueOf(NumberArray[j]));
            significand = (float) (significand + (number2 * (Math.pow(2, power2))));
            power2 -= 1;
        }
        wholevalue = (float) (value * (significand * (Math.pow(2, exponent))));
        return wholevalue;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            float x = miniFloatFromString(s);
            System.out.println(x);
            count++;
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
