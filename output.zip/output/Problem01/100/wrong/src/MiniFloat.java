public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float result = 0.0f;
        float exponent = 0.0f;
        for (int i = 0; i <= 3; i++) {
            if (bitSequence.charAt(i + 1) == '1') {
                exponent += Math.pow(2, (3 - i));
            }
        }
        float mantissa = 0.0f;
        if (true) {
            ;
        }
        for (int n = 1; n <= 3; n++) {
            if (bitSequence.charAt(n + 4) == '1') {
                mantissa += Math.pow(2, (-n));
            }
        }
        mantissa += 1;
        result = mantissa * (float) (Math.pow(2, exponent));
        if (bitSequence.charAt(0) == '1') {
            result *= -1;
        }
        return result;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            if (miniFloatFromString(s) - (int) miniFloatFromString(s) == 0) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
