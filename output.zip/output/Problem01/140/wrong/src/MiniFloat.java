public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // System.out.println(miniFloatExponent(bitSequence, 1,4));
        return miniFloatSign(bitSequence) * miniFloatMantissa(bitSequence, 5, 7) * miniFloatExponent(bitSequence, 1, 4);
    }

    // Determine it's positive num or negative num
    // input: miniFloat x
    // output: int 1 or -1
    private static int miniFloatSign(String x) {
        int sign;
        if (x.charAt(0) == '0') {
            sign = 1;
        } else {
            sign = -1;
        }
        return sign;
    }

    // input: miniFloat x, Index of the starting point of exponent, Index of the ending point of exponent
    // Output: exponent
    private static int miniFloatExponent(String x, int startIndex, int endIndex) {
        String newX = x.substring(startIndex, endIndex + 1);
        // System.out.println(newX);
        // Convert String newX into integer
        int exponent = Integer.parseInt(newX, 2);
        // System.out.println(exponent);
        int output = 2;
        if (exponent == 0) {
            output = 1;
        } else {
            for (int i = 0; i < exponent - 1; i++) {
                output *= 2;
            }
        }
        return output;
    }

    // input: miniFloat x, Index of the starting point of exponent, Index of the ending point of exponent
    // Output: Mantissa
    private static float miniFloatMantissa(String x, int startIndex, int endIndex) {
        float mantissa = 0;
        float base = 0.5f;
        for (int i = startIndex; i <= endIndex; i++) {
            mantissa += Character.getNumericValue(x.charAt(i)) * base;
            base *= 0.5;
        }
        mantissa++;
        return mantissa;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        String[] sequence = getValidMiniFloatBitSequences();
        for (int i = 0; i < 256; i++) {
            // System.out.println(miniFloatFromString(sequence[i]));
            if (miniFloatFromString(sequence[i]) % 1 == 0) {
                // It is integer
                count++;
            }
        }
        // System.out.println(count);
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
