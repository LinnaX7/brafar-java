import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        float result = 0;
        float fac = 0;
        int a = Integer.parseInt(bitSequence.substring(0, 1), 2);
        int b = Integer.parseInt(bitSequence.substring(1, 5), 2);
        int c = Integer.parseInt(bitSequence.substring(5, 6), 2);
        int d = Integer.parseInt(bitSequence.substring(6, 7), 2);
        int e = Integer.parseInt(bitSequence.substring(7, 8), 2);
        fac = c * (float) Math.pow(2, -1) + d * (float) Math.pow(2, -2) + e * (float) Math.pow(2, -3);
        if (a == 1) {
            result = -(1 + fac) * (float) Math.pow(2, b);
        } else {
            result = (1 + fac) * (float) Math.pow(2, b);
        }
        return result;
    }

    public static int numIntegralMiniFloats() {
        float outcome;
        int result = 0;
        String[] results = getValidMiniFloatBitSequence();
        for (int p = 0; p < 256; p++) {
            outcome = (int) miniFloatFromString(results[p]) - miniFloatFromString(results[p]);
            if (outcome != 0) {
                result = result + 1;
            }
        }
        getValidMiniFloatBitSequence();
        return result;
    }

    private static String[] getValidMiniFloatBitSequence() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    public static void main(String[] args) throws IOException {
        System.out.println("Please input a binary number：");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String a = null;
        a = br.readLine();
        System.out.println(miniFloatFromString(a));
        System.out.println(numIntegralMiniFloats());
    }
}
