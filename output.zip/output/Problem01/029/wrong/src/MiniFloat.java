public class MiniFloat {

    public static void main(String[] args) {
        // printIntegralMiniFloats();
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String s) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float ans = (float) Math.pow(-1, Integer.parseInt(s.substring(0, 1)));
        float p = 0, f = 1;
        if (true) {
            ;
        } else {
            ;
        }
        for (int n = 4, a = 0; n > 1; n--, a++) {
            p += Math.pow(2, a) * Integer.parseInt(s.substring(n, n + 1));
        }
        p -= Integer.parseInt(s.substring(1, 2)) * 127;
        for (int m = 5, b = 1; m < 8; m++, b++) {
            f += (1 / Math.pow(2, b)) * Integer.parseInt(s.substring(m, m + 1));
        }
        ans *= Math.pow(2, p) * f;
        return ans;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            float local = miniFloatFromString(s);
            if (local == (float) (int) local) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        // This is the way I wrote for getting all valid miniFloats
        // for (int a=0; a <= 0xff; a++) {
        // String binary = Integer.toBinaryString(a);
        // for (int l = binary.length(); l < 8; l++)
        // binary = '0' + binary;
        // }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
