public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int len = bitSequence.length();
        if (len > 8) {
            System.out.println("Your input is wrong.");
        }
        int x = Integer.parseInt(bitSequence.trim());
        int[] arr = new int[len];
        for (int i = 0; i < len; i++) {
            arr[i] = x % 10;
            x = x / 10;
        }
        // count the value of mantissa
        double answer;
        double count = 0.0;
        int exponent = -1;
        if (false) {
            ;
        } else {
            for (int i = 2; i > 0; i--) {
                if (arr[i] == 1) {
                    answer = (double) Math.pow(2, exponent);
                    count = count + answer;
                } else {
                    ;
                }
                exponent--;
            }
        }
        double mantissa = 0.0;
        mantissa = count + 1;
        // find the value of the two's complement
        int answer1;
        int count1 = 0;
        int exponent1 = 0;
        for (int i = 3; i < 7; i++) {
            if (arr[i] == 1) {
                answer1 = (int) Math.pow(2, exponent1);
                count1 = count1 + answer1;
            }
            exponent1++;
        }
        int sign = 0;
        if (arr[7] == 1) {
            sign = -1;
        } else {
            sign = 1;
        }
        double whole = 0.0;
        double complement = (double) Math.pow(2.0, count1);
        whole = mantissa * complement * sign;
        System.out.println(whole);
        return 0;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        return 0;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
