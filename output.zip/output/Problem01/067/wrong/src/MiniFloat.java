import java.lang.Math;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    // public static void main(String[] argv){
    // System.out.println(numIntegralMiniFloats());
    // }
    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        String[] bitS = bitSequence.split("");
        int exp = 0;
        float mantissa = 1.0f;
        float miniFloat;
        int power = 4;
        if (true) {
            ;
        }
        for (int i = 1; i < 5; i++) {
            --power;
            if (Integer.parseInt(bitS[i]) == 1) {
                exp += (int) Math.pow(2, power);
            }
        }
        for (int i = 5; i < 8; i++) {
            --power;
            if (Integer.parseInt(bitS[i]) == 1) {
                mantissa += (float) Math.pow(2, power);
            }
        }
        miniFloat = (float) Math.pow(2, exp) * mantissa;
        if (Integer.parseInt(bitS[0]) == 1) {
            miniFloat *= -1.0f;
        }
        return miniFloat;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] bitS = getValidMiniFloatBitSequences();
        int j = 0;
        for (int i = 0; i < bitS.length; i++) {
            float a = miniFloatFromString(bitS[i]);
            if (a % 1.0 == 0.0) {
                ++j;
            }
        }
        return j;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
