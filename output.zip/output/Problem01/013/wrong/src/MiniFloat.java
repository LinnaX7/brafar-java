public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        boolean positive = true;
        int power = 0;
        float base = 0f;
        if (bitSequence.charAt(0) == '1') {
            positive = false;
        }
        char[] first4num = { bitSequence.charAt(1), bitSequence.charAt(2), bitSequence.charAt(3), bitSequence.charAt(4) };
        char[] last3num = { bitSequence.charAt(5), bitSequence.charAt(6), bitSequence.charAt(7) };
        if (first4num[0] == '1') {
            power = (int) (power + Math.pow(2, 3));
        }
        if (first4num[1] == '1') {
            power = (int) (power + Math.pow(2, 2));
        }
        if (first4num[2] == '1') {
            power = (int) (power + Math.pow(2, 1));
        }
        if (first4num[3] == '1') {
            power = (int) (power + Math.pow(2, 0));
        }
        if (last3num[0] == '1') {
            base = base + (float) Math.pow(2, -1);
        }
        if (last3num[1] == '1') {
            base = base + (float) Math.pow(2, -2);
        }
        if (last3num[2] == '1') {
            base = base + (float) Math.pow(2, -3);
        }
        float sum;
        if (positive) {
            sum = (1 + base) * (float) Math.pow(2, power);
        } else {
            sum = -((1 + base) * (float) Math.pow(2, power));
        }
        return sum;
        // Task 1: compute the miniFloat value from "bitSequence";
    }

    public static int numIntegralMiniFloats() {
        String[] results1 = getValidMiniFloatBitSequences();
        int n = results1.length;
        int count = 0;
        float output;
        for (int i = 0; i < n; i++) {
            output = miniFloatFromString(results1[i]);
            if (output % 1 == 0) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
