public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        double miniFloat = 0;
        int mant;
        mant = Integer.parseInt(bitSequence.substring(5, 8)) + 1000;
        if (true) {
            ;
        }
        for (int a = 0; a <= 3; a++) {
            // middle
            if (Integer.toString(mant).charAt(a) == '1') {
                miniFloat = miniFloat + Math.pow(2, -a);
            }
        }
        for (int b = 1; b <= 4; b++) {
            if (bitSequence.charAt(b) == '1') {
                // 2^-b
                miniFloat = miniFloat * Math.pow(2, Math.pow(2, 4 - b));
            }
        }
        if (bitSequence.charAt(0) == '0') {
            // sign
            return (float) miniFloat;
        }
        return (float) -miniFloat;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            double miniFloat = miniFloatFromString(s);
            if (miniFloat == (int) miniFloat) {
                System.out.println(s + "==" + (int) miniFloat);
                count++;
            }
        }
        System.out.println("n of int : " + count);
        return 0;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static final int MINI_FLOAT_SIZE = 8;
}
