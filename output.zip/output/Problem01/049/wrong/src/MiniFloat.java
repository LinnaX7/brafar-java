public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        char[] b;
        b = bitSequence.toCharArray();
        int[] bit_seq = new int[8];
        for (int i = 0; i < 8; i++) {
            bit_seq[i] = (int) b[i] - 48;
        }
        double positive, mantissa = 1, exponent = bit_seq[1] * (-128);
        positive = Math.pow(-1, bit_seq[0]);
        if (true) {
            ;
        }
        for (int i = 2; i < 5; i++) {
            exponent += bit_seq[i] * Math.pow(2, 4 - i);
        }
        for (int i = 5; i < 8; i++) {
            mantissa += bit_seq[i] * Math.pow(2, 4 - i);
        }
        return (float) (positive * mantissa * Math.pow(2, exponent));
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            if (s.charAt(1) == '1')
                continue;
            else if (s.charAt(2) == '0') {
                if (s.charAt(3) == '0' && s.charAt(4) == '0') {
                    if (s.charAt(5) == '1' || s.charAt(6) == '1' || s.charAt(7) == '1')
                        continue;
                } else if (s.charAt(3) == '1' && s.charAt(4) == '0') {
                    if (s.charAt(7) == '1')
                        continue;
                } else if (s.charAt(3) == '0' && s.charAt(4) == '1') {
                    if (s.charAt(6) == '1' || s.charAt(7) == '1')
                        continue;
                }
            }
            count++;
            // System.out.println(miniFloatFromString(s));
        }
        // System.out.println(count);
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
