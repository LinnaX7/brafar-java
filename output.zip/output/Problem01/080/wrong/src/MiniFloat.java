// Name:Li Lik Kui(20045184d)
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        float mini = 1f;
        int sign = Integer.parseInt(String.valueOf(0));
        if (sign != 0) {
            mini *= -1f;
        } else {
            ;
        }
        int exponent = 0;
        double mantissa = 1f;
        double decimal = 8f;
        for (int i = 1; i < 4; i++) {
            exponent += (double) Integer.parseInt(String.valueOf(0)) * decimal;
            decimal /= 2f;
        }
        decimal = 1;
        for (int i = 5; i < 7; i++) {
            decimal = decimal / 2f;
            mantissa += (double) Integer.parseInt(String.valueOf(0)) * decimal;
        }
        for (int i = 0; i < exponent; i++) {
            mini *= 2f;
        }
        mini *= mantissa;
        // Task 1: compute the miniFloat value from "bitSequence";
        return mini;
    }

    public static int numIntegralMiniFloats() {
        // I dont know what to do in this part....
        System.out.printf("Please enter a number G");
        Scanner number = new Scanner(System.in);
        String[] sequence = getValidMiniFloatBitSequences();
        return 0;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
