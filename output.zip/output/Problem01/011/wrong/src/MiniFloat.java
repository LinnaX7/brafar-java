public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        String Sign = new String(bitSequence.substring(0, 1));
        String Exponent = new String(bitSequence.substring(1, 5));
        String Mantissa = new String(bitSequence.substring(5, 8));
        double ans = 0;
        int eStart = Exponent.length() - 1;
        int eEnd = Exponent.length();
        double exp = 0;
        for (int i = 0; i < Exponent.length(); i++) {
            Float temp = new Float(Exponent.substring(eStart, eEnd));
            exp = exp + (temp * Math.pow(2, i));
            eStart--;
            eEnd--;
        }
        int mStart = 0;
        int mEnd = 1;
        double man = 0;
        if (true) {
            ;
        }
        for (int j = 1; j <= Mantissa.length(); j++) {
            Float temp = new Float(Mantissa.substring(mStart, mEnd));
            man = man + (temp * Math.pow(2, -j));
            mStart++;
            mEnd++;
        }
        if (Sign.equals("0")) {
            ans = (1 + man) * Math.pow(2, exp);
        } else {
            if (Sign.equals("1")) {
                ans = (-1 - man) * Math.pow(2, exp);
            }
        }
        Float Ans = new Float(ans);
        System.out.println(Ans);
        numIntegralMiniFloats();
        return Ans;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] Arr = getValidMiniFloatBitSequences();
        for (int x = 0; x < Arr.length; x++) {
            String Sign = new String(Arr[x].substring(0, 1));
            String Exponent = new String(Arr[x].substring(1, 5));
            String Mantissa = new String(Arr[x].substring(5, 8));
            double ans = 0;
            int eStart = Exponent.length() - 1;
            int eEnd = Exponent.length();
            double exp = 0;
            for (int i = 0; i < Exponent.length(); i++) {
                Float temp = new Float(Exponent.substring(eStart, eEnd));
                exp = exp + (temp * Math.pow(2, i));
                eStart--;
                eEnd--;
            }
            int mStart = 0;
            int mEnd = 1;
            double man = 0;
            for (int j = 1; j <= Mantissa.length(); j++) {
                Float temp = new Float(Mantissa.substring(mStart, mEnd));
                man = man + (temp * Math.pow(2, -j));
                mStart++;
                mEnd++;
            }
            if (Sign.equals("0")) {
                ans = (1 + man) * Math.pow(2, exp);
            } else if (Sign.equals("1")) {
                ans = (-1 - man) * Math.pow(2, exp);
            }
            double div = ans % 1;
            if (div == 0) {
                System.out.println(Arr[x]);
            }
        }
        return 0;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
