public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        int power = new Integer(2);
        float exponentDecimal = new Float(0);
        if (bitSequence.charAt(1) == '0') {
            exponentDecimal = Integer.parseInt(bitSequence.substring(1, 5), 2);
        } else {
            ;
        }
        if (bitSequence.charAt(1) == '1') {
            for (int i = 2; i < 5; i++) {
                if (bitSequence.charAt(i) == '0') {
                    exponentDecimal += Math.pow(2, power);
                }
                power--;
            }
            exponentDecimal++;
            exponentDecimal = exponentDecimal - exponentDecimal - exponentDecimal;
        }
        char num5 = (bitSequence.charAt(5));
        int a5 = Character.getNumericValue(num5);
        double mantissaDecimal = a5 * 0.5;
        char num6 = (bitSequence.charAt(6));
        int a6 = Character.getNumericValue(num6);
        mantissaDecimal = mantissaDecimal + a6 * 0.25;
        char num7 = (bitSequence.charAt(7));
        int a7 = Character.getNumericValue(num7);
        mantissaDecimal = mantissaDecimal + a7 * 0.125;
        mantissaDecimal = 1 + mantissaDecimal;
        System.out.println("significand: " + mantissaDecimal);
        double wholeValue = (double) Math.pow(2, exponentDecimal);
        wholeValue = wholeValue * mantissaDecimal;
        char num0 = (bitSequence.charAt(0));
        int a0 = Character.getNumericValue(num0);
        if (a0 == 1) {
            wholeValue = wholeValue - wholeValue - wholeValue;
        } else {
            ;
        }
        System.out.println(exponentDecimal);
        System.out.println("Whole value: " + wholeValue);
        // Task 1: compute the miniFloat value from "bitSequence";
        return (float) wholeValue;
    }

    public static int numIntegralMiniFloats() {
        int counter = new Integer(0);
        String[] resultArray = getValidMiniFloatBitSequences();
        for (int j = 0; j < Math.pow(2, MINI_FLOAT_SIZE); j++) {
            if (((miniFloatFromString(resultArray[j]) % 1) == 0)) {
                System.out.println(miniFloatFromString(resultArray[j]));
                counter++;
            }
        }
        System.out.println(counter);
        return counter;
        // Task 2: return the number of integral miniFloat values
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
