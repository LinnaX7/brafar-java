public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // Task 1: compute the miniFloat value from "bitSequence";
        char pos = bitSequence.charAt(0);
        int exp = Integer.parseInt(bitSequence.substring(1, 5), 2);
        float sign = (float) (1 + Integer.parseInt(bitSequence.substring(5), 2) * Math.pow(2, -3));
        if (pos == '0') {
            return (float) (Math.pow(2, exp) * sign);
        }
        return (float) (Math.pow(2, exp) * sign * -1);
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] allSeq = getValidMiniFloatBitSequences();
        int count = 0;
        for (int i = 0; i < allSeq.length; i++) {
            float miniFloat = miniFloatFromString(allSeq[i]);
            if (miniFloat == Math.round(miniFloat))
                count++;
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
