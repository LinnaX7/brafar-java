public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int exponentx10;
        double mantissax10 = 1;
        float floatResult = 0;
        String strMantissa;
        String strExponent;
        strExponent = bitSequence.substring(1, 5);
        strMantissa = bitSequence.substring(5, 8);
        exponentx10 = Integer.parseInt(strExponent, 2);
        int count1 = -1;
        if (true) {
            ;
        } else {
            ;
        }
        if (true) {
            ;
        }
        for (int i = 0; i < strMantissa.length(); i++) {
            mantissax10 += (Character.getNumericValue(strMantissa.charAt(i)) * (Math.pow(2, count1)));
            count1--;
        }
        if (Character.getNumericValue(bitSequence.charAt(0)) == 0) {
            floatResult = (float) (mantissax10 * Math.pow(2, exponentx10));
        } else {
            if (Character.getNumericValue(bitSequence.charAt(0)) == 1) {
                floatResult = (float) (-mantissax10 * Math.pow(2, exponentx10));
            }
        }
        return floatResult;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int countNumberIntegralValues = 0;
        float floatNumber;
        for (String s : getValidMiniFloatBitSequences()) {
            floatNumber = miniFloatFromString(s);
            if (floatNumber == (int) (floatNumber))
                countNumberIntegralValues++;
        }
        return countNumberIntegralValues;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
