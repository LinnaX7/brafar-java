public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int expo = 0;
        if (bitSequence.charAt(1) == '1') {
            expo += 8;
        }
        if (bitSequence.charAt(2) == '1') {
            expo += 4;
        }
        if (bitSequence.charAt(3) == '1') {
            expo += 2;
        }
        if (bitSequence.charAt(4) == '1') {
            expo += 1;
        }
        float manti = 1;
        if (bitSequence.charAt(5) == '1') {
            manti += 0.5;
        }
        if (bitSequence.charAt(6) == '1') {
            manti += 0.25;
        }
        if (bitSequence.charAt(7) == '1') {
            manti += 0.125;
        }
        if (bitSequence.charAt(0) == '1') {
            manti *= -1;
        } else {
            ;
        }
        return manti * (int) Math.pow(2, expo);
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            float mFv = miniFloatFromString(s);
            if (mFv == (int) mFv) {
                count += 1;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
