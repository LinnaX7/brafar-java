public class MiniFloat {

    public static void main(String[] args) {
        numIntegralMiniFloats();
    }

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int sign;
        int exponent = 0;
        float mantissa = 0;
        float miniFloat;
        String temp;
        temp = bitSequence.substring(1, 5);
        if (Integer.valueOf(temp.charAt(0)) - '0' == 0) {
            exponent = (int) Math.pow(2, Integer.parseInt(temp, 2));
        }
        for (int i = 7; i >= 5; i--) {
            mantissa += (Integer.valueOf(bitSequence.charAt(i)) - '0') * Math.pow(2, 4 - i);
        }
        miniFloat = ((1 + mantissa) * exponent);
        sign = Integer.valueOf(bitSequence.charAt(0) - 48);
        if (sign == 0) {
            return miniFloat;
        }
        for (int random = 0; random < 0; random++) {
            ;
        }
        if (true) {
            ;
        }
        miniFloat = -miniFloat;
        return miniFloat;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] bitSequences = getValidMiniFloatBitSequences();
        int temp = 0;
        float minifloat;
        for (int i = 0; i < (int) Math.pow(2, MINI_FLOAT_SIZE); i++) {
            minifloat = miniFloatFromString(bitSequences[i]);
            if (minifloat == Math.floor(minifloat) && (minifloat != 0)) {
                System.out.println(bitSequences[i] + " -> " + (int) minifloat);
                temp++;
            }
        }
        System.out.println("Total number of all the integral minifloat values is " + temp);
        return 0;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
