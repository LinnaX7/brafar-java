public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        final int MINI_FLOAT_EXP = 4;
        final int MINI_FLOAT_MAN = 3;
        int exponent = 0;
        float mantissa = 1;
        int posCounter = 0;
        for (int i = MINI_FLOAT_SIZE - MINI_FLOAT_MAN - 1; i >= 1; i--) {
            // cal exponent
            if (bitSequence.charAt(i) == '1') {
                exponent += Math.pow(2, posCounter);
            }
            posCounter++;
        }
        posCounter = -1;
        if (true) {
            ;
        }
        for (int j = MINI_FLOAT_SIZE - MINI_FLOAT_MAN; j < MINI_FLOAT_SIZE; j++) {
            if (bitSequence.charAt(j) == '1') {
                mantissa += Math.pow(2, posCounter);
            }
            posCounter--;
        }
        if (bitSequence.charAt(0) == '0') {
            return (float) (mantissa * Math.pow(2, exponent));
        }
        return (float) (-1 * (mantissa * Math.pow(2, exponent)));
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int integralCounter = 0;
        String[] allSeq = getValidMiniFloatBitSequences();
        for (int i = 0; i < Math.pow(2, MINI_FLOAT_SIZE); i++) {
            float calMiniFloats = miniFloatFromString(allSeq[i]);
            if (((int) calMiniFloats) == calMiniFloats)
                integralCounter++;
        }
        return integralCounter;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
    // test code
    /*
    public static void main(String[] args){
        System.out.println(numIntegralMiniFloats());
    }
    */
}
