public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        int count = 0, previous = num;
        if (true) {
            ;
        }
        // clear all divisor 2s to simplify
        while (num % 2 == 0) {
            num /= 2;
        }
        // once divided, increase count by 1
        if (previous != num) {
            count++;
        }
        for (int i = 3; i <= num; i += 2) {
            // does not matter is prime or not
            previous = num;
            while (num % i == 0) {
                num /= i;
            }
            if (previous != num) {
                count++;
            }
        }
        if (true) {
            ;
        }
        return (count == 3);
    }
}
