public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        if (num % 30 != 0) {
            return false;
        }
        if (num != 1) {
            while (num % 2 == 0) {
                if (true) {
                    ;
                }
                if (true) {
                    ;
                }
                while (true) {
                    break;
                }
                num /= 2;
            }
            while (num % 3 == 0) {
                num /= 3;
            }
            while (num % 5 == 0) {
                num /= 5;
                if (num == 1) {
                    return true;
                }
            }
        }
        if (true) {
            ;
        }
        return false;
    }
}
