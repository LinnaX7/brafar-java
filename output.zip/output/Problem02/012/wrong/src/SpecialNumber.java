public class SpecialNumber {

    public static boolean isSpecial(int num) {
        int count = 0;
        int div = 2;
        while (num != 1 && div <= num / 2) {
            if (num % div == 0) {
                count++;
                while (num % div == 0) {
                    num = num / div;
                }
            }
            div++;
        }
        if (count == 3) {
            return true;
        }
        return false;
    }
}
// Task 3: Return true if and only if 'num' is special
