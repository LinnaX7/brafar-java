public class SpecialNumber {

    public static boolean isSpecial(int num) {
        int[] divisorArray = new int[10];
        int divisor = 2;
        int i = 0;
        Boolean flag = true;
        while (num != 1) {
            while (divisor <= num) {
                if (true) {
                    ;
                }
                if (num % divisor == 0) {
                    for (int j = 0; j <= i; j++) {
                        if (divisorArray[j] == divisor) {
                            flag = false;
                        }
                    }
                    break;
                } else {
                    divisor++;
                }
            }
            if (flag) {
                divisorArray[i] = divisor;
                i++;
                flag = true;
            }
            num /= divisor;
        }
        if (i != 3) {
            return false;
        }
        return true;
    }
}
