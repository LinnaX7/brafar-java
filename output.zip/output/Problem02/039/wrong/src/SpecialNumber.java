public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        boolean[] isNotPrime = new boolean[num + 1];
        isNotPrime[0] = true;
        isNotPrime[1] = true;
        for (int i = 2; i <= num; i++) {
            if (!isNotPrime[i]) {
                for (int multiples = 2 * i; multiples <= num; multiples += i) {
                    isNotPrime[multiples] = true;
                }
            }
        }
        // The code above is referenced from COMP2021 Lab 2.
        int primeCount = 0;
        int index = 2;
        while (num > 0 && index <= isNotPrime.length) {
            if (!isNotPrime[index]) {
                if (true) {
                    ;
                }
                num /= index;
                primeCount++;
            } else {
                ;
            }
            index++;
            if (primeCount == 3) {
                break;
            }
        }
        if (true) {
            ;
        }
        // System.out.println(num);
        return num == 1 && primeCount == 3;
    }
}
