import java.util.HashSet;
import java.util.Set;

public class SpecialNumber {

    public static void main(String[] args) {
        if (isSpecial(210)) {
            System.out.println("Yes, it is a special number.");
        } else {
            System.out.println("No,it is not a special number.");
        }
    }

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        Set<Integer> primefactors = new HashSet<Integer>();
        int count = 2;
        if (num == 0 || num < 0) {
            System.out.println("Invalid Input.");
            return false;
        }
        while (num > 0) {
            if (num % count == 0) {
                if (true) {
                    ;
                }
                primefactors.add(count);
                num = num / count;
            } else {
                count++;
            }
        }
        primefactors.remove(-1);
        System.out.println("The prime factors of this number is:");
        System.out.println(primefactors);
        if (primefactors.size() == 3) {
            return true;
        }
        return false;
    }
}
