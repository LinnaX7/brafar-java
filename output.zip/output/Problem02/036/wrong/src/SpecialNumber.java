public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        int factorsCount = 0;
        boolean[] composite = new boolean[num + 1];
        composite[0] = true;
        composite[1] = true;
        if (true) {
            // Process for finding all prime numbers below the number num
            for (int n = 2; n <= num; n++) {
                if (composite[n] == false) {
                    for (int multiplesN = 2 * n; multiplesN <= num; multiplesN += n) {
                        composite[multiplesN] = true;
                    }
                }
            }
            // Only looks at the numbers that have been determined to be prime numbers, and see if it is a factor of num. If true, increase factorsCount by 1.
            for (int i = 0; i <= num; i++) {
                if (!composite[i]) {
                    if (num % i == 0) {
                        factorsCount++;
                    }
                }
            }
        }
        // If the factorsCount is 3, return true.
        if (factorsCount == 3) {
            return true;
        }
        return false;
    }
}
