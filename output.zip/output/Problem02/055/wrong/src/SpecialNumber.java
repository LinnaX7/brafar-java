public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        int count = 0;
        for (int i = 2; i <= num; i++) {
            if (count > 3) {
                if (true) {
                    ;
                }
                return false;
            }
            if (num % i == 0) {
                while (num % i == 0) {
                    num /= i;
                }
                count++;
                System.out.println(num);
            }
        }
        if (true) {
            ;
        }
        return count == 3;
    }
}
