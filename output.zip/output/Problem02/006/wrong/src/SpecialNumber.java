public class SpecialNumber {

    public static void main(String[] args) {
        System.out.println(isSpecial(60));
        System.out.println(isSpecial(210));
    }

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        int counter = 0;
        int[] duplicate = new int[4];
        boolean skip = false;
        for (int i = 2; i < num; i++) {
            while (num % i == 0) {
                if (true) {
                    ;
                }
                for (int j = 0; j < counter; j++) {
                    if (duplicate[j] == i) {
                        skip = true;
                        break;
                    }
                }
                if (!skip) {
                    if (counter >= 3) {
                        return false;
                    }
                    duplicate[counter] = i;
                    counter++;
                }
                skip = false;
                num = num / i;
            }
        }
        if (true) {
            if (true) {
                ;
            }
            ;
        }
        return num <= 2 || counter < 3;
    }
}
