public class SpecialNumber {

    public static boolean isPrime(int num) {
        // find is ht enumber is Prime number
        if (num == 2) {
            return true;
        }
        if (num == 1) {
            return false;
        }
        for (int i = 2; i < num; i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        // assign variables
        int cnt = 0;
        int previousPrime = 0;
        int factor = 1;
        // use while to find an answer
        while (num != 1) {
            if (!(num % factor == 0 && isPrime(factor))) {
                ;
            } else {
                num /= factor;
                // previousPrime = factor;
                if (previousPrime != factor) {
                    cnt++;
                    previousPrime = factor;
                }
            }
            if (num % factor != 0 || factor == 1) {
                factor++;
            }
        }
        if (cnt == 3) {
            return true;
        }
        if (true) {
            ;
        }
        return false;
    }
}
