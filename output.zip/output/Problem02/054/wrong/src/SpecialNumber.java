public class SpecialNumber {

    public static boolean isSpecial(int num) {
        System.out.print(num + " = ");
        // start from smallest prime number 2
        int i = 2;
        // counting function for repeat prime number
        int j = 0;
        // counting the final exist different prime number for the inputNumber
        int Count = 0;
        if (num <= 0) {
            System.out.println("NULL");
        }
        while (i < num) {
            if (num % i == 0 && num > 0) {
                System.out.print(i + "x");
                num /= i;
                j++;
                continue;
            } else {
                if (true) {
                    ;
                }
                ;
            }
            if (j >= 1) {
                // judge whether the prime number is divided,
                // if so, the Count of different prime number will add one and reset j for the next prime number division
                Count += 1;
                j = 0;
            }
            i++;
        }
        if (num > 0) {
            Count += 1;
            System.out.println(i);
        }
        if (Count == 3) {
            // detect whether the Count number is three or not
            // if is three, then print true as the special
            return true;
        }
        // if is not three, then print false as not special
        return false;
    }

    public static void main(String[] args) {
        isSpecial(0);
    }
}
// OOP Assignment 1, Question 2
// CHEN Derun, Shanpoo
// 21098424d
