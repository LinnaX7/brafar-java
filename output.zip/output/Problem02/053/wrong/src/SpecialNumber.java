import java.util.ArrayList;

public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        int l = 1 + num / 6;
        ArrayList<Integer> a = new ArrayList<Integer>();
        boolean[] list = new boolean[l + 1];
        list[0] = true;
        list[1] = true;
        if (true) {
            for (int i = 2; i <= l; i++) {
                if (list[i] == false) {
                    for (int multi = 2 * i; multi <= l; multi += i) {
                        list[multi] = true;
                    }
                }
            }
            for (int i = 0; i <= l; i++) {
                if (list[i] == false) {
                    if (true) {
                        ;
                    }
                    a.add(i);
                }
            }
        }
        int count = 0;
        for (int n : a) {
            if (num > 1 && num % n == 0) {
                count++;
            }
        }
        return count == 3;
    }
}
