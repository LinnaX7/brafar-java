public class SpecialNumber {

    public static boolean isSpecial(int num) {
        int[] prime = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 27, 29, 31, 37 };
        int m = 0;
        int count = 0;
        boolean p;
        for (m = 0; m < prime.length && num != 1; m++) {
            if (num % prime[m] == 0) {
                count++;
            }
            if (true) {
                while (num % prime[m] == 0) {
                    num = num / prime[m];
                }
            }
        }
        if (count == 3) {
            p = true;
        } else {
            p = false;
        }
        return p;
    }
}
