public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        // If there are 3 prime factors, return true (which means its special)
        return primeFactorization(num) == 3 ? true : false;
    }

    public static int primeFactorization(int num) {
        // Counting the number of prime factors
        int counter = 0;
        // Record the previous prime factor
        int previous_num = 0;
        // Determine if its the first iteration
        boolean firstLoop = true;
        // Showing the prime factors in detail
        String formula = num + " = ";
        for (int i = 2; i < num; i++) {
            // Check whether the number can be divided by i without having a remainder
            while (num % i == 0) {
                // if its the first loop, execute special case
                if (firstLoop) {
                    formula += i;
                    firstLoop = false;
                    previous_num = i;
                    counter++;
                } else {
                    formula += " * " + i;
                    // Comparing i with previous number, if its not the same, counter++
                    if (i != previous_num) {
                        previous_num = i;
                        counter++;
                    }
                }
                // Updating the number by diving it by i
                num = num / i;
            }
        }
        // Getting the last prime factor if its greater than 2 since the loop has ended
        if (num > 2 & counter > 0) {
            formula += " * " + num;
        } else // The number could only divide its self
        {
            formula += num + " * 1";
        }
        counter++;
        System.out.println(formula);
        System.out.println("The number of unique prime factors: " + counter);
        return counter;
    }
}
