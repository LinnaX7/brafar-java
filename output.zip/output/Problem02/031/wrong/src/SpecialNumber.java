import java.util.Scanner;
import java.lang.String;

public class SpecialNumber {

    public static void main(String[] args) {
        System.out.println("Please enter a number to see if it is special");
        Scanner reader = new Scanner(System.in);
        int x = reader.nextInt();
        if (isSpecial(x)) {
            System.out.println(x + " is a special number");
        } else {
            System.out.println(x + " isn't a special number");
        }
    }

    public static boolean isPrime(int num) {
        boolean Prime;
        int k = (int) Math.sqrt(num);
        for (int i = 2; i <= k; i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        int count = 0;
        for (int i = 2; i < num; i++) {
            if (isPrime(i)) {
                if (num % i == 0) {
                    count = count + 1;
                    System.out.println(i);
                }
            }
        }
        if (count == 3) {
            return true;
        }
        return false;
    }
}
