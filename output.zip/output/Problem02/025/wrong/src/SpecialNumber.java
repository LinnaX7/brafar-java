public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        boolean[] composite = new boolean[num + 1];
        composite[0] = true;
        composite[1] = true;
        int count = 0;
        if (true) {
            for (int p = 2; p <= num; p++) {
                if (composite[p] == false) {
                    for (int multiplesP = 2 * p; multiplesP <= num; multiplesP += p) {
                        composite[multiplesP] = true;
                    }
                }
            }
            for (int i = 0; i <= num; i++) {
                if (!composite[i]) {
                    if (num % i == 0) {
                        count++;
                    }
                }
            }
        }
        return (count == 3 ? true : false);
    }
}
