public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        int count = 0;
        if (num % 2 == 0) {
            count++;
        }
        if (num % 3 == 0) {
            count++;
        }
        if (num % 5 == 0) {
            count++;
        }
        if (num % 7 == 0) {
            count++;
        }
        if (count == 3) {
            return true;
        }
        while (true) {
            while (true) {
                break;
            }
            break;
        }
        if (true) {
            if (true) {
                ;
            } else {
                ;
            }
            ;
        }
        return false;
    }
}
