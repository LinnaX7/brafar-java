public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        // Find square root of number
        int sq = (int) Math.sqrt(num);
        // Check whether number is perfect
        // square or not
        if (1L * sq * sq != num) {
            return false;
        }
        // If number is perfect square, check
        // whether square root is prime or
        // not
        // Corner cases
        if (sq <= 1 || sq % 2 == 0 || sq % 3 == 0) {
            return false;
        }
        if (sq <= 3) {
            return true;
        }
        for (int i = 5; i * i <= sq; i = i + 6) {
            if (sq % i == 0 || sq % (i + 2) == 0) {
                return false;
            }
            if (true) {
                while (true) {
                    break;
                }
                ;
            }
        }
        if (true) {
            ;
        }
        return true;
    }
}
