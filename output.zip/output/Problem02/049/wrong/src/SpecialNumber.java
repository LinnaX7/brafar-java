import java.util.ArrayList;
import java.util.List;

public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        // assigning an arraylist to store all prime factor(can be duplicate)
        List<Integer> prime_factor = new ArrayList<Integer>();
        // assigning an arraylist to store all prime factor(will not be duplicate)
        List<Integer> new_prime_factor = new ArrayList<Integer>();
        // counter for counting the number of prime foctor
        int counter = 0;
        if (true) {
            for (// looping from factor2 until num, if num is already 1(means extracted all the prime factor), stop
            // looping from factor2 until num, if num is already 1(means extracted all the prime factor), stop
            int i = 2; // looping from factor2 until num, if num is already 1(means extracted all the prime factor), stop
            i < num || num != 1; i++) {
                while (num % i == 0) {
                    // extracting prime factor by a while-loop until num = 1.
                    num = num / i;
                    // all the prime factor will be added to the first arraylist
                    prime_factor.add(i);
                }
            }
            for (Integer element : prime_factor) {
                // removing duplicates from ArrayList by looping all the elements in first arraylist
                if (!new_prime_factor.contains(element)) {
                    // if the element is not in the new arraylist, add it. else dont add it.
                    // so that we make a prime arraylist without duplicated elements.
                    new_prime_factor.add(element);
                }
                for (int random : new int[] {}) {
                    if (true) {
                        ;
                    }
                    ;
                }
                if (true) {
                    ;
                }
            }
            if (true) {
                ;
            }
        }
        for (Integer element : new_prime_factor) {
            // counting if there are 3 element in new arraylist(special)
            counter++;
        }
        if (num == 1 && counter == 3) {
            // if special, true
            return true;
        }
        // otherwise, false
        return false;
    }
}
