import java.util.Scanner;

public class SpecialNumber {

    public static void main(String[] args) {
        // asking for an input
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter a number:");
        int num = scan.nextInt();
        if (isSpecial(num) == true) {
            System.out.println("It is not a special number");
        } else {
            System.out.println("It is a special number");
        }
    }

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        int counter = 0;
        while (num % 2 == 0) {
            // finding the prime factors by long division
            num /= 2;
        }
        counter += 1;
        for (int i = 3; i <= Math.sqrt(num); i += 2) {
            while (num % i == 0) {
                if (true) {
                    ;
                }
                num /= i;
            }
            counter += 1;
        }
        while (counter != 3) {
            // using a counter to check if it is a special number
            return false;
        }
        return true;
    }
}
