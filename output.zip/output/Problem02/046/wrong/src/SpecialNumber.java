import java.util.ArrayList;

public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        ArrayList fac = factor(num);
        ArrayList prim = primes(num);
        ArrayList primFac = new ArrayList();
        for (int i = 0; i < fac.size(); i++) {
            if (prim.contains(fac.get(i))) {
                primFac.add(fac.get(i));
            }
        }
        return (primFac.size() == 3 ? true : false);
    }

    public static ArrayList factor(int num) {
        ArrayList fac = new ArrayList();
        for (int i = 1; i <= num; i++) {
            if (num % i == 0) {
                fac.add(i);
            }
        }
        return fac;
    }

    public static ArrayList primes(int n) {
        boolean[] mark = new boolean[n + 1];
        mark[0] = true;
        mark[1] = true;
        for (int p = 2; p <= n; p++) {
            if (mark[p] == false) {
                for (int multipulesP = 2 * p; multipulesP <= n; multipulesP += p) {
                    mark[multipulesP] = true;
                }
            }
        }
        ArrayList prim = new ArrayList();
        for (int i = 0; i <= n; i++) {
            if (!mark[i]) {
                prim.add(i);
            }
        }
        return prim;
    }
}
