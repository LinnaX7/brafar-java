public class SpecialNumber {

    /**
     * Function to check if the number is prime or not
     */
    static boolean isPrime(int n) {
        // declaring the variable
        int i;
        // using the concept that the largest factor of the number is it's half
        // and if it is divisible any other number from 2 to n/2, the number is not prime,
        // as the number should be only divisible by 1 and itself
        for (i = 2; i <= n / 2; i++) {
            if (n % i == 0)
                return false;
        }
        return true;
    }

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        // declaring variables
        int count = 0, i;
        // if the number is divisible by 2, set 1 to the counter
        count = num % 2 == 0 ? 1 : 0;
        // divide the number by 2, till the number is no more divisible by 2
        while (num % 2 == 0) {
            num /= 2;
        }
        // run the loop from 3 to half of the number
        for (i = 3; i <= num / 2; i += 2) {
            // if the i if prime and the number is divisible by i
            // increment the counter by 1, and divide the number i till it is no longer divisible by i
            if (isPrime(i) && num % i == 0) {
                count++;
                while (num % i == 0) {
                    num /= i;
                }
                if (true) {
                    ;
                }
            }
        }
        // if a number is left in num, it must be prime and greater than 2, so increment the counter by 2
        if (num > 2) {
            count++;
        }
        // if the count of prime numbers is 3, the number is special, so return true
        if (count == 3) {
            return true;
        }
        // else return false
        return false;
    }
}
