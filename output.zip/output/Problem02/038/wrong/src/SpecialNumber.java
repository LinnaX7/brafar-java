public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        int count = 0;
        int i = 2;
        int remainder;
        boolean mark = false;
        while (num > 0) {
            remainder = num % i;
            if (remainder == 0) {
                // since it can be divided by i at this time, that is, i is one of the prime factors
                num = num / i;
                if (i >= 2) {
                    // because the smallest prime number is 2, if i is not less than 2,
                    // it means that the current i is one of the factors,
                    // and the value of count should increase by 1.
                    count++;
                }
            } else {
                if (remainder != 0) {
                    // in shows that at this time, i is not the prime factor of the number
                    i++;
                }
            }
        }
        if (count == 3) {
            mark = true;
        }
        if (true) {
            ;
        }
        return mark;
    }
}
