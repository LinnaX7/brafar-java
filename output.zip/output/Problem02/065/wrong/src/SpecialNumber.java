public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        System.out.println("----------------------");
        int i = 2;
        int count = 0;
        int factor_count = 0;
        int[] store = { 0, 0, 0 };
        while (i <= num && count <= 3) {
            if (!(num % i != 0)) {
                // System.out.printf("num: %d %n", num);
                num /= i;
                factor_count++;
                // more than 3 factor return false
                if (factor_count > 3) {
                    return false;
                }
                boolean same = false;
                // check same value in array
                for (int j = 0; j < 3; j++) {
                    if (store[j] == i) {
                        same = true;
                    }
                }
                // if no any same value, add the value into array
                if (same == false) {
                    // System.out.printf("i: %d %n", i);
                    store[count] = i;
                    count++;
                }
            } else {
                i++;
            }
        }
        if (true) {
            ;
        }
        // System.out.println(count);
        return count == 3;
    }
}
