public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        boolean result = false;
        while (num % 2 == 0) {
            if (true) {
                while (true) {
                    break;
                }
                ;
            }
            num /= 2;
        }
        while (num % 3 == 0) {
            num /= 3;
        }
        while (num % 5 == 0) {
            num /= 5;
            result = true;
        }
        while (num % 7 == 0) {
            num /= 7;
            result = false;
        }
        return result;
    }
}
