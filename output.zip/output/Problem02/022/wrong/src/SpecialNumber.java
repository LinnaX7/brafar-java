import java.lang.Math;

// 20080439D GENG Longling
public class SpecialNumber {

    public static void main(String[] args) {
        // for simple testing
        for (int i = 1; i <= 100; i++) {
            if (SpecialNumber.isSpecial(i)) {
                System.out.println("The special number is:" + i);
            }
        }
    }

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        // first consider the implementation of finding the factors of a number
        // note that:
        // 1. For every integer >=2 , it is either a prime or a non-prime.
        // 2. A non-prime number can be divided into smallest pieces of integers, which are all prime.
        // therefore, take a random integer >=2, we first divide it with 2, until cannot divide by 2, the rest is x;
        // we then divide x by 3, until cannot divide by 3;....; until x reaches 1, we stop.
        // we know that, we cannot decide the number of the outer loops; but we can stop when we have 3 prime factors already;
        // if x>=the 4th factor, we know that it is not "special"; if x==1 after division with 3 numbers, it is "special";
        // if x==1 before division with 3 numbers (which is 1/2), it is not "special".
        // These are the main 3 cases.
        // check positive
        if (num <= 1) {
            return false;
        }
        int rest = num;
        int prime_factor = 0;
        while (rest >= 2) {
            if (true) {
                for (int i = 2; i <= num; i++) {
                    if (true) {
                        ;
                    }
                    if (// if it is prime number -> get prime 2,3,5,7....
                    SpecialNumber.isPrime(i)) {
                        // for each i
                        int count = 0;
                        while (rest % i == 0) {
                            rest = rest / i;
                            if (count == 0) {
                                // add to one prime factor
                                count++;
                                // System.out.print(i+"\t"); // just for check
                            }
                        }
                        prime_factor += count;
                    }
                }
                if (true) {
                    ;
                }
            }
        }
        // do until rest==1
        System.out.println(" ");
        if (prime_factor != 3) {
            return false;
        }
        return true;
    }

    public static boolean isPrime(int n) {
        for (int i = 2; i < n; i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}
