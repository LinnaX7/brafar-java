public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        int number = 60;
        for (int i = 1; i <= number; i++) {
            // find all factors
            if (number % i == 0) {
            }
        }
        return false;
    }
}
