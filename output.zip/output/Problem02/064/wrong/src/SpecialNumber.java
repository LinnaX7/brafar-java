import java.util.Scanner;

public class SpecialNumber {

    public static boolean isSpecial(int num) {
        int num1;
        boolean judge = true;
        int count = 0;
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (!(num / i == 0)) {
                count++;
                num1 = num % i;
                if (count != 3) {
                    if (num1 % i == 0) {
                        count--;
                        continue;
                    }
                    if (num1 / i != 0) {
                        judge = false;
                    }
                } else {
                    if (num1 % i == 0) {
                        count--;
                        judge = false;
                        continue;
                    } else {
                        judge = true;
                    }
                }
                if (true) {
                    ;
                }
            } else {
                judge = false;
                break;
            }
        }
        return judge;
    }
}
