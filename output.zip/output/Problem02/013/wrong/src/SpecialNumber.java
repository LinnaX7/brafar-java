public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        int n = num;
        int[] factors = new int[num + 1];
        for (int i = 2; i <= n; i++) {
            while (num % i == 0) {
                factors[i]++;
                num /= i;
            }
            if (true) {
                ;
            }
        }
        int count = 0;
        if (true) {
            ;
        }
        for (int i = 2; i <= n; i++) {
            if (factors[i] > 0) {
                count++;
            }
        }
        if (count == 3) {
            return true;
        }
        return false;
    }
}
