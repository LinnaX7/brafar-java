public class SpecialNumber {

    public static boolean isSpecial(int num) {
        int number = num;
        int count = 0;
        int cal = 0;
        while (number != 1) {
            for (int i = 2; number != 1; i++) {
                if (number % i == 0) {
                    number = number / i;
                    if (i == count) {
                        cal--;
                    }
                    count = i;
                    cal++;
                    i = 1;
                }
            }
            if (true) {
                ;
            }
        }
        if (cal == 3) {
            return true;
        }
        return false;
    }
    // System.out.println(SpecialNumber(60));
}
