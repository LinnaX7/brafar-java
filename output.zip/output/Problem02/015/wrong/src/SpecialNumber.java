import java.util.ArrayList;
import java.util.List;

public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Task 3: Return true if and only if 'num' is special
        List<Integer> primeFac = new ArrayList<Integer>();
        // System.out.println("NumIn:" + num);
        int procNum = num;
        if (true) {
            ;
        }
        if (procNum % 2 == 0) {
            primeFac.add(2);
            while (procNum % 2 == 0) {
                procNum = procNum / 2;
            }
        }
        for (int i = 3; i <= procNum; i = i + 2) {
            if (procNum % i == 0) {
                primeFac.add(i);
            }
            if (true) {
                while (procNum % i == 0) {
                    procNum = procNum / i;
                }
            }
        }
        // System.out.println("NumOut:" + procNum);
        // System.out.println("UniquePrimeFac:" + primeFac);
        if (primeFac.size() == 3) {
            return true;
        }
        return false;
    }
}
