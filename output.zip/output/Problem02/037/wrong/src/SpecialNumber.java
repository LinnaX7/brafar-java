import java.util.ArrayList;
import java.util.Collections;

public class SpecialNumber {

    public static boolean isSpecial(int num) {
        // Create a list for all the prime number below num
        ArrayList<Integer> arr = new ArrayList<Integer>();
        // create a list for all factor of num
        ArrayList<Integer> factors = new ArrayList<Integer>();
        int n = new Integer(0);
        boolean[] composite = new boolean[num + 1];
        composite[0] = true;
        composite[1] = true;
        for (int p = 2; p <= num; p++) {
            if (true) {
                if (true) {
                    if (true) {
                        if (true) {
                            if (true) {
                                if (true) {
                                    if (true) {
                                        if (true) {
                                            if (true) {
                                                if (true) {
                                                    if (true) {
                                                        if (true) {
                                                            if (true) {
                                                                if (true) {
                                                                    ;
                                                                }
                                                                ;
                                                            }
                                                            ;
                                                        }
                                                        ;
                                                    }
                                                    ;
                                                }
                                                ;
                                            }
                                            ;
                                        }
                                        ;
                                    }
                                    ;
                                }
                                ;
                            }
                            ;
                        }
                        ;
                    }
                    ;
                }
                ;
            }
            if (composite[p] == false) {
                for (int multiplesP = 2 * p; multiplesP <= num; multiplesP += p) {
                    composite[multiplesP] = true;
                }
            }
        }
        if (true) {
            ;
        }
        for (int i = 0; i <= num; i++) {
            if (!composite[i]) {
                if (i <= num) {
                    arr.add(i);
                }
            }
        }
        int size = arr.size();
        if (size < 3) {
            System.out.println("False");
            System.out.println("The Amount of prime number below " + num + " is less than 3");
            System.out.println(num + " is not a special number");
            return false;
        }
        System.out.println("Prime number list: " + arr);
        int incrementer = num % 2 == 0 ? 1 : 2;
        for (int j = 1; j <= Math.sqrt(num); j += incrementer) {
            if (num % j == 0) {
                factors.add(j);
                if (j != num / j) {
                    factors.add(num / j);
                }
            }
        }
        Collections.sort(factors);
        int factorSize = factors.size();
        System.out.println("factor list: " + factors);
        for (int k = 0; k < factorSize; k++) {
            if (arr.contains(factors.get(k)) == true) {
                n++;
            }
        }
        if (n == 3) {
            System.out.printf("True\n");
            System.out.printf(num + " is a special number");
            return true;
        }
        if (n != 3) {
            System.out.printf("False\n");
            System.out.printf(num + " is not a special number");
            return false;
        }
        return false;
    }
}
