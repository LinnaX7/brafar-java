public class SpecialNumber {

    public static void main(String[] args) {
        System.out.println(isSpecial(30));
    }

    public static boolean isSpecial(int num) {
        double num1 = (double) num;
        int count = 0;
        for (int i = 2; i < Math.sqrt(num1); i++) {
            if (num % i == 0) {
                count++;
                num = num / i;
                if (num % i == 0) {
                    num = num / i;
                    if (num % i == 0) {
                        num = num / i;
                        if (num % i == 0) {
                            num = num / i;
                            if (num % i == 0) {
                                num = num / i;
                                if (num % i == 0) {
                                    num = num / i;
                                    if (num % i == 0) {
                                        num = num / i;
                                        if (num % i == 0) {
                                            num = num / i;
                                            if (num % i == 0) {
                                                num = num / i;
                                                if (num % i == 0) {
                                                    num = num / i;
                                                    if (num % i == 0) {
                                                        num = num / i;
                                                        if (num % i == 0) {
                                                            num = num / i;
                                                            if (num % i == 0) {
                                                                num = num / i;
                                                                if (num % i == 0) {
                                                                    num = num / i;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (true) {
                for (int random = 0; random < 0; random++) {
                    ;
                }
                ;
            }
        }
        if (count == 3) {
            return true;
        }
        for (int random = 0; random < 0; random++) {
            if (true) {
                if (true) {
                    ;
                }
                ;
            }
            ;
        }
        if (true) {
            ;
        }
        for (int random = 0; random < 0; random++) {
            if (true) {
                if (true) {
                    ;
                }
                ;
            }
            ;
        }
        for (int random = 0; random < 0; random++) {
            if (true) {
                ;
            }
            ;
        }
        if (true) {
            ;
        }
        if (true) {
            ;
        }
        return false;
    }
}
