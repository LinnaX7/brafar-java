import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        String n = "";
        boolean isNegative = false;
        if (num < 0) {
            isNegative = true;
            num *= (-1);
        }
        for (int i = num; i != 0; i /= 7) {
            n = String.valueOf(i % 7) + n;
        }
        if (isNegative) {
            n = "-" + n;
        }
        return n;
    }
}
