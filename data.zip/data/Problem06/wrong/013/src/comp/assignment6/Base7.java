package comp.assignment6;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        int e;
        int y = num;
        String str = "";
        char[] ch = { '0', '1', '2', '3', '4', '5', '6' };
        boolean neg = false;
        if (y < 0) {
            neg = true;
            y = y * -1;
        }
        while (y != 0) {
            e = y % 7;
            str = ch[e] + str;
            y = y / 7;
        }
        if (neg == true) {
            str = "-" + str;
        }
        return str;
    }
}
