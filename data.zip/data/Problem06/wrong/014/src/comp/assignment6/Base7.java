package comp.assignment6;

import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        long Max = 1000_000_000L;
        int ji = 0;
        boolean flag = true;
        String ans = "";
        if (num < 0) {
            flag = false;
            num = num * -1;
        }
        for (int i = 0; i < Max; i++) {
            if (num < Math.pow(7, i)) {
                ji = i - 1;
                break;
            }
        }
        for (int i = ji; i >= 0; i--) {
            ans = num % 7 + ans;
            num = num / 7;
        }
        if (flag == false) {
            ans = "-" + ans;
        }
        return ans;
    }
}
