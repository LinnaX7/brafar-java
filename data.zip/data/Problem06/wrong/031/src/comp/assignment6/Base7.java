package comp.assignment6;

public class Base7 {

    public static String convertToBase7(int num) {
        String result = "";
        boolean positive = num > 0;
        while (num != 0) {
            result = String.valueOf(Math.abs(num % 7)) + result;
            num /= 7;
        }
        return positive ? result : "-" + result;
    }
}
