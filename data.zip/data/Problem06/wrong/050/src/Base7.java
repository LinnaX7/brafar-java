public class Base7 {

    public static String convertToBase7(int input) {
        if (input < 0) {
            input = input * (-1);
        }
        String result = "";
        String remain = "";
        while (input >= 7) {
            remain = String.valueOf(input % 7);
            input = input / 7;
            result = remain + result;
        }
        String number = String.valueOf(input);
        result = number + result;
        if (input >= 0) {
            return result;
        }
        result = "-" + result;
        return result;
    }

    public static void main(String[] args) {
        String a = convertToBase7(7);
        System.out.println(a);
    }
}
