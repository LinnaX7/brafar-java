public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        int remainder = 0, count = 0;
        String temp = "";
        Boolean IsNot0 = true;
        String ans = "", ans2 = "";
        char ans1;
        if (num == 0) {
            ans = "0";
        }
        if (num < 0) {
            ans = "-";
            num *= -1;
        }
        while (IsNot0) {
            if (num / 7 != 0) {
                temp = temp + String.valueOf(num % 7);
                num /= 7;
            } else {
                temp = temp + String.valueOf(num % 7);
                IsNot0 = false;
            }
        }
        for (int i = 0; i < temp.length(); i++) {
            ans1 = temp.charAt(i);
            ans2 = ans1 + ans2;
        }
        return ans + ans2;
    }
}
