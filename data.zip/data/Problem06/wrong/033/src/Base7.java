import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        String modulo = "";
        String base7 = "";
        boolean negative = false;
        if (num < 0) {
            negative = true;
            num = -num;
        }
        while (num != 0) {
            modulo += (char) ('0' + num % 7);
            num /= 7;
        }
        if (negative == true) {
            modulo += '-';
        }
        for (int i = modulo.length() - 1; i >= 0; i--) {
            base7 += modulo.charAt(i);
        }
        return base7;
    }
}
