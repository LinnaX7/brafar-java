package comp.assignment6;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        boolean ne = num <= 0;
        if (ne) {
            num *= -1;
        }
        String remainder = "";
        while (num != 0) {
            remainder = num % 7 + remainder;
            num = num / 7;
        }
        if (ne) {
            return "-" + remainder;
        }
        return remainder;
    }
}
