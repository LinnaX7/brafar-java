import java.util.Scanner;

public class Base7 {

    public static String convertToBase7(int A) {
        int B;
        int C;
        String D = "";
        if (A < 0) {
            C = -A;
        } else {
            C = A;
        }
        while (C != 0) {
            B = C % 7;
            C /= 7;
            D = String.valueOf(B) + D;
        }
        if (A > 0) {
            return D;
        }
        return "-" + D;
    }

    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);
        System.out.println("please type your number");
        int number = num.nextInt();
        System.out.println(convertToBase7(number));
    }
}
