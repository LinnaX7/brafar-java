import java.util.Arrays;
import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        // assume the length of array
        int[] a = new int[100];
        int number = 0;
        if (num < 0) {
            number = Math.abs(num);
        }
        // to initialize a String
        String str = "";
        if (num < 0) {
            str += "-";
        }
        int i = 0;
        // to go through the whole array
        while (num > 0) {
            a[i] = num % 7;
            num = num / 7;
            i++;
        }
        /*the same as above,
         but operations below are performed on num we test less than 0
         */
        while (number > 0) {
            a[i] = number % 7;
            number = number / 7;
            i++;
        }
        // add integers into String
        for (int m = i - 1; m >= 0; m--) {
            str += a[m];
        }
        return str;
    }
}
