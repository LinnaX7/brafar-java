package comp.assignment6;

import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        String a = "";
        if (num >= 0) {
            while (num != 0) {
                a = num % 7 + a;
                num = num / 7;
            }
        } else {
            num = -num;
            while (num != 0) {
                a = num % 7 + a;
                num = num / 7;
            }
            a = "-" + a;
        }
        return a;
    }
}
