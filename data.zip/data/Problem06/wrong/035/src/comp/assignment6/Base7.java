package comp.assignment6;

public class Base7 {

    public static String convertToBase7(int num) {
        String remainer = "";
        if (num < 0) {
            num *= -1;
            while (num != 0) {
                remainer = num % 7 + remainer;
                num = num / 7;
            }
            remainer = '-' + remainer;
        } else {
            while (num != 0) {
                remainer = num % 7 + remainer;
                num = num / 7;
            }
        }
        return remainer;
    }
}
