import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        int a = 0;
        int t = num;
        String result = "";
        String x = "";
        if (t < 0) {
            t = t * -1;
            while (true) {
                a = t % 7;
                t = t / 7;
                x = String.valueOf(a);
                result = x + result;
                if (t < 1) {
                    result = "-" + result;
                    break;
                }
            }
        }
        if (t > 0) {
            while (true) {
                a = t % 7;
                t = t / 7;
                x = String.valueOf(a);
                result = x + result;
                if (t < 1) {
                    break;
                }
            }
        }
        return result;
    }
}
