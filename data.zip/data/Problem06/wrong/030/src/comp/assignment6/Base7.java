package comp.assignment6;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        int ex = num;
        String str = "";
        char[] c = new char[] { '0', '1', '2', '3', '4', '5', '6' };
        boolean n = false;
        if (num < 0) {
            n = true;
            ex = num * -1;
        }
        while (ex != 0) {
            int e = ex % 7;
            str = c[e] + str;
            ex /= 7;
        }
        if (n) {
            str = "-" + str;
        }
        return str;
    }
}
