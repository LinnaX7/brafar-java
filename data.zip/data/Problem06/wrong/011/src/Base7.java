import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        int sum = 0;
        String result = "";
        boolean flag = false;
        if (num < 0) {
            num *= -1;
            flag = true;
        }
        if (num >= 0) {
            for (int j = num; j >= 1; j /= 7) {
                if (j % 7 == 0) {
                    sum = 0;
                } else {
                    sum = j % 7;
                }
                result = sum + result;
            }
        } else {
        }
        return flag == true ? "-" + result : result;
    }
}
