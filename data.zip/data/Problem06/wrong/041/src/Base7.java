public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        int remainder;
        String retValue = "";
        boolean negative = false;
        if (num < 0) {
            negative = true;
            num *= -1;
        }
        while (num != 0) {
            remainder = num % 7;
            retValue = remainder + retValue;
            num = num / 7;
        }
        if (negative) {
            retValue = "-" + retValue;
        }
        return retValue;
    }
}
