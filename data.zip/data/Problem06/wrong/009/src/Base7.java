public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        int quotient = 0;
        quotient = num;
        int remainder;
        String result = null;
        String str2 = "";
        for (int i = 0; quotient != 0; i++) {
            if (quotient < 0) {
                remainder = quotient % 7 * -1;
                quotient = quotient / 7;
                String str1 = String.valueOf(remainder);
                result = str1 + str2;
                str2 = result;
            } else {
                remainder = quotient % 7;
                quotient = quotient / 7;
                String str1 = String.valueOf(remainder);
                result = str1 + str2;
                str2 = result;
            }
        }
        if (num < 0) {
            result = "-" + result;
        }
        return result;
    }
}
