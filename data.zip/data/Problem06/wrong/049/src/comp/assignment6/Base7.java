package comp.assignment6;

public class Base7 {

    public static String convertToBase7(int num) {
        int[] base7 = new int[1000];
        int index = 0;
        int num2 = num;
        String output = "";
        if (num < 0) {
            num = num / -1;
        }
        while (num > 0) {
            base7[index] = num % 7;
            num = num / 7;
            index++;
        }
        if (num2 > 0) {
            for (int i = index - 1; i >= 0; i--) {
                output = output + base7[i];
            }
        } else {
            output = output + "-";
            for (int i = index - 1; i >= 0; i--) {
                output = output + base7[i];
            }
        }
        return output;
    }
}
