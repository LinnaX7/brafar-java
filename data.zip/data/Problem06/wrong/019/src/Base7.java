import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        String ans = new String();
        int tmp = num > 0 ? num : -num;
        while (tmp != 0) {
            ans = String.valueOf(tmp % 7) + ans;
            tmp /= 7;
        }
        if (num < 0) {
            ans = '-' + ans;
        }
        return ans;
    }
}
