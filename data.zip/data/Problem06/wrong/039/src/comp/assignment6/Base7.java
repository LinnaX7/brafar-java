package comp.assignment6;

public class Base7 {

    public static String convertToBase7(int num) {
        int digit = 0;
        int total = 0;
        String temp = String.valueOf(num);
        boolean Negative = num < 0;
        // count digit
        do digit++; while (num / Math.pow(10, digit) >= 10 || num / Math.pow(10, digit) <= -10);
        for (int i = digit; i >= 0; i--) {
            if (num / 7 < 7) {
                total += num;
            } else {
                total += num % 7 * Math.pow(7, i);
            }
        }
        if (Negative) {
            total = -total;
        }
        String numString = String.valueOf(total);
        return numString;
    }
}
