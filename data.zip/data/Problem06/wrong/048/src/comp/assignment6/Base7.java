package comp.assignment6;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        boolean negative = false;
        if (num < 0) {
            num *= -1;
            negative = true;
        }
        String remainder = "";
        while (num != 0) {
            remainder = String.valueOf(num % 7) + remainder;
            num /= 7;
        }
        if (negative == true) {
            remainder = "-" + remainder;
        }
        return remainder;
    }
}
