package comp.assignment6;

import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        String cal = "";
        int quotient, remainder;
        char number;
        boolean net = false;
        if (num < 0) {
            net = true;
            num = num * -1;
        }
        while (num != 0) {
            remainder = num % 7;
            cal += remainder;
            num = num / 7;
        }
        String ans = "";
        for (int i = 0; i < cal.length(); i++) {
            number = cal.charAt(i);
            ans = number + ans;
        }
        if (net) {
            return "-" + ans;
        }
        return ans;
    }
}
