package comp.assignment6;

import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        String out = "";
        boolean neg = false;
        if (num < 0) {
            num *= -1;
            neg = true;
        }
        while (num != 0) {
            out = String.valueOf(num % 7) + out;
            num = num / 7;
        }
        if (neg) {
            out = "-" + out;
        }
        return out;
    }
}
