import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        /*
            Implemented by HAOLIN ZHANG <21107569d@connect.polyu.hk>
        */
        String res = "";
        boolean negFlag = false;
        // Check sign
        if (num < 0) {
            negFlag = true;
            num = num * -1;
        }
        // Convert
        int tmpValue = num;
        while (tmpValue > 0) {
            // Get sub string
            int tmpDigit = tmpValue % 7;
            String tmpStr = String.valueOf(tmpDigit);
            res = tmpStr + res;
            // Update Value
            tmpValue /= 7;
        }
        if (negFlag) {
            res = "-" + res;
        }
        return res;
    }
}
