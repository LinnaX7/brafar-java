package comp.assignment6;

import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        int temp, remainder;
        String sign = "", base7 = "";
        temp = num;
        if (num < 0) {
            temp = num * -1;
            sign = "-";
        }
        while (temp > 0) {
            remainder = temp % 7;
            temp = temp / 7;
            base7 = String.valueOf(remainder) + base7;
        }
        base7 = sign + base7;
        return base7;
    }
}
