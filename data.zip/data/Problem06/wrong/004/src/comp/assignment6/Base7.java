package comp.assignment6;

import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        String result = "", temp;
        boolean isNegative = false;
        while (num != 0) {
            if (num < 0) {
                isNegative = true;
                num *= -1;
            }
            temp = num % 7 + "";
            result = temp + result;
            num /= 7;
        }
        if (isNegative) {
            result = "-" + result;
        }
        return result;
    }
}
