package comp.assignment6;

import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        int[] list = new int[10];
        int i = 0, j = 1;
        int temp = num;
        while (temp >= 7) {
            // this loop find temp%7 values and store them in the array
            if (j == 1) {
                list[i] = num % 7;
            }
            if (j > 1) {
                list[i] = temp % 7;
            }
            temp = num / 7;
            i++;
            j++;
        }
        list[i] = temp % 7;
        int b = 0;
        for (int a = i; a >= 0; a--) {
            if (a != 0) {
                b += list[a] * Math.pow(10, a);
            } else {
                b += list[a];
            }
        }
        System.out.println(b);
        String str = b + "";
        System.out.println(str);
        return str;
    }
}
