package comp.assignment6;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        String result = "";
        if (num > 0) {
            while (num > 0) {
                int temp = num % 7;
                num = num / 7;
                result = temp + result;
            }
        } else {
            while (num < 0) {
                int temp = num % 7 * -1;
                num = num / 7;
                result = temp + result;
            }
            result = "-" + result;
        }
        return result;
    }
}
