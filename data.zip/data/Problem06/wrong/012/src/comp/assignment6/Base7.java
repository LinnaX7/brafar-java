package comp.assignment6;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        int x = num, r;
        String retstr = "";
        char[] ch = { '0', '1', '2', '3', '4', '5', '6' };
        boolean neg = false;
        if (x < 0) {
            neg = true;
            x = x * -1;
        }
        while (x != 0) {
            r = x % 7;
            retstr = ch[r] + retstr;
            x = x / 7;
        }
        if (neg == true) {
            retstr = "-" + retstr;
        }
        return retstr;
    }
}
