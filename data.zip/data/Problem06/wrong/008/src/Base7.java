import java.util.Stack;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        int x;
        String ret = "";
        Stack<Integer> stack = new Stack<>();
        if (num < 0) {
            num = -num;
            ret += '-';
        }
        while (num > 0) {
            x = num % 7;
            stack.push(x);
            num /= 7;
        }
        while (!stack.empty()) {
            ret += stack.pop();
        }
        return ret;
    }
}
