package comp.assignment6;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        // Create an empty string for base-7 representation
        String result = "";
        int test = 0;
        if (num < 0) {
            // When num is a negative integer, the variable test become 1 and num become its
            // absolute value.
            test = 1;
            // The purpose of using test is to remind the program whether it is a negative number.
            num = num * -1;
        }
        // If yes, and finally it need to add '-' in fornt of the string result.
        while (num > 0) {
            // find the remainder after the num divided by 7
            int remainder = num % 7;
            // divide the num by 7. Since it is integer type, it will not have decimal number.
            num = num / 7;
            // add the remainder value to the result.
            result = remainder + result;
        }
        if (test == 1) {
            // IF test = 1, then a negative symbol is added in fornt of the result.
            result = "-" + result;
        }
        return result;
    }
}
