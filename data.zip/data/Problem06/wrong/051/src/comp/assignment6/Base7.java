package comp.assignment6;

public class Base7 {

    public static String convertToBase7(int num) {
        String result = "";
        String remain = "";
        if (num > 0) {
            while (num >= 7) {
                remain = String.valueOf(num % 7);
                num = num / 7;
                result = remain + result;
            }
            return String.valueOf(num) + result;
        }
        while (-num >= 7) {
            remain = String.valueOf((-num) % 7);
            num = (-num) / 7;
            result = remain + result;
        }
        return String.valueOf(-num) + result;
    }
}
