package comp.assignment6;

import java.util.Arrays;
import static java.lang.Math.abs;
import static java.lang.Math.pow;

public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        // array to store base7 number
        int[] arr = new int[1000];
        // counter for base 7 array
        int i = 0;
        int number = 0;
        // Check if the number is a negative number
        if (num < 0) {
            // absolute value
            number = Math.abs(num);
        }
        while (num > 0) {
            // storing remainder in base 7 array
            arr[i] = num % 7;
            num /= 7;
            i++;
        }
        while (number > 0) {
            // storing remainder in base 7 array
            arr[i] = number % 7;
            number /= 7;
            i++;
        }
        String str = "";
        // if it is a negative number, add the negative sign before it
        if (num < 0) {
            str = "-";
        }
        // printing array in reverse order
        for (int j = i - 1; j >= 0; j--) {
            str += arr[j];
        }
        return str;
    }
}
