public class Base7 {

    public static String convertToBase7(int num) {
        // TODO: Add your code here
        String result = "";
        if (num > 0) {
            while (num > 0) {
                result = num % 7 + result;
                num /= 7;
            }
        } else {
            num *= -1;
            while (num > 0) {
                result = num % 7 + result;
                num /= 7;
            }
            result = '-' + result;
        }
        return result;
    }
}
