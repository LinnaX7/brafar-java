# Assignment 6: Base7

---
Given an integer value $X$, you need to return the base-7 representation of $X$ as a string. In a base-7 representation, each digit is between 0 and 6, both inclusive, and the value of a digit is based on its position in the representation. For example, given a base-7 representation $r_1 = (d_n...d_3d_2d_1d_0)_7$ $(0\leq d_i \leq 6, 0\leq i \leq n)$, the decimal value of $r_1$ is calculated as $d_n*7^n + ... + d_3*7^3+d_2*7^2+d_1*7^0$.

**What to do:** In Base7.java

[Task] Complete method <font color=' #A52A2A '>convertToBase7</font> in class <font color=' #A52A2A '>Base7</font> so that the method will take an <font style="background-color: #e0e0e0;">int</font> value as the argument and return the <font style="background-color: #e0e0e0;">String</font> representation of the argument based on 7. For example, when the input value is 100, the method should return a string “202”.
