# Assignment 1: Floating Point Vs. Integer Numbers

---
Suppose we have a new data type called <font style="background-color: #e0e0e0;">miniFloat</font>, which is like <font style="background-color: #e0e0e0;">float</font> but uses only eight bits. From left to right, the meaning of the bits is as the following:

* 1 bit for the sign: 0 for positive values and 1 for negative values;
* 4 bits in two’s complement for the exponent;
* 3 bits for the mantissa;

Consider for example a <font style="background-color: #e0e0e0;">miniFloat</font> value with bit sequence <font style="background-color: #e0e0e0;">00100110</font>. The value is positive (0), the exponent is $4_{10}$(= $0100_2$), and the significand is $1.75_{10}$ (=$1.110_2$). Therefore, the whole value is 1.75x$2^4$ =28.

**What to do:** In MiniFloat.java

[Task] Complete method <font color=' #A52A2A '>miniFloatFromString</font> in class <font color=' #A52A2A '>MiniFloat</font>; Method <font color=' #A52A2A '>miniFloatFromString</font> takes a String of eight characters, each being ‘1’ or ‘0’, and returns the value of the corresponding miniFloat (as a float value).
