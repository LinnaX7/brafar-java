package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        char[] charBitSequence = bitSequence.toCharArray();
        int positive = Integer.parseInt(String.valueOf(charBitSequence[0]));
        /* Binary to decimal,get the value of significand and exponent. */
        float significand = 1 + (float) Math.pow(2, -1) * Integer.parseInt(String.valueOf(charBitSequence[5])) + (float) Math.pow(2, -2) * Integer.parseInt(String.valueOf(charBitSequence[6])) + (float) Math.pow(2, -3) * Integer.parseInt(String.valueOf(charBitSequence[7]));
        int exponent = (int) Math.pow(2, 0) * Integer.parseInt(String.valueOf(charBitSequence[4])) + (int) Math.pow(2, 1) * Integer.parseInt(String.valueOf(charBitSequence[3])) + (int) Math.pow(2, 2) * Integer.parseInt(String.valueOf(charBitSequence[2])) + (int) Math.pow(2, 3) * Integer.parseInt(String.valueOf(charBitSequence[1]));
        float minifloatvalue = (int) Math.pow(-1, positive) * significand * (int) Math.pow(2, exponent);
        return minifloatvalue;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        /* Initialize the integer "number" as the number of the integral miniFloat values. */
        int number = 0;
        String[] result = getValidMiniFloatBitSequences();
        int totalNum = result.length;
        /* Use a for loop to check one by one if the minifloat is an integer. */
        for (int i = 0; i < totalNum; i++) {
            float miniFloat = miniFloatFromString(result[i]);
            String strMiniFloat = String.valueOf(miniFloat);
            String[] str = strMiniFloat.split("\\.");
            int decimalDigits = str[1].length();
            if (decimalDigits == 1)
                if (str[1].equals("0")) {
                    number++;
                }
        }
        System.out.print(number);
        return number;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
