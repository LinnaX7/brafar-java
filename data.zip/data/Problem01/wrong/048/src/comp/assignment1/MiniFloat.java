package comp.assignment1;

public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // select the 4 bits for exponent and calculate
        String e = bitSequence.substring(1, 5);
        int e2 = Integer.parseInt(e, 2);
        // calculate the significant
        float sig = (float) (1 + ((int) (bitSequence.charAt(5)) - 48) * 0.5 + (((int) (bitSequence.charAt(6)) - 48) * 0.25) + (((int) (bitSequence.charAt(7)) - 48) * 0.125));
        // calculate the value, find out is positive or negative
        float value = sig * (1 << e2);
        if (((int) (bitSequence.charAt(0)) - 48 == 0)) {
            value = value * 1;
        } else {
            value = value * -1;
        }
        return value;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            if (String.valueOf(miniFloatFromString(s)).contains(".0")) {
                count++;
            } else {
                continue;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
