public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int sign = bitSequence.charAt(0) == '0' ? 1 : -1;
        float exponent = Integer.parseInt(bitSequence.substring(1, 5), 2);
        String mantissa = bitSequence.substring(5, 8);
        int get;
        int pow = -1;
        float sum = .0f;
        for (int i = 0; i < mantissa.length(); i++) {
            get = Integer.parseInt(String.valueOf(mantissa.charAt(i)), 10);
            sum = (float) (sum + get * Math.pow(2, pow));
            pow--;
        }
        float significand = 1.0f + sum;
        return (float) (sign * significand * Math.pow(2, exponent));
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] array = getValidMiniFloatBitSequences();
        int count = 0;
        for (int i = 0; i < array.length; i++) {
            float check = miniFloatFromString(array[i]);
            if (Math.floor(check) == check) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
