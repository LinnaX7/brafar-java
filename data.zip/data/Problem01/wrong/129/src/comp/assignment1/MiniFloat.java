package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // find sign bit 1 / 0
        int sign = Character.getNumericValue(bitSequence.charAt(0));
        // find exponent in decimal
        int exponent = Integer.parseInt(bitSequence.substring(1, 5), 2);
        // find the 3 digits of mantissa in binary
        char[] mantissa = bitSequence.substring(5, 8).toCharArray();
        // calculate the value of mantissa in decimal
        float fraction = (float) (Math.pow(2, -1) * Character.getNumericValue(mantissa[0]) + Math.pow(2, -2) * Character.getNumericValue(mantissa[1]) + Math.pow(2, -3) * Character.getNumericValue(mantissa[2]));
        // calculate the value of float
        return (float) (Math.pow(-1, sign) * Math.pow(2, exponent) * (1 + fraction));
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        // get all valid miniFloat values
        String[] miniFloatBitSequences = getValidMiniFloatBitSequences();
        // int to count the number of integral miniFloat values
        int num = 0;
        // loop through each miniFloat
        for (String miniFloatBS : miniFloatBitSequences) {
            // generate decimal value of miniFloat
            float miniFloatTemp = MiniFloat.miniFloatFromString(miniFloatBS);
            // check if it is integer
            if (((int) miniFloatTemp) == miniFloatTemp) {
                num++;
            }
        }
        return num;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
