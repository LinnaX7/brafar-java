public class MiniFloat {

    public static void main(String[] args) {
        // printIntegralMiniFloats();
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        double exp1, exp, sig;
        String[] bitArray = bitSequence.split("");
        int[] BinaryArray = new int[8];
        for (int i = 0; i < 8; i++) {
            BinaryArray[i] = Integer.parseInt(bitArray[i]);
        }
        exp1 = BinaryArray[4] + BinaryArray[3] * 2 + BinaryArray[2] * 4 + BinaryArray[1] * 8;
        exp = Math.pow(2, exp1);
        sig = 1 + (BinaryArray[7] * 0.125 + BinaryArray[6] * 0.25 + BinaryArray[5] * 0.5);
        if (BinaryArray[0] == 1) {
            sig = sig * (-1);
        }
        return (float) (exp * sig);
    }

    public static boolean isInt(float a) {
        int b = (int) a;
        float c = a - b;
        if (c != 0)
            return false;
        return true;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            if (isInt(miniFloatFromString(s))) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
