package comp.assignment1;

public class MiniFloat {

    public static double output = 0;

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        double sign;
        double exponent;
        double mantissa;
        double ans;
        sign = ((double) bitSequence.charAt(0) - 48) * (-2) + 1;
        exponent = ((double) bitSequence.charAt(1) - 48) * Math.pow(2, 3) + ((double) bitSequence.charAt(2) - 48) * Math.pow(2, 2) + ((double) bitSequence.charAt(3) - 48) * Math.pow(2, 1) + ((double) bitSequence.charAt(4) - 48);
        mantissa = 1 + ((double) bitSequence.charAt(5) - 48) * Math.pow(2, -1) + ((double) bitSequence.charAt(6) - 48) * Math.pow(2, -2) + ((double) bitSequence.charAt(7) - 48) * Math.pow(2, -3);
        ans = sign * (mantissa * Math.pow(2, exponent));
        output = ans;
        return (float) ans;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int num = 0;
        if ((output % 1) == 0) {
            num += 1;
        }
        return num;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
