package comp.assignment1;

import java.util.Scanner;

public class MiniFloat {

    public static float miniFloatFromString(String s) {
        char[] arr = s.toCharArray();
        float[] result = new float[8];
        for (int j = 0; j < 8; j++) {
            result[j] = Integer.parseInt(String.valueOf(arr[j]), 10);
        }
        float exponent = result[4] * 1 + result[3] * 2 + result[2] * 4 + result[1] * 8;
        float significand = (float) (1 + result[5] * 0.5 + result[6] * 0.25 + result[7] * 0.125);
        int temp = 1;
        for (int m = 0; m < exponent; m++) {
            temp *= 2;
        }
        float value = (float) (temp * significand);
        if (result[0] == 0) {
            return value;
        }
        return -1 * value;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        String[] sequences = getValidMiniFloatBitSequences();
        for (int i = 0; i < sequences.length; i++) {
            String s = sequences[i];
            float miniFloat = miniFloatFromString(s);
            if (miniFloat == (int) miniFloat) {
                System.out.println(s + " == " + miniFloat);
                count += 1;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
