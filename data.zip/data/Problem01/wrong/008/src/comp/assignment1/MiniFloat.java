package comp.assignment1;

import java.lang.Math;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // string to char array converter from GeeksforGeeks
        char[] bit = new char[bitSequence.length()];
        for (int i = 0; i < bitSequence.length(); i++) {
            bit[i] = bitSequence.charAt(i);
        }
        // Task 1: compute the miniFloat value from "bitSequence";
        boolean positive = false;
        if (bit[0] == '0') {
            positive = true;
        }
        int exponent = 0;
        for (int i = 1; i < 5; i++) {
            if (bit[i] == '1') {
                exponent += (int) Math.pow((double) 2, (double) (4 - i));
            }
        }
        double significand = 1;
        int signBit = 1;
        for (int i = 5; i < 8; i++) {
            if (bit[i] == '1') {
                significand = Math.pow((double) 0.5, (double) signBit) + significand;
            }
            signBit++;
        }
        int multiply = (int) Math.pow((double) 2, (double) exponent);
        double result = significand * multiply;
        if (!positive) {
            result *= -1;
        }
        return (float) result;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] str = getValidMiniFloatBitSequences();
        int count = 0;
        for (int i = 0; i < str.length; i++) {
            if (isIntegralMiniFloat(str[i])) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static boolean isIntegralMiniFloat(String miniFloat) {
        float result = miniFloatFromString(miniFloat);
        if (result % 1 == 0) {
            return true;
        }
        return false;
    }
}
