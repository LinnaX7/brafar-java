package comp.assignment1;

import java.util.Scanner;

public class MiniFloat {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter 8 digits with only 0 or 1: ");
        String x = scanner.nextLine();
        float x2 = miniFloatFromString(x);
        System.out.println("miniFloat is " + x2);
        System.out.println("The number of integers = " + numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String Bitsequence) {
        int sign = Bitsequence.charAt(0) - '0';
        String x = Bitsequence.substring(1, 5);
        int exponent = Integer.parseInt(x, 2);
        String x2 = Bitsequence.substring(5, 8);
        double mantissa = 0;
        for (int i = 0; i < 3; i++) {
            double x7 = x2.charAt(i) - '0';
            x7 = x7 / Math.pow(2, i + 1);
            mantissa = mantissa + x7;
        }
        float calculation = (1 + (float) mantissa) * (float) Math.pow(2, exponent);
        if (sign == 1) {
            calculation = calculation * (-1);
        }
        return calculation;
    }

    public static String[] getValidMiniFloatBitSequences() {
        String[] arr = new String[256];
        for (int i = 0; i < 256; i++) {
            String y = Integer.toBinaryString(i);
            int u = Integer.parseInt(y, 10);
            String x = String.format("%08d", u);
            arr[i] = x;
        }
        return arr;
    }

    public static int numIntegralMiniFloats() {
        String[] array = getValidMiniFloatBitSequences();
        int counter = 0;
        for (int i = 0; i < 256; i++) {
            float x = miniFloatFromString(array[i]);
            if (x % 1 == 0) {
                counter = counter + 1;
            }
        }
        return counter;
    }
}
