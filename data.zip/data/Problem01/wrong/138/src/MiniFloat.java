public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // assign variables
        float sign, exponent = 0, mantissa = 0, power;
        // find sign using if else
        if (bitSequence.charAt(0) != '1') {
            sign = 1f;
        } else {
            sign = -1f;
        }
        // find exponent by using loop for
        // use power to convert from binary to decimal
        power = 3f;
        for (int i = 1; i <= 4; i++) {
            if (bitSequence.charAt(i) == '1') {
                exponent += (float) Math.pow(2, power);
            }
            power--;
        }
        // find mantissa by using loop for
        power = -1f;
        for (int i = 5; i <= 7; i++) {
            if (bitSequence.charAt(i) == '1') {
                mantissa += (float) Math.pow(2, power);
            }
            power--;
        }
        mantissa += 1;
        float miniFloat = 1;
        miniFloat = (float) sign * mantissa * (float) Math.pow(2, exponent);
        return miniFloat;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] arrayofminiFloats = getValidMiniFloatBitSequences();
        int cnt = 0;
        for (int i = 0; i < 256; i++) {
            float miniFloat = miniFloatFromString(arrayofminiFloats[i]);
            int tmp = (int) miniFloat;
            if (tmp == miniFloat) {
                cnt += 1;
            }
        }
        return cnt;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
