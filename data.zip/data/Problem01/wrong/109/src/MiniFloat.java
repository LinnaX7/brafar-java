// 20050394d Lau Sin Man (Task 1, 2)
public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        char[] conversion = bitSequence.toCharArray();
        // set user input as invalid by default
        boolean validInput = false;
        if (bitSequence.length() == MINI_FLOAT_SIZE) {
            // only 8 characters are accepted for valid input
            for (int i = 0; i < bitSequence.length(); i++) {
                if (conversion[i] == '0' || conversion[i] == '1') {
                    // check if the string contains only '0' or '1'
                    validInput = true;
                    break;
                }
            }
        }
        if (validInput) {
            // convert to miniFloat when input is proved valid
            // convert part of the character array into string for exponent part
            String exp = String.copyValueOf(conversion, 1, 4);
            // conversion to decimal value (using two's complement)
            int exponent = Integer.parseInt(exp, 2);
            String m = String.copyValueOf(conversion, 5, 3);
            float mantissa = Integer.parseInt(m, 2) / (float) 8.0;
            float significand = 1 + mantissa;
            float result = (float) (significand * (Math.pow(2, exponent)));
            if (conversion[0] == '1') {
                // conversion[0] is the sign bit, if it's '1', the result will be negative
                result = -result;
            }
            return result;
        }
        // output printed out for invalid user input
        System.out.println("Invalid input!");
        return 0;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            if (miniFloatFromString(s) == (int) miniFloatFromString(s)) {
                // if the miniFloat value is integer, count increases by 1
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static final int MINI_FLOAT_SIZE = 8;
}
