public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int[] list = new int[8];
        for (int i = 0; i < 8; i++) {
            list[i] = bitSequence.charAt(i) == '1' ? 1 : 0;
        }
        float ind = .0f;
        float frac = 1.0f;
        for (int i = 1; i < 5; i++) {
            ind += list[i] == 1 ? Math.pow(2, 4 - i) : 0;
            if (i + 4 < 8) {
                frac += list[i + 4] == 1 ? Math.pow(2, 0 - i) : 0;
            }
        }
        if (list[0] == 1) {
            return (float) Math.pow(2, ind) * frac * -1;
        }
        return (float) Math.pow(2, ind) * frac;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        for (int i = 0; i < 256; i++) {
            if (miniFloatFromString(getValidMiniFloatBitSequences()[i]) == (int) miniFloatFromString(getValidMiniFloatBitSequences()[i])) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
