public class MiniFloat {

    private static int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        double miniFloat = 0;
        int mantissa;
        mantissa = 1000 + Integer.parseInt(bitSequence.substring(5, 8));
        for (int i = 0; i < 4; i++) {
            if (Integer.toString(mantissa).charAt(i) == '1') {
                miniFloat += Math.pow(2, -i);
            }
        }
        for (int j = 1; j < 5; j++) {
            if (bitSequence.charAt(j) == '1') {
                miniFloat *= Math.pow(2, Math.pow(2, 4 - j));
            }
        }
        return (float) miniFloat;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
