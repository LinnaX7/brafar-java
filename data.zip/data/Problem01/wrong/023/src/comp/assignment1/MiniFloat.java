package comp.assignment1;

public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float result = 0;
        boolean neg = false;
        if (bitSequence.charAt(0) == 49) {
            neg = true;
        }
        String exponent = bitSequence.substring(1, 5);
        int ex = 0;
        for (int temp = 3; temp >= 0; temp--) {
            if (exponent.charAt(temp) == 49) {
                ex += 2 ^ temp;
            }
        }
        String mantissa = bitSequence.substring(5, 8);
        float ma = 0;
        for (int temp = 2; temp >= 0; temp--) {
            if (mantissa.charAt(temp) == 49) {
                ma += 2 ^ (-1 * temp);
            }
        }
        result = (2 ^ ex) * ma;
        if (neg) {
            result *= -1;
        }
        return result;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            for (int i = 0; i < s.length(); i++) {
                float x = miniFloatFromString(s);
                if (x % 1 == 0) {
                    count++;
                }
            }
        }
        return count;
    }

    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
