package comp.assignment1;

public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float sign = 1 - 2 * (bitSequence.charAt(0) - '0');
        float exp = 0f;
        for (int i = 4, t = 1; i >= 1; i--, t <<= 1) {
            if (bitSequence.charAt(i) == '1') {
                exp += t;
            }
        }
        float tmp = 1f / 8f;
        float man = 0f;
        for (int i = 7; i > 4; i--) {
            if (bitSequence.charAt(i) == '1') {
                man += tmp;
            }
            tmp *= 2;
        }
        man += 1f;
        return (float) (sign * Math.pow(2, exp) * man);
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            float x = miniFloatFromString(s);
            if (Math.abs((int) x - x) < 1E-6f) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
