/*
Tiago Teixeira Reis - 19085298d
 */
public class MiniFloat {

    public static void main(String[] args) {
        printIntegralMiniFloats();
    }

    public static float miniFloatFromString(String bitSequence) {
        byte[] idk = bitSequence.getBytes();
        for (int x = 0; x < idk.length; x++) {
            if (idk[x] == 48) {
                idk[x] = 0;
            } else {
                idk[x] = 1;
            }
        }
        int sign_bit = 0;
        int exponent = 0;
        float significant = 0;
        float answer = 0;
        for (int x = 0; x < idk.length; x++) {
            if (x == 0) {
                if (idk[x] == 0) {
                    sign_bit = 1;
                } else {
                    sign_bit = -1;
                }
            }
            if (x >= 1 && x <= 4) {
                exponent += idk[x] * (1 << (4 - x));
            }
            if (x >= 5 && x < 8) {
                significant += (float) idk[x] * (1.0 / (1 << (7 - x)));
            }
        }
        answer = (sign_bit * ((1 + significant) * (1 << exponent)));
        return answer;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            if (miniFloatFromString(s) - ((float) ((int) miniFloatFromString(s))) == 0.0) {
                count++;
            }
        }
        return count;
    }

    static int printIntegralMiniFloats() {
        return numIntegralMiniFloats();
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
