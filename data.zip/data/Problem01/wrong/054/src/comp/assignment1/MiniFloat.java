package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int sign = 1;
        if (bitSequence.charAt(0) == '1') {
            sign = -1;
        }
        int exp = Integer.parseInt(bitSequence.substring(1, 5), 2);
        String mantissa = bitSequence.substring(5, 8);
        float mantissaValue = mantissaBinaryToFloat(mantissa);
        return (float) (sign * (mantissaValue * Math.pow(2, exp)));
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] minFloatBitSequences = getValidMiniFloatBitSequences();
        int integralCount = 0;
        for (String seq : minFloatBitSequences) {
            float value = miniFloatFromString(seq);
            if (value == (int) value)
                integralCount++;
        }
        return integralCount;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    /**
     * Convert binary mantissa to float
     */
    private static float mantissaBinaryToFloat(String mantissa) {
        float value = 1;
        for (int i = 0; i < mantissa.length(); i++) {
            if (mantissa.charAt(i) == '1')
                value += Math.pow(2, ((i + 1) * -1));
        }
        return value;
    }
}
