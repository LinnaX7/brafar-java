package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task1: compute the miniFloat value from "bitSequence";
        double miniFloat = 0;
        int mantissa;
        mantissa = 1000 + Integer.parseInt(bitSequence.substring(5, 8));
        for (int x = 0; x <= 3; x++) {
            if (Integer.toString(mantissa).charAt(x) == '1') {
                miniFloat = miniFloat + Math.pow(2, -x);
            }
        }
        for (int check = 1; check <= 4; check++) {
            if (bitSequence.charAt(check) == '1') {
                miniFloat = miniFloat * Math.pow(2, Math.pow(2, 4 - check));
            }
        }
        if (bitSequence.charAt(0) == '0') {
            System.out.println(miniFloat);
            return (float) miniFloat;
        }
        System.out.println(miniFloat);
        return (float) -miniFloat;
        // Task 2: return the number of integral miniFloat values.
    }

    // Task 2: return the number of integral miniFloat values.
    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences(String minifloat) {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            String full = String.format("%" + Integer.SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
            result[i] = full.substring(Integer.SIZE - MINI_FLOAT_SIZE, Integer.SIZE);
        }
        return result;
    }
}
