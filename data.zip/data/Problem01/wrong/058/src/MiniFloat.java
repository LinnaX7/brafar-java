public class MiniFloat {

    public static void main(String[] args) {
        // printIntegralMiniFloats();
        // System.out.println(miniFloatFromString("10100110"));
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int signNumber;
        int[] mantissaBinary = new int[3];
        double mantissaDecimal = 1.0;
        int[] exponentBinary = new int[4];
        int exponentDecimal = 0;
        float result = 0;
        signNumber = Character.getNumericValue(bitSequence.charAt(0));
        for (int i = 0; i <= 3; i++) {
            exponentBinary[i] = Character.getNumericValue(bitSequence.charAt(i + 1));
        }
        for (int i = 0; i <= 2; i++) {
            mantissaBinary[i] = Character.getNumericValue(bitSequence.charAt(i + 5));
        }
        int count = 3;
        for (int i = 0; i <= 3; i++) {
            exponentDecimal += (int) (exponentBinary[i] * Math.pow(2, count));
            count--;
        }
        int count1 = -1;
        for (int i = 0; i <= 2; i++) {
            mantissaDecimal += (mantissaBinary[i] * Math.pow(2, count1));
            count1--;
        }
        if (signNumber == 0) {
            result = (float) (mantissaDecimal * Math.pow(2, exponentDecimal));
        } else {
            if (signNumber == 1) {
                result = (float) (-mantissaDecimal * Math.pow(2, exponentDecimal));
            }
        }
        return result;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        float binarySequence;
        for (String s : getValidMiniFloatBitSequences()) {
            binarySequence = miniFloatFromString(s);
            if (binarySequence == Math.round(binarySequence)) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
