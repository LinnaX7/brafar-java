package comp.assignment1;

public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        float m = 0;
        float k;
        int e = 0;
        for (int a = 1; a <= 4; a++) {
            if (bitSequence.charAt(a) == '1') {
                e += (int) Math.pow(2, 4 - a);
            }
        }
        for (int b = 5; b <= 7; b++) {
            if (bitSequence.charAt(b) == '1') {
                m += (float) Math.pow(2, -(b - 4));
            }
        }
        k = (m + 1) * (float) Math.pow(2, e);
        if (bitSequence.charAt(0) == '1') {
            k = -k;
        }
        return k;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            for (int k = 0; k < s.length(); k++) {
                float a = miniFloatFromString(s);
                if (a % 1 == 0) {
                    count++;
                }
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
