package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        boolean isNegative;
        char s = bitSequence.charAt(0);
        ;
        float exponent = 0F, significand = 0F, endResult = 0F, finalExponent = 1F;
        double tempNum;
        if (s == '0') {
            isNegative = false;
        } else {
            isNegative = true;
        }
        for (int n = 1; n <= 4; n++) {
            // reads the exponent from the sequence 2-5
            s = bitSequence.charAt(n);
            if (s == '1') {
                if (n == 4) {
                    exponent += 1;
                }
                if (n == 3) {
                    exponent += 2;
                }
                if (n == 2) {
                    exponent += 4;
                }
                if (n == 1) {
                    exponent += 8;
                }
            }
        }
        for (int n = 5; n <= 7; n++) {
            // reads significand from the sequence 6-8
            s = bitSequence.charAt(n);
            if (s == '1') {
                float c = 2 * (n - 4);
                c = 1 / c;
                significand += c;
            }
        }
        significand += 1;
        // conversion for further processing using Math
        int mExponent = Math.round(exponent);
        double tempExponent = (double) mExponent;
        tempNum = Math.pow(2, tempExponent);
        finalExponent = (float) tempNum;
        endResult = significand * finalExponent;
        if (isNegative) {
            // if the first bit in the sequence is negative, the result will be given a negative value
            float temp = endResult * 2;
            endResult -= temp;
        }
        return endResult;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        double exponent = 0;
        float significand = 0F, tempResult;
        // 8bit range = 0.1111.111
        // 1111 as exponent
        for (int n = 0; n < 4; n++) {
            exponent += Math.pow(2, n);
        }
        // 111 as significand
        for (int n = 1; n < 4; n++) {
            int c = 1 / (n * 2);
            // converted to decimal
            significand += c;
        }
        // add 1 to the significand = 1.__
        significand++;
        // significand * 2^exponent
        exponent = Math.pow(2, exponent);
        float exponentF = (float) exponent;
        tempResult = significand * exponentF;
        double res = Math.round(tempResult);
        int endRes = (int) res;
        return endRes;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
