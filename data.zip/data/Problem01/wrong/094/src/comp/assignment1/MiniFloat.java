package comp.assignment1;

import java.lang.Math;

// 20080439D GENG Longling
public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(miniFloatFromString("00100110"));
        System.out.println(miniFloatFromString("0010011"));
        System.out.println(miniFloatFromString("00100113"));
        System.out.println(miniFloatFromString("88888888"));
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // input validation
        boolean flag = true;
        if (// 1.check the length;
        bitSequence.length() != 8) {
            System.out.println("Your input is incorrect. Please input a bit string of 8 digits.");
            flag = false;
        } else // 2. check each digit is either 0 or 1
        {
            for (int i = 0; i < 8; i++) {
                if (!((bitSequence.charAt(i) == '0') || (bitSequence.charAt(i) == '1'))) {
                    System.out.println("Your input is incorrect. Please input a bit string of 8 digits.");
                    flag = false;
                    break;
                }
            }
        }
        if (flag == false) {
            return -1f;
        }
        // if input is correct, do the calculation.
        // calculate the s
        int s = (int) Math.pow(-1, bitSequence.charAt(0));
        // calculate the E
        int E = 0;
        for (int i = 1; i < 5; i++) {
            // index 1,2,3,4 turn into 3,2,1,0
            E += (int) Math.pow(2, 4 - i) * (bitSequence.codePointAt(i) - 48);
        }
        // calculate the 1.xxx
        float M = 1;
        for (int i = 5; i < 8; i++) {
            // turn 5,6,7 to -1,-2,-3
            int ex = -i + 4;
            // multiply by 0/1
            M += (float) Math.pow(2, ex) * (bitSequence.codePointAt(i) - 48);
        }
        // calculate the result
        // return the float value
        return s * (float) Math.pow(2, E) * M;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        // since the num has max 3 floating digits, so if after it casts to int and the absolute bias is smaller than 0.0001,
        // it proves that the original number should be an integer.
        for (String s : getValidMiniFloatBitSequences()) {
            // 1.generate 256 numbers --- by getValidMiniFloatBitSequences()
            // System.out.println(miniFloatFromString(s));
            // 2.check if it is int
            int casting_value = (int) miniFloatFromString(s);
            if (Math.abs(miniFloatFromString(s) - casting_value) < 0.0001f) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
