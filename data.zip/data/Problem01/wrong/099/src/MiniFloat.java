public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    /**
     * Function to calculate the exponent part of the decimal number
     */
    public static int exponent(String bit) {
        // declaring and initializing the variable
        int exp = 0, i, j;
        // converting the given bit string of 4 bits to integer
        for (i = 0, j = 3; i < 4; i++, j--) {
            exp += (bit.charAt(i) - 48) * (int) (Math.pow(2, j));
        }
        // returning the exponent
        return exp;
    }

    /**
     * Function to calculate the mantissa part of the decimal number
     */
    public static float mantissa(String bit) {
        // declaring the variables
        float man = 0;
        int i, j;
        // converting the given bit string of 3 bits to decimal
        for (i = 0, j = -1; i < 3; i++, j--) {
            man += (bit.charAt(i) - 48) * (float) (Math.pow(2, j));
        }
        // returning the mantissa
        return man;
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float miniFloat;
        // declaring the sign through sign bit
        int sign = bitSequence.charAt(0) == '0' ? 1 : -1;
        // calculating the exponent
        int exp = exponent(bitSequence.substring(1, 5));
        // calculating the significand
        float significand = 1 + mantissa(bitSequence.substring(5));
        // returning the miniFloat
        miniFloat = (float) (sign * significand * Math.pow(2, exp));
        return miniFloat;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        // taking the list of miniFloat bit sequences of 8 bits
        String[] miniFloatList = getValidMiniFloatBitSequences();
        // declaring counters
        int i, count = 0;
        // assigning length of array to l
        int l = miniFloatList.length;
        // varibale to store the miniFloat value of each element of miniFloatList
        float miniFloat;
        for (i = 0; i < l; i++) {
            miniFloat = Math.abs(miniFloatFromString(miniFloatList[i]));
            // if the number is equal to its nearest integer, increment count by 1
            if (miniFloat == (float) Math.floor(miniFloat))
                count++;
        }
        // return count
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
