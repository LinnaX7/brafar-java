package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    // constructor
    public MiniFloat() {
    }

    public static float miniFloatFromString(String st) {
        String[] test = st.split("");
        int sign = (test[0].equals("0")) ? 1 : -1;
        double mantissa = 1.0D;
        int exponent = 0;
        double value;
        float value1;
        double exp0;
        // exponent
        for (int i = 1; i < 5; i++) {
            if (test[i].equals("1")) {
                exponent += myPow(2, (4 - i));
            }
        }
        if (test[1].equals("1")) {
            exponent = -1 * (8 - exponent);
        }
        // mantissa
        for (int j = 5; j < 8; j++) {
            if (test[j].equals("1")) {
                mantissa += myPow(0.5, (j - 4));
            }
        }
        if (exponent < 0) {
            int t = -1 * exponent;
            exp0 = myPow(2, t);
            exp0 = 1 / exp0;
        } else {
            exp0 = myPow(2, exponent);
        }
        value = sign * exp0 * mantissa;
        value1 = (float) value;
        return value1;
    }

    public static double myPow(double a, int b) {
        double res = 1.0D;
        for (int i = 0; i < b; ++i) {
            res *= a;
        }
        return res;
    }
}
