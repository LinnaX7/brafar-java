public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float miniFloat = 0;
        int n = 4;
        // set double for using power function
        double exponent = 0;
        // set double for using power function
        double significand = 1;
        for (int i = 1; i < 5; i++) {
            if (bitSequence.charAt(i) == 49) {
                // 49 is the ascii no. of 1
                // using power function to get the exponent
                exponent = exponent + Math.pow(2, (n - i));
            }
        }
        // System.out.println(exponent);  //test for exponent value
        for (int i = 5; i < MINI_FLOAT_SIZE; i++) {
            if (bitSequence.charAt(i) == 49) {
                // 49 is the ascii no. of 1
                // using power function to get the significand
                significand = significand + Math.pow(2, (n - i));
            }
        }
        // System.out.println(significand);      // test for significand value
        miniFloat = (float) ((Math.pow(2, exponent)) * significand);
        // System.out.println(miniFloat);    // test for miniFloat value
        if (bitSequence.charAt(0) == 49) {
            // if the signbit is 1
            // the miniFloat number is negative
            miniFloat = miniFloat * (-1);
        }
        return miniFloat;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        // store the value of all valid sequence
        String[] value = getValidMiniFloatBitSequences();
        // get the max no. of looping
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        // counter of integral miniFloat
        int counter = 0;
        float miniFloat;
        for (int i = 0; i < nbrValues; i++) {
            // for loop for checking integral miniFloat
            miniFloat = (int) miniFloatFromString(value[i]);
            if (miniFloat % 1 == 0) {
                // if miniFloat have no remainder
                // then counter +1
                counter++;
            }
        }
        return counter;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
