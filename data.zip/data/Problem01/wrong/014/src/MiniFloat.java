public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int sign = bitSequence.charAt(0) - '0';
        int exponent = 0;
        float mantissa = 0;
        for (int i = 4; i > 1; i--) {
            exponent += (int) (bitSequence.charAt(i) - '0') * Math.pow(2, 4 - i);
        }
        if (bitSequence.charAt(1) == '1') {
            exponent -= 16;
        }
        for (int j = 7; j > 4; j--) {
            mantissa += (bitSequence.charAt(j) - '0') * Math.pow(2, 4 - j);
        }
        float miniFloat = (1 + mantissa) * (int) Math.pow(2, exponent);
        if (sign == 0) {
            return miniFloat;
        }
        return -miniFloat;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] bitSequences = getValidMiniFloatBitSequences();
        int count = 0;
        for (int i = 0; i < Math.pow(2, MINI_FLOAT_SIZE); i++) {
            float miniFloat = miniFloatFromString(bitSequences[i]);
            if (miniFloat == (int) miniFloat) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
