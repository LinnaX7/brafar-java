import java.util.Scanner;

public class MiniFloat {

    public static float DELTA = 1E-6f;

    public static void main(String[] args) {
        // Task 3: Prints out the result of method MiniFloat.numIntegralMiniFloats;
        // Receives an input of a String str of eight characters from keyboard, and prints out both the input and its float value obtained from miniFloatFromString;
        System.out.println(numIntegralMiniFloats());
        Scanner scanner = new Scanner(System.in);
        String str = scanner.next();
        System.out.println(miniFloatFromString(str));
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        String s = bitSequence.substring(0, 1);
        String exponent = bitSequence.substring(1, 4);
        String mantissa = bitSequence.substring(4);
        int a1 = 0;
        float a2 = 1.0f;
        int j = 0;
        for (int i = exponent.length() - 1; i >= 0; i--) {
            if (exponent.charAt(i) == '1') {
                a1 += (int) Math.pow(2, j);
            }
            j++;
        }
        for (int i = 0; i < mantissa.length(); i++) {
            int anInt = Integer.parseInt(String.valueOf(mantissa.charAt(i)));
            a2 += anInt / Math.pow(2, i + 1);
        }
        float result = (float) (Math.pow(2, a1) * a2);
        if (s == "1") {
            result *= -1;
        }
        return result;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] sequences = getValidMiniFloatBitSequences();
        int k = 0;
        for (int i = 0; i < sequences.length; i++) {
            String s = sequences[i];
            float miniFloat = miniFloatFromString(s);
            if (miniFloat == (int) miniFloat) {
                k++;
            }
        }
        return k;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, 8);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + 8 + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    /**
     * Following are some test cases for you to check the correctness of your implementation.
     * But it does no necessarily mean that if all the tests pass, then your implementation is correct.
     * When I test your programs, I may use different sequences of bits.
     */
    public static void test1() {
        assert (Math.abs(MiniFloat.miniFloatFromString("00100110") - 5.5) < DELTA);
        System.out.println("00100110 pass");
    }

    public static void test2() {
        assert (Math.abs(MiniFloat.miniFloatFromString("10100110") - -5.5) < DELTA);
        System.out.println("10100110 pass");
    }

    public static void test3() {
        assert (Math.abs(MiniFloat.miniFloatFromString("00000000") - 1) < DELTA);
        System.out.println("00000000 pass");
    }

    public static void test4() {
        assert (Math.abs(MiniFloat.miniFloatFromString("10000000") - -1) < DELTA);
        System.out.println("10000000 pass");
    }

    public static void test5() {
        assert (Math.abs(MiniFloat.miniFloatFromString("00001000") - 1.5) < DELTA);
        System.out.println("00001000 pass");
    }

    public static void test6() {
        assert (Math.abs(MiniFloat.miniFloatFromString("00001100") - 1.75) < DELTA);
        System.out.println("00001100 pass");
    }

    public static void test7() {
        assert (Math.abs(MiniFloat.miniFloatFromString("00111111") - 15.5) < DELTA);
        System.out.println("00111111 pass");
    }

    public static void test8() {
        assert (Math.abs(MiniFloat.miniFloatFromString("11111111") - -0.96875) < DELTA);
        System.out.println("11111111 pass");
    }
}
