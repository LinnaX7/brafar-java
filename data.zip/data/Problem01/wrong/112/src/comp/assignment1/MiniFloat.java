package comp.assignment1;

import java.util.Scanner;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.next();
        System.out.println(miniFloatFromString(str));
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float exponent = 0;
        float mantissa = 0;
        float result;
        String currentNumberC = bitSequence.substring(1, 5);
        String cu = bitSequence.substring(5);
        String s1 = currentNumberC.replace('0', '2');
        String s2 = s1.replace('1', '0');
        String s3 = s2.replace('2', '1');
        if (bitSequence.charAt(0) == '0') {
            for (int i = 0; i < currentNumberC.length(); i++) {
                char ch = currentNumberC.charAt(i);
                int n = (int) ch - (int) '0';
                int m = (3 - i);
                exponent = exponent + n * (float) Math.pow(2, m);
            }
        } else {
            for (int i = 0; i < s3.length(); i++) {
                char ch = s3.charAt(i);
                int n = (int) ch - (int) '0';
                int m = (3 - i);
                exponent = exponent + n * (float) Math.pow(2, m);
            }
            exponent = exponent + 1;
        }
        for (int i = 0; i < cu.length(); i++) {
            char ch = cu.charAt(i);
            int n = (int) ch - (int) '0';
            mantissa = mantissa + n * (float) Math.pow(0.5, i + 1);
        }
        mantissa = mantissa + 1;
        if (bitSequence.charAt(0) == '0') {
            result = mantissa * (float) Math.pow(2, exponent);
        } else {
            result = -(mantissa * (float) Math.pow(2, exponent));
        }
        return result;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int count2 = 0;
        String[] allNumber = getValidMiniFloatBitSequences();
        for (int i = 0; i < 256; i++) {
            float x = miniFloatFromString(allNumber[i]);
            if (x % 1 == 0) {
                count2 = count2 + 1;
            }
        }
        return count2;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
