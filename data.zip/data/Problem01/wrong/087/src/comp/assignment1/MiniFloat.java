package comp.assignment1;

public class MiniFloat {

    public static void main(String[] args) {
        numIntegralMiniFloats();
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int exponent = 0;
        int mantissa = 0;
        int final_value = 0;
        for (int i = 1; i <= 4; i++) {
            if (bitSequence.charAt(i) == '1') {
                exponent += (int) Math.pow(2, (4 - i));
            }
        }
        for (int j = 5; j <= 7; j++) {
            if (bitSequence.charAt(j) == '1') {
                mantissa += (int) Math.pow(2, (4 - j));
            }
        }
        final_value = (mantissa + 1) * (int) Math.pow(2, exponent);
        if (bitSequence.charAt(0) == '1') {
            final_value = -final_value;
        }
        return final_value;
    }

    public static int numIntegralMiniFloats() {
        String[] bitSequences = getValidMiniFloatBitSequences();
        int intNumber = 0;
        for (int x = 0; x < bitSequences.length; x++) {
            float y = miniFloatFromString(bitSequences[x]);
            if (y == (int) y) {
                intNumber++;
                System.out.println(bitSequences[x] + " == " + (int) y);
            }
        }
        return intNumber;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
