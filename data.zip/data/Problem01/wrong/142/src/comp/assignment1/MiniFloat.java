package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int sign = Character.getNumericValue(bitSequence.charAt(0));
        float expValue = binToDec(bitSequence.substring(1, 5), Character.getNumericValue(bitSequence.charAt(1)), 0);
        float mantissaValue = binToDec(bitSequence.substring(5, MINI_FLOAT_SIZE), 0, -3) + 1;
        float miniFloatValue = (float) (mantissaValue * Math.pow(2, expValue));
        miniFloatValue = (sign == 0) ? miniFloatValue : -miniFloatValue;
        return miniFloatValue;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int sum = 0;
        for (int j = 0; j <= 255; ++j) {
            if (miniFloatFromString(getValidMiniFloatBitSequences()[j]) % 1.0 == 0) {
                ++sum;
            }
        }
        return sum;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    public static float binToDec(String binString, int sign, int order) {
        float binValue = 0;
        if (binString.length() == 4) {
            if (sign == 1) {
                binValue = binToDec(binString.substring(1, 4), 0, 0) * (-1) - 1;
                return binValue;
            }
        }
        for (int j = binString.length() - 1; j >= 0; --j) {
            binValue += Character.getNumericValue(binString.charAt(j)) * Math.pow(2, order);
            ++order;
        }
        return binValue;
    }
}
