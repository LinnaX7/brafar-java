package comp.assignment1;

public class MiniFloat {

    public static void main(String[] args) {
        numIntegralMiniFloats();
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float miniFloat;
        // character code for '0' & '1' is the value 48 & 49, ref ASCII chart
        int sign = Integer.valueOf(bitSequence.charAt(0) - 48);
        int exponent = 0;
        float mantissa = 0;
        for (int i = 1; i <= 4; i++) {
            // count exponent from 2 digit to 10 digit
            exponent += (Integer.valueOf(bitSequence.charAt(i)) - '0') * (int) Math.pow(2, 4 - i);
        }
        // from equation
        exponent = (int) Math.pow(2, exponent);
        for (int j = 5; j <= 7; j++) {
            // count mantissa from 2 digit to 10 digit
            mantissa += (Integer.valueOf(bitSequence.charAt(j)) - '0') * Math.pow(2, 4 - j);
        }
        // formula
        miniFloat = (1 + mantissa) * exponent;
        // check sign is 0 or not, ref https://www.delftstack.com/zh-tw/howto/java/java-question-mark-colon/
        return sign == 0 ? miniFloat : -miniFloat;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
