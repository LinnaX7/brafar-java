package comp.assignment1;

public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        int sign = 0, exp = 0;
        double signif = 1;
        for (int i = 0; i < bitSequence.length(); i++) {
            if (i == 0) {
                // check sign
                sign = ((bitSequence.charAt(i) == '0') ? 1 : -1);
            } else {
                if ((i > 0) && (i < 5)) {
                    // check exponent
                    if (bitSequence.charAt(i) == '1') {
                        exp += (1 * Math.pow(2, 4 - i));
                    }
                } else {
                    if (i > 4) {
                        // check mantissa
                        if (bitSequence.charAt(i) == '1') {
                            signif += (1 * Math.pow(2, (-i + 4)));
                        }
                    }
                }
            }
        }
        double temp = signif * (Math.pow(2, exp)) * sign;
        float miniFloat = (float) temp;
        return miniFloat;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            float a = miniFloatFromString(s);
            int b = (int) a;
            if (b == (float) a) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
