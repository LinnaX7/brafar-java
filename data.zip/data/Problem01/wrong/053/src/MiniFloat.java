public class MiniFloat {

    public static void main(String[] args) {
        System.out.print(numIntegralMiniFloats());
    }

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        byte exponent = 0;
        float significand = 1;
        float point = 1;
        int num = 16;
        for (int i = 1; i < 5; i++) {
            num /= 2;
            if (bitSequence.charAt(i) == '1') {
                exponent += num;
            }
        }
        for (int i = 5; i < 8; i++) {
            point /= 2;
            if (bitSequence.charAt(i) == '1') {
                significand += point;
            }
        }
        if (bitSequence.charAt(0) == '1') {
            significand *= -1;
        }
        double ans = significand * Math.pow(2, exponent);
        return (float) ans;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int valid = 0;
        String[] AllSequences = getValidMiniFloatBitSequences();
        for (String allSequence : AllSequences) {
            double TestNumber = miniFloatFromString(allSequence);
            if (Math.ceil(TestNumber) - TestNumber == 0)
                valid++;
        }
        return valid;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
