package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static double value = 0f;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // take the first bit to devide negative or positive
        char firstchar = bitSequence.charAt(0);
        // if 0 ,set PosNeg to 1, if 1, set to -1
        int PosNeg = firstchar == '0' ? 1 : -1;
        // extract the exponent part as string
        String strexponent = bitSequence.substring(1, 5);
        // start to extract the mantissa part one by one
        char place5 = bitSequence.charAt(5);
        // turn char to int
        int significand1 = place5 == '0' ? 0 : 1;
        char place6 = bitSequence.charAt(6);
        int significand2 = place6 == '0' ? 0 : 1;
        char place7 = bitSequence.charAt(7);
        int significand3 = place7 == '0' ? 0 : 1;
        value = (PosNeg * (Math.pow(2, Integer.parseInt(strexponent, 2)) * (1 + (significand1 * 0.5) + (significand2 * 0.25) + (significand3 * 0.125))));
        return (float) value;
        // value = 1/-1 *( 2^exponent)*(the significand) and return value in float.
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        // assigning a String array named as result to store all 256 miniFloats
        String[] result = getValidMiniFloatBitSequences();
        // assigning counter for counting the IntegralMiniFloats
        int counter = 0;
        // values2 are the elements(minifloat values) in result
        double value2;
        for (int i = 0; i < result.length; i++) {
            // looping the result
            // assigning values2 as the elements(minifloat values) in result
            value2 = miniFloatFromString(result[i]);
            if (value2 == (int) value2) {
                // comparing float value2 and int value2, if same, then count +1
                counter++;
            }
        }
        // return the number of all integral miniFloat values (222)
        return counter;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
