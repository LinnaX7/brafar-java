public class MiniFloat {

    public static void main(String[] args) {
        int result = numIntegralMiniFloats();
        System.out.println(result);
    }

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        char sign1 = bitSequence.charAt(0);
        String comPart1 = bitSequence.substring(1, 5);
        int comPart1Int = (int) Long.parseLong(comPart1, 2);
        double sum = 0;
        double exp = -3;
        for (int i = MINI_FLOAT_SIZE - 1; i > 4; i--) {
            sum = sum + Math.pow(2, exp) * (bitSequence.charAt(i) - '0');
            exp++;
        }
        sum = sum + 1;
        double sign;
        if (sign1 == '1') {
            sign = -1;
        } else {
            sign = 1;
        }
        double value = sign * Math.pow(2, comPart1Int) * sum;
        float output = (float) value;
        return output;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] generate = getValidMiniFloatBitSequences();
        int num = 0;
        for (int i = 0; i < Math.pow(2, MINI_FLOAT_SIZE); i++) {
            if ((miniFloatFromString(getValidMiniFloatBitSequences()[i])) % 1 == 0)
                num++;
        }
        return num;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
