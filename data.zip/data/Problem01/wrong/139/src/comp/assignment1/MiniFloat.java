package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        int i = Integer.valueOf(bitSequence.charAt(0) - 48);
        int a = 1000 + Integer.parseInt(bitSequence.substring(5, 8));
        String exponent = String.valueOf(a);
        int x = 0, y = 1;
        float miniFloat = 0;
        while (x <= 3) {
            if (exponent.charAt(x) == '1') {
                miniFloat += Math.pow(2, -x);
            }
            x++;
        }
        while (y <= 4) {
            if (bitSequence.charAt(y) == '1') {
                miniFloat *= Math.pow(2, Math.pow(2, 4 - y));
            }
            y++;
        }
        return i == 0 ? miniFloat : -miniFloat;
    }
}
