package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    private static float value_of_exponent;

    private static float value_of_mantissa;

    private static String positive;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        String exponent = bitSequence.substring(1, 5);
        String mantissa = bitSequence.substring(5, 8);
        positive = bitSequence.substring(0, 1);
        System.out.println(positive);
        int temp_value_of_exponent = Integer.parseInt(exponent, 2);
        float sum_of_mantissa = 0;
        int temp = Integer.parseInt(mantissa);
        for (int i = -3; i < 0; i++) {
            int digit = temp % 10;
            sum_of_mantissa += (float) digit * Math.pow(2, i);
            temp /= 10;
        }
        sum_of_mantissa += 1;
        value_of_exponent = temp_value_of_exponent;
        value_of_mantissa = sum_of_mantissa;
        System.out.println(value_of_exponent);
        System.out.println(sum_of_mantissa);
        return 0;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int P_or_N = Integer.parseInt(positive);
        System.out.println(P_or_N);
        float answer;
        float exponent = value_of_exponent;
        answer = (float) (Math.pow(2, exponent));
        answer *= value_of_mantissa;
        if (P_or_N == 1) {
            answer *= -1;
        }
        System.out.println(answer);
        return 0;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    public static void main(String[] args) {
        System.out.println(miniFloatFromString("00100110"));
        System.out.println(numIntegralMiniFloats());
    }
}
