package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        String subs1 = bitSequence.substring(0, 1);
        String subs2 = bitSequence.substring(1, 5);
        String subs3 = bitSequence.substring(5);
        int num1 = Integer.parseInt(subs1, 2);
        int num2 = Integer.parseInt(subs2, 2);
        float num3 = Integer.parseInt(subs3, 2);
        float result;
        num3 = num3 / 8 + 1;
        result = num3 * (float) Math.pow(2, num2);
        if (num1 == 1) {
            result = -result;
        }
        return result;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        float n = 0;
        for (int i = 0; i < getValidMiniFloatBitSequences().length; i++) {
            n = miniFloatFromString(getValidMiniFloatBitSequences()[i]);
            int m = (int) n;
            if (m == n)
                count++;
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
