package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        String a = bitSequence.substring(0, 1);
        int an = Integer.parseInt(a.trim());
        float symbol = 0;
        if (an == 0) {
            symbol = 1;
        }
        if (an == 1) {
            symbol = -1;
        }
        String b = bitSequence.substring(1, 5);
        int bdec = Integer.parseInt(b, 2);
        String c = bitSequence.substring(5, 6);
        double x = Integer.parseInt(c.trim());
        x = x * (0.5);
        String c1 = bitSequence.substring(6, 7);
        double x1 = Integer.parseInt(c1.trim());
        x1 = x1 * (0.25);
        String c2 = bitSequence.substring(7, 8);
        double x2 = Integer.parseInt(c2.trim());
        x2 = x2 * (0.125);
        double cdec = 1 + x + x1 + x2;
        double haha = (Math.pow(2, bdec));
        float result = (float) ((cdec) * haha);
        result = result * symbol;
        return result;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String bit = "01001001";
        int count = 0;
        float result = MiniFloat.miniFloatFromString(bit);
        if (Math.floor(result) == result) {
            count = count + 1;
            System.out.println(count);
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
