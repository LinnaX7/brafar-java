package comp.assignment1;

public class MiniFloat {

    public static float miniFloatFromString(String bitSequence) {
        int i = 0;
        int k = 0;
        int sum = 0;
        float sum1 = 0;
        String exp = bitSequence.substring(1, 5);
        String man = bitSequence.substring(5, 8);
        int a = Integer.parseInt(exp);
        int b = Integer.parseInt(man);
        while (i < exp.length()) {
            if (a % 10 == 1) {
                sum = sum + (int) Math.pow(2, i);
            }
            a = a / 10;
            i = i + 1;
        }
        while (k < man.length()) {
            if (b % 10 == 1) {
                sum1 = sum1 + (float) Math.pow(0.5, 3 - k);
            }
            b = b / 10;
            k = k + 1;
        }
        sum1 = sum1 + 1;
        return sum1 * ((int) Math.pow(2, sum));
    }
}
