package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float value = 0;
        char[] input = new char[8];
        // string to char array
        for (int i = 0; i < MINI_FLOAT_SIZE; i++) {
            input[i] = bitSequence.charAt(i);
        }
        int[] exponent = new int[4];
        for (int i = 1; i < 5; i++) {
            if (input[i] == '0') {
                exponent[i - 1] = 0;
            } else {
                exponent[i - 1] = 1;
            }
        }
        int[] significand = new int[3];
        for (int i = 5; i < 8; i++) {
            if (input[i] == '0') {
                significand[i - 5] = 0;
            } else {
                significand[i - 5] = 1;
            }
        }
        // exponent calculation
        int expNo = 0;
        for (int i = 0; i < 4; i++) {
            if (exponent[i] == 1) {
                expNo += Math.pow(2, 3 - i);
            }
        }
        // significand calculation
        float sigNo = 0;
        for (int i = 0; i < 3; i++) {
            if (significand[i] == 1) {
                sigNo += Math.pow(2, (i + 1) * -1);
            }
        }
        sigNo += 1;
        // final value calculation
        value = (float) Math.pow(2, expNo) * sigNo;
        // negative and positive
        if (input[0] == '1') {
            value *= -1;
        }
        return value;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        int count = 0;
        for (int i = 0; i < nbrValues; i++) {
            float compare = MiniFloat.miniFloatFromString(getValidMiniFloatBitSequences()[i]);
            if (compare % 1 == 0) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
