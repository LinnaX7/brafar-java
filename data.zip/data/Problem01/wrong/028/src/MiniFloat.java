public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // System.out.println("BitSequence: " + bitSequence);
        int sign = Integer.parseInt(bitSequence.substring(0, 1));
        int ExpVal = Integer.parseInt(bitSequence.substring(1, 5), 2);
        float Mval = binStrFractionToDecimal(bitSequence.substring(5, 8)) + 1f;
        // System.out.println("Sign: " + sign);
        // System.out.println("Exp: " + bitSequence.substring(1,5) + " = " + ExpVal);
        // System.out.println("Mval: " + bitSequence.substring(5,8) + " = " + Mval);
        // System.out.println(binStrFractionToDecimal("110"));
        float miniFloatVal = (sign == 0) ? Mval * (float) Math.pow(2, ExpVal) : -Mval * (float) Math.pow(2, ExpVal);
        // System.out.println("MiniFloat: " + miniFloatVal);
        return miniFloatVal;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] allSeq = getValidMiniFloatBitSequences();
        int IntegeralCount = 0;
        for (int i = 0; i < allSeq.length; i++) {
            if (// the val is integral
            miniFloatFromString(allSeq[i]) % 1 == 0)
                IntegeralCount++;
        }
        return IntegeralCount;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static float binStrFractionToDecimal(String binaryStr) {
        float sum = 0;
        for (int i = 0; i < binaryStr.length(); i++) {
            int binaryVal = Integer.parseInt(binaryStr.substring(i, i + 1));
            sum = sum + binaryVal * (float) Math.pow(2, -(i + 1));
        }
        return sum;
    }
}
