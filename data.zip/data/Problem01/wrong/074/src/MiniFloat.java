import java.util.Scanner;

public class MiniFloat {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please input a 8-bit bit sequence");
        String strinput = sc.nextLine();
        System.out.println("The whole value of " + strinput + " is: " + miniFloatFromString(strinput));
        System.out.println("Task2 The number of all integral: " + numIntegralMiniFloats());
    }

    static char flip(char x) {
        return (x == '0') ? '1' : '0';
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int exponentx = 0;
        float significandx;
        String signbit = bitSequence.substring(0, 1);
        String exponent = bitSequence.substring(1, 5);
        String mantissa = bitSequence.substring(5, 8);
        String[] str = mantissa.split("");
        int size = mantissa.length();
        float sum = 1;
        float x = -1;
        for (int i = 0; i < size; i++) {
            float temp = Float.parseFloat(str[i]);
            sum += temp * Math.pow(2, x);
            x -= 1;
        }
        significandx = sum;
        if (exponent.charAt(0) == '0') {
            exponentx = Integer.parseInt(exponent, 2);
        } else {
            String temp;
            temp = exponent;
            int n = temp.length();
            int i;
            String twos = "";
            for (i = 0; i < n; i++) {
                twos += flip(temp.charAt(i));
            }
            for (i = n - 1; i >= 0; i--) {
                if (twos.charAt(i) == '1') {
                    twos = twos.substring(0, i) + '0' + twos.substring(i + 1);
                } else {
                    twos = twos.substring(0, i) + '1' + twos.substring(i + 1);
                    break;
                }
            }
            exponentx = Integer.parseInt(twos, 2);
        }
        float output = 0;
        output += significandx * Math.pow(2, exponentx);
        if (Integer.parseInt(signbit) == 1) {
            output *= -1;
        }
        return output;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        double x;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            double temp = 0;
            temp = miniFloatFromString(s);
            if (temp == (int) temp) {
                count += 1;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
