package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // get exponent and mantissa from bitSequence first.
        String exponent = bitSequence.substring(1, 5);
        String mantissa = bitSequence.substring(5, 8);
        // binary to decimal.
        double ePowNum = 3;
        double decimalExponent = 0;
        for (int i = 0; i < 4; i++) {
            double calNum = Character.getNumericValue(exponent.charAt(i));
            decimalExponent = decimalExponent + calNum * Math.pow(2, ePowNum);
            ePowNum--;
        }
        // binary to decimal.
        double mPowNum = -1;
        double significand = 1;
        for (int i = 0; i < 3; i++) {
            double calNum2 = Character.getNumericValue(mantissa.charAt(i));
            significand = significand + calNum2 * Math.pow(2, mPowNum);
            mPowNum--;
        }
        // 1.mantissa x 2exponent formula.
        double value = significand * Math.pow(2, decimalExponent);
        float floatValue = (float) value;
        // here start to check if the value is positive or not.
        int check = Character.getNumericValue(bitSequence.charAt(0));
        if (check == 1) {
            floatValue = floatValue * -1;
        }
        return floatValue;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int count = 0;
        // get the array result from getValidMiniFloatBitSequences().
        String[] result = getValidMiniFloatBitSequences();
        for (int i = 0; i < result.length; i++) {
            float floatNum = Float.parseFloat(result[i]);
            if (floatNum == Math.ceil(floatNum)) {
                // If the float is integral, it will still be the same value after the program ceil it.
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
