import java.util.Scanner;

public class MiniFloat {

    public static void main(String[] args) {
        System.out.println("The number of integral miniFloat values are: " + numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float record2 = 0;
        char sign_bit = bitSequence.charAt(0);
        String exp = bitSequence.substring(1, 5);
        // Converting the exponent part to integer
        int e = Integer.parseInt(exp, 2);
        String mantissa = bitSequence.substring(5, 8);
        float significand = 1;
        int n = -1;
        for (int i = 0; i < mantissa.length(); i++) {
            char c = mantissa.charAt(i);
            int a = Character.getNumericValue(c);
            // Calculating the significand value
            significand += (a * (float) Math.pow(2, n));
            n--;
        }
        // Calculating the absolute value of miniFloat
        record2 = significand * (float) Math.pow(2, e);
        if (sign_bit == '1') {
            // if the minifloat is a negative number
            record2 = -1 * record2;
        }
        return record2;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            float N = miniFloatFromString(s);
            // converting each miniFloat value to int
            int X = (int) N;
            // finding the difference between the float and int value of each miniFloat
            float temp = N - X;
            if (temp == 0) {
                // If difference is 0, then the miniFloat value is an integer
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
