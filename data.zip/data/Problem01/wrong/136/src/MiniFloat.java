public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int sign = 1;
        int twoscomplement = 0;
        float mantissa = 0;
        float result;
        int[] a = { 0, 0, 0, 0, 0, 0, 0, 0 };
        for (int i = 0; i <= 7; i++) {
            a[i] = Integer.parseInt(String.valueOf(bitSequence.charAt(i)));
        }
        if (a[0] == 1) {
            sign = -1;
        }
        twoscomplement = (int) ((a[1] * Math.pow(2, 3)) + (a[2] * Math.pow(2, 2)) + (a[3] * Math.pow(2, 1)) + (a[4] * Math.pow(2, 0)));
        mantissa = (float) ((a[5] * Math.pow(2, -1)) + (a[6] * Math.pow(2, -2)) + (a[7] * Math.pow(2, -3)));
        result = (float) ((1 + mantissa) * (Math.pow(2, twoscomplement)) * sign);
        return result;
    }

    public static int numIntegralMiniFloats() {
        /*
        Answer is 222
         */
        int count = 0;
        String[] result = getValidMiniFloatBitSequences();
        for (int i = 0; i < result.length; i++) {
            if (miniFloatFromString(result[i]) == (int) miniFloatFromString(result[i])) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
