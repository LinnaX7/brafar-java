import java.lang.Math;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // substring index0;=1bits
        String sign = bitSequence.substring(0, 1);
        // substring from index 1 and ending index 4=3bits
        String exponent = bitSequence.substring(1, 5);
        // substring from 4 to the end(7)= 4 bits
        String Mantissa = bitSequence.substring(5);
        int Exp = 0;
        float value = 0;
        for (int i = 0; i < exponent.length(); i++) {
            if (exponent.charAt(i) == '1') {
                Exp += Math.pow(2, exponent.length() - i - 1);
            }
        }
        float M = 1;
        for (// for the last 3 terms in strings
        int j = 0; // for the last 3 terms in strings
        j < Mantissa.length(); // for the last 3 terms in strings
        j++) {
            if (Mantissa.charAt(j) == '1') {
                M += 1 / (float) Math.pow(2, (j + 1));
            }
        }
        // To find the decimal value
        value = M * (float) Math.pow(2, Exp);
        if (bitSequence.charAt(0) == '1') {
            // When sign is negative
            value -= (2 * value);
        }
        return value;
    }

    public static float numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) return (miniFloatFromString(s));
        return 0;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
