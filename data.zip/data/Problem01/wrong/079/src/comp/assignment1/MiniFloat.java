package comp.assignment1;

import java.lang.Math;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // 1st digit
        char sign = bitSequence.charAt(0);
        // 2nd to 5th digits
        String exp = bitSequence.substring(1, 5);
        // 6th to 8th digits
        String mantissa = bitSequence.substring(5, 8);
        // System.out.println("Sign: "+sign+"\nExp: "+exp+"\nMantissa: "+mantissa);
        int expNum = 0;
        int baseCount = 0;
        for (int i = exp.length() - 1; i >= 0; i--) {
            // convert the exp from string to int, from right to left
            if (exp.charAt(i) == '1') {
                // The char must be either 0 or 1, so calculate the int value if the digit is 1 with math.pow()
                expNum += Math.pow(2, baseCount);
            }
            baseCount++;
        }
        float mantissaNum = 0;
        baseCount = -1;
        for (int i = 0; i < mantissa.length(); i++) {
            if (mantissa.charAt(i) == '1') {
                mantissaNum += Math.pow(2, baseCount);
            }
            baseCount--;
        }
        // add 1 since the format should be 1.mantissa
        mantissaNum += 1;
        // calculate the value with formula
        float miniFloatValue = mantissaNum * (float) Math.pow(2, expNum);
        // value = 1.mantissa * 2^(exp)
        if (sign == '1') {
            // convert to negative value if sign bit is 1
            miniFloatValue *= -1;
        }
        return miniFloatValue;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        // get all 8-bits str.
        String[] bitsArray = getValidMiniFloatBitSequences();
        // counter for integral miniFloat
        int count = 0;
        for (int i = 0; i < bitsArray.length; i++) {
            // save a copy as an int for comparison
            int checkInt = (int) miniFloatFromString(bitsArray[i]);
            if ((float) checkInt == miniFloatFromString(bitsArray[i])) {
                // if (float)int == float itself, it means that the num is integer value(such that the format is ????.0)
                count++;
                // System.out.println("Value of "+bitsArray[i]+" = "+miniFloatFromString(bitsArray[i])+", count = "+count);
            }
        }
        System.out.println("Total count for all integral values: " + count);
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
    /*
    public static void main(String[] args){
        numIntegralMiniFloats();
    }*/
}
