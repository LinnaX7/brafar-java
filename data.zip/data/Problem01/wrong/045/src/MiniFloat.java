public class MiniFloat {

    private static String ans;

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int sign = 1;
        int exp = 0;
        float man = 1;
        char signIndex = bitSequence.charAt(0);
        if (signIndex == '1') {
            sign = -1;
        }
        int a, b;
        for (a = 1, b = 3; a <= 4; a++, b--) {
            exp += Character.getNumericValue(bitSequence.charAt(a)) * Math.pow(2, b);
        }
        for (a = 5, b = -1; a <= 7; a++, b--) {
            man = (float) (man + Character.getNumericValue(bitSequence.charAt(a)) * Math.pow(2, b));
        }
        return (float) (sign * man * (Math.pow(2, exp)));
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            if (miniFloatFromString(s) - Math.floor(miniFloatFromString(s)) == 0) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
