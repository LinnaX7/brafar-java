public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        String signBit = bitSequence.substring(0, 1);
        String exponentBit = bitSequence.substring(1, 5);
        String mantissaBit = bitSequence.substring(5, 8);
        int sign = Integer.parseInt(signBit);
        int exponent = Integer.parseInt(exponentBit, 2);
        int firstmantissaBit = Integer.parseInt(mantissaBit.substring(0, 1));
        int secondmantissaBit = Integer.parseInt(mantissaBit.substring(1, 2));
        int thirdmantissaBit = Integer.parseInt(mantissaBit.substring(2));
        float significand = firstmantissaBit * (float) 0.5 + secondmantissaBit * (float) 0.25 + thirdmantissaBit * (float) 0.125;
        significand = significand + 1;
        float value = significand * (int) Math.pow(2, exponent);
        if (sign == 1) {
            value = value * -1;
        }
        return value;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int number_of_integer = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] miniFloat = getValidMiniFloatBitSequences();
        float value = 0;
        int answer = 0;
        for (int i = 0; i < number_of_integer; i++) {
            String signBit = miniFloat[i].substring(0, 1);
            String exponentBit = miniFloat[i].substring(1, 5);
            String mantissaBit = miniFloat[i].substring(5, 8);
            int exponent = Integer.parseInt(exponentBit, 2);
            int sign = Integer.parseInt(signBit);
            int firstmantissaBit = Integer.parseInt(mantissaBit.substring(0, 1));
            int secondmantissaBit = Integer.parseInt(mantissaBit.substring(1, 2));
            int thirdmantissaBit = Integer.parseInt(mantissaBit.substring(2));
            float significand = firstmantissaBit * (float) 0.5 + secondmantissaBit * (float) 0.25 + thirdmantissaBit * (float) 0.125;
            significand = significand + 1;
            value = 1 + significand * (int) Math.pow(2, (2 + exponent));
            int integer_value = (int) value;
            if (sign == 1) {
                return answer = integer_value * -1;
            } else {
                return answer = integer_value;
            }
        }
        return answer;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
