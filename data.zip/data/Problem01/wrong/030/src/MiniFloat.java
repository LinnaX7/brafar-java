import java.math.BigDecimal;
import java.util.TreeMap;

public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    /* assume bitSequence is with length 8. */
    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int exponent = 0;
        boolean isNegative = false;
        BigDecimal accumulateMantissa = new BigDecimal(0);
        int highestValidDigitOfMantissa = 0;
        int mantissa = 0;
        TreeMap<Integer, Integer> mantissaMap = new TreeMap<>();
        int[] boxForMantissa = new int[3];
        int sizeOfBox = 0;
        // get the sign
        if (bitSequence.charAt(0) == '1') {
            isNegative = true;
        }
        // get the exponent
        exponent = getExponent(bitSequence);
        // process the mantissa
        for (int i = 5; i < bitSequence.length(); i++) {
            if (bitSequence.charAt(i) == '0') {
                continue;
            }
            // update the highestValidDigitOfMantissa
            highestValidDigitOfMantissa = i - 4;
            boxForMantissa[sizeOfBox] = compPow(5, highestValidDigitOfMantissa);
            sizeOfBox++;
            mantissaMap.put(compPow(5, highestValidDigitOfMantissa), highestValidDigitOfMantissa);
        }
        for (int i = 0; i < sizeOfBox; i++) {
            mantissa += boxForMantissa[i] * compPow(10, highestValidDigitOfMantissa - mantissaMap.get(boxForMantissa[i]));
        }
        BigDecimal accuMantissa1 = new BigDecimal(mantissa + "E" + "-" + highestValidDigitOfMantissa);
        BigDecimal accuMantissa2 = accuMantissa1.add(new BigDecimal(1));
        BigDecimal finalAns = accuMantissa2.multiply(new BigDecimal("2").pow(exponent));
        float res = finalAns.floatValue();
        // assign the sign to the value
        if (isNegative) {
            res = -res;
        }
        return res;
    }

    // Computes the exponent
    private static int getExponent(String sequence) {
        int exponent = 0;
        for (int i = 1; i <= 4; i++) {
            if (i == 1 && sequence.charAt(i) == '1') {
                exponent -= 8;
            } else if (i >= 2 && sequence.charAt(i) == '1') {
                exponent += compPow(2, 4 - i);
            }
        }
        return exponent;
    }

    /* Calculates the position of the last 1 in the significand, relative to the left binary point.*/
    private static int getLastOne(String sequence) {
        int last = 0;
        for (int i = 5; i < sequence.length(); i++) {
            if (sequence.charAt(i) == '1') {
                last = i - 4;
            }
        }
        return last;
    }

    // Computes the power, given the exponent b.
    private static int compPow(int base, int exponent) {
        int retVal = 1;
        while (exponent > 0) {
            if ((exponent & 1) == 1) {
                retVal = retVal * base;
            }
            base = base * base;
            exponent = exponent >> 1;
        }
        return retVal;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            if (MiniFloat.getExponent(s) < 0) {
                // this cannot be an integral value.
                continue;
            }
            if (getLastOne(s) <= getExponent(s)) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
