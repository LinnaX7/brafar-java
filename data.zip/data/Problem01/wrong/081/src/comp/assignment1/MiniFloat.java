package comp.assignment1;

import java.util.Scanner;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String bitSequence = in.nextLine();
        miniFloatFromString(bitSequence);
        numIntegralMiniFloats();
    }

    public static float miniFloatFromString(String bitSequence) {
        char[] s = bitSequence.toCharArray();
        double exp = Math.pow(2, 0) * (int) s[4] + Math.pow(2, 1) * (int) s[3] + Math.pow(2, 2) * (int) s[2] + Math.pow(2, 3) * (int) s[1];
        double man = 1 + Math.pow(2, -1) * (int) s[5] + Math.pow(2, -2) * (int) s[6] + Math.pow(2, -3) * (int) s[7] + Math.pow(2, -4) * (int) s[8];
        if (s[0] == 1) {
            double value = -man * Math.pow(2, exp);
            return (float) value;
        }
        double value = man * Math.pow(2, exp);
        return (float) value;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] bitSequences = getValidMiniFloatBitSequences();
        int count = 0;
        for (int i = 0; i < 256; i++) {
            if (miniFloatFromString(bitSequences[i]) == (int) miniFloatFromString(bitSequences[i])) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
