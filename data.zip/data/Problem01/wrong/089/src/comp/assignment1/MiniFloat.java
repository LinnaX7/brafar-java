package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // set an array to record the real number of the string
        int[] each = new int[8];
        for (int i = 0; i < 8; i++) {
            each[i] = (int) bitSequence.charAt(i) - '0';
        }
        // calculate the exponent
        double exponent = 0;
        for (int x = 1; x < 5; x++) {
            exponent = exponent + each[x] * Math.pow(2, 4 - x);
        }
        // calculate the significand
        double sign = 1;
        for (int y = 5; y < 8; y++) {
            sign = sign + each[y] * Math.pow(2, 4 - y);
        }
        // calculate the result
        double result = sign * Math.pow(2, exponent);
        // judge whether it is negative
        if (each[0] == 1) {
            result = -result;
        }
        return (float) result;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        // set a counter
        int number = 0;
        int len = getValidMiniFloatBitSequences().length;
        // use for loop to judge every miniFloats
        for (int i = 0; i < len; i++) {
            float value = miniFloatFromString(getValidMiniFloatBitSequences()[i]);
            // if the float is equal to integer,the counter will add 1
            if (value - (int) value == 0) {
                number = number + 1;
            }
        }
        return number;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
