public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        String exp = bitSequence.substring(1, 5);
        String man = bitSequence.substring(5);
        int decexp = 0;
        float answer = 0;
        float finman = 1;
        for (int i = 0; i < man.length(); i++) {
            if (man.charAt(i) == '1') {
                finman += (1.0 / (2.0 * (i + 1)));
            }
        }
        int multiplier;
        if (bitSequence.charAt(0) == '1') {
            multiplier = 1;
        } else {
            multiplier = -1;
        }
        for (int i = 0; i < exp.length(); i++) {
            if (exp.charAt(i) == '1') {
                decexp += (1.0 / (2.0 * (i + 1)));
            }
        }
        answer = multiplier * finman * decexp;
        return 0;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
