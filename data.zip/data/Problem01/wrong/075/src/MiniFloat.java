public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float miniFloat;
        // Calculate the exponent  using the next four values
        int exponent = 0;
        int currentExponent = 8;
        // Checks the 2nd to 5th bits (exponent bits)
        for (int i = 1; i < 5; i++) {
            if (bitSequence.charAt(i) == '1') {
                exponent += currentExponent;
            }
            currentExponent = currentExponent / 2;
        }
        double exponentValue = Math.pow(2, exponent);
        // Calculate mantissa
        double mantissa = 1;
        // Checks the 6th to 8th bits (mantissa bits)
        for (int i = 1; i < 4; i++) {
            if (bitSequence.charAt(i + 4) == '1') {
                mantissa = mantissa + 1 / Math.pow(2, i);
            }
        }
        // Converting the values to float so they can be calculated
        float mantissaF = (float) mantissa;
        float exponentValueF = (float) exponentValue;
        // Change value to -1 if sign bit is 1
        miniFloat = exponentValueF * mantissaF;
        if (bitSequence.charAt(0) == '1') {
            miniFloat = miniFloat * -1;
        }
        return (miniFloat);
    }

    public static int numIntegralMiniFloats() {
        String[] bitSequenceArray = getValidMiniFloatBitSequences();
        for (int i = 0; i < 256; i++) {
            if (miniFloatFromString(bitSequenceArray[i]) == (int) miniFloatFromString(bitSequenceArray[i])) {
                System.out.println(bitSequenceArray[i]);
            }
        }
        return -1;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
