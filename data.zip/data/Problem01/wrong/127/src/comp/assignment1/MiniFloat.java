package comp.assignment1;

public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int sign;
        int exp;
        float mantissa;
        sign = -1;
        if (Character.getNumericValue(bitSequence.charAt(0)) == 0) {
            sign = 1;
        }
        int exp1 = Character.getNumericValue(bitSequence.charAt(2)) * 4 + Character.getNumericValue(bitSequence.charAt(3)) * 2 + Character.getNumericValue(bitSequence.charAt(4));
        if (bitSequence.charAt(1) == '0') {
            exp = exp1;
        } else {
            if (bitSequence.substring(1, 5).equals("1000")) {
                exp = -8;
            } else {
                exp = -exp1;
            }
        }
        mantissa = Character.getNumericValue(bitSequence.charAt(5)) * (float) 0.5 + Character.getNumericValue(bitSequence.charAt(6)) * (float) 0.25 + Character.getNumericValue(bitSequence.charAt(7)) * (float) 0.125 + (float) 1;
        return (sign * (float) Math.pow(2, exp) * mantissa);
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            if (miniFloatFromString(s) == Math.floor(miniFloatFromString(s))) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static final int MINI_FLOAT_SIZE = 8;
}
