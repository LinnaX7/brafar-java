package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        byte[] bitvalue = new byte[8];
        for (int i = 0; i < bitSequence.length(); i++) {
            if (bitSequence.charAt(i) == '0') {
                bitvalue[i] = 0;
            } else {
                bitvalue[i] = 1;
            }
        }
        // calculate exponent
        double exp = 0;
        for (int i = 4; i >= 1; i--) {
            if (bitvalue[i] == 1) {
                exp += 1.0 * Math.pow(2.0, (double) (4 - i));
            }
        }
        // calculate mantissa
        double man = 1;
        for (int i = 5; i <= 7; i++) {
            if (bitvalue[i] == 1) {
                man += 1.0 * Math.pow(2.0, (double) (4 - i));
            }
        }
        // calculate whole value
        double value = (bitvalue[0] == 1) ? (-1) * man * Math.pow(2, exp) : man * Math.pow(2, exp);
        // System.out.println(value);
        return (float) value;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        int count = 0;
        String[] test = getValidMiniFloatBitSequences();
        for (int i = 0; i < nbrValues; i++) {
            int integerpart = (int) miniFloatFromString(test[i]);
            if (integerpart - miniFloatFromString(test[i]) == 0) {
                ++count;
                // System.out.println(integerpart);
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
