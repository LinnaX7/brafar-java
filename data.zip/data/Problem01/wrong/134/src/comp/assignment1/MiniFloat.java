package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        boolean sign = bitSequence.charAt(0) == '1';
        int exponent = 0;
        float mantissa = (float) 0.0;
        for (int i = 1; i <= 4; i++) {
            if (bitSequence.charAt(i) == '1') {
                exponent += Math.pow(2, 4 - i);
            }
        }
        for (int i = 5; i <= 7; i++) {
            if (bitSequence.charAt(i) == '1') {
                mantissa += Math.pow(2, 4 - i);
            }
        }
        float result = (float) ((1 + mantissa) * Math.pow(2, exponent));
        float signedResult = sign ? -result : result;
        return signedResult;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] setOfValidBitSequence = getValidMiniFloatBitSequences();
        int len = setOfValidBitSequence.length;
        int counter = 0;
        for (int i = 0; i < len; i++) {
            int exponent = 0;
            int leastWeightOfMantissa = 0;
            for (int j = 1; j <= 4; j++) if (setOfValidBitSequence[i].charAt(j) == '1')
                exponent += Math.pow(2, 4 - j);
            if (setOfValidBitSequence[i].charAt(7) == '1')
                leastWeightOfMantissa = -3;
            else if (setOfValidBitSequence[i].charAt(6) == '1')
                leastWeightOfMantissa = -2;
            else if (setOfValidBitSequence[i].charAt(5) == '1')
                leastWeightOfMantissa = -1;
            if (leastWeightOfMantissa + exponent >= 0)
                counter++;
        }
        return counter;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
