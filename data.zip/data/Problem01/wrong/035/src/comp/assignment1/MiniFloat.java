package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int exponent = 0;
        double significant = 1;
        float value;
        for (int i = 4; i > 0; i--) {
            double x;
            x = ((int) bitSequence.charAt(i) - 48) * (Math.pow(2, (4 - i)));
            exponent += x;
        }
        for (int j = 5; j < 8; j++) {
            double y;
            y = ((int) bitSequence.charAt(j) - 48) * (Math.pow(2, (4 - j)));
            significant += y;
        }
        if (bitSequence.charAt(0) == '0') {
            value = (float) (significant * (Math.pow(2, exponent)));
        } else {
            value = (float) (significant * (Math.pow(2, exponent)) * (-1));
        }
        return value;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int num = 0;
        for (int a = 0; a < 256; a++) {
            if (miniFloatFromString((getValidMiniFloatBitSequences())[a]) % 1 == 0)
                num += 1;
        }
        return num;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
