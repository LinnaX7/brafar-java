import static java.lang.Math.pow;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        char[] tempchar = bitSequence.toCharArray();
        int[] temp = new int[8];
        for (int i = 0; i < 8; i++) {
            if (tempchar[i] == '1') {
                temp[i] = 1;
            } else {
                temp[i] = 0;
            }
        }
        // sign
        int sign = temp[0] == 0 ? 1 : -1;
        // exponent
        int exponent = 0;
        for (int i = 1; i <= 4; i++) {
            exponent += temp[i] * pow(2, (4 - i));
        }
        // mantissa
        float mantissa = 0;
        for (int i = 5; i <= 7; i++) {
            mantissa += temp[i] * pow(2, 4 - i);
        }
        return (float) ((float) sign * pow(2, exponent) * (1 + mantissa));
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int count = 0;
        float value = 0;
        String[] allSeq = getValidMiniFloatBitSequences();
        for (String i : allSeq) {
            value = miniFloatFromString(i);
            if ((float) (int) value == value)
                count++;
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    public static void main(String[] args) {
        String seq = "00100110";
        System.out.println("is" + miniFloatFromString(seq));
    }
}
