public class MiniFloat {

    public static float miniFloatFromString(String bitSequence) {
        int sum1 = 0;
        float sum2 = 0;
        String expo = bitSequence.substring(1, 5);
        String man = bitSequence.substring(5, 8);
        int m = Integer.parseInt(expo);
        int n = Integer.parseInt(man);
        for (int i = 0; i < expo.length(); i++) {
            if (m % 10 == 1) {
                sum1 = sum1 + (int) Math.pow(2, i);
            }
            m = m / 10;
        }
        for (int i = 0; i < man.length(); i++) {
            if (n % 10 == 1) {
                sum2 = sum2 + (float) Math.pow(0.5, 3 - i);
            }
            n = n / 10;
        }
        sum2 = sum2 + 1;
        return sum2 * ((int) Math.pow(2, sum1));
    }
}
