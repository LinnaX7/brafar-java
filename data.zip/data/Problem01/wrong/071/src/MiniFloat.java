public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static void main(String[] args) {
        numIntegralMiniFloats();
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        char[] holdMiniFloat = bitSequence.toCharArray();
        int exponent = 0;
        for (int i = 1; i < 5; i++) {
            if (holdMiniFloat[i] == '1') {
                exponent += Math.pow(2, 4 - i);
            }
        }
        float mantissa = 1F;
        for (int i = 5; i < MINI_FLOAT_SIZE; i++) {
            if (holdMiniFloat[i] == '1') {
                mantissa += Math.pow(2, 4 - i);
            }
        }
        if (holdMiniFloat[0] == '0') {
            return (float) (mantissa * Math.pow(2, exponent));
        }
        return (float) (0 - (mantissa * Math.pow(2, exponent)));
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        for (int i = 0; i < nbrValues; i++) {
            System.out.println(getValidMiniFloatBitSequences()[i] + " == " + miniFloatFromString(getValidMiniFloatBitSequences()[i]));
        }
        return 0;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
