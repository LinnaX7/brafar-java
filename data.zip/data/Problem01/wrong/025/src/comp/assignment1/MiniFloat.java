package comp.assignment1;

import java.lang.Math;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float n = 0;
        String p = bitSequence.substring(0, 1);
        String f = bitSequence.substring(5, 6);
        String s = bitSequence.substring(6, 7);
        String t = bitSequence.substring(7);
        int p1 = Integer.parseInt(p);
        int f1 = Integer.parseInt(f);
        int s1 = Integer.parseInt(s);
        int t1 = Integer.parseInt(t);
        n = (float) (1 + 0.5 * f1 + 0.25 * s1 + 0.125 * t1);
        if (p1 == 1) {
            n = -n;
        }
        String i1 = bitSequence.substring(1, 2);
        String i2 = bitSequence.substring(2, 3);
        String i3 = bitSequence.substring(3, 4);
        String i4 = bitSequence.substring(4, 5);
        int l1 = Integer.parseInt(i1);
        int l2 = Integer.parseInt(i2);
        int l3 = Integer.parseInt(i3);
        int l4 = Integer.parseInt(i4);
        double e = l1 * 8 + l2 * 4 + l3 * 2 + l4;
        double tt = Math.pow(2, e);
        float num = (float) (n * tt);
        return num;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int count = 0;
        for (String i : getValidMiniFloatBitSequences()) {
            float n = miniFloatFromString(i);
            if (n % 1 == 0) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
