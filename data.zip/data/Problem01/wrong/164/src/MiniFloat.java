public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // the miniFloat//
        float flt = 0.0f;
        // the significand//
        // the last 3 bits of bitSequence//
        int num = 1000 + Integer.parseInt(bitSequence.substring(5, 8));
        for (int x = 0; x <= 3; x++) {
            if (// if the bit value is 0, neglect it//
            Integer.toString(num).charAt(x) == '1') {
                // calculate the significand//
                flt += (float) Math.pow(2, -x);
            }
        }
        // the exponent//
        for (int x = 1; x <= 4; x++) {
            // the second to the fifth bit of the bitSequence//
            if (// if the bit value is 0, neglect it//
            bitSequence.charAt(x) == '1') {
                // significand times exponent//
                flt *= (float) Math.pow(2, Math.pow(2, 4 - x));
            }
        }
        // if 1 is the first bit, the miniFloat value is negative; and 0 for positive value//
        if (bitSequence.charAt(0) == '1') {
            return (float) -flt;
        }
        return (float) flt;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] bitSequence = getValidMiniFloatBitSequences();
        for (int x = 0; x < 256; x++) {
            if (miniFloatFromString(bitSequence[x]) == (int) miniFloatFromString(bitSequence[x])) {
                System.out.println(bitSequence[x] + " = " + (int) miniFloatFromString(bitSequence[x]));
            }
        }
        return 0;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
