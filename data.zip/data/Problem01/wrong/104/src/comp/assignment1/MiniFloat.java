package comp.assignment1;

import java.util.Scanner;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    String bitSequence;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        Float a = Float.valueOf(bitSequence).floatValue();
        System.out.println(a);
        return 0;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        Scanner sequence = new Scanner(System.in);
        System.out.println("Please enter the miniFloat value with bit sequence");
        String seq = sequence.nextLine();
        char char1 = seq.charAt(0);
        int a;
        if (char1 == '0') {
            a = 1;
        } else {
            a = -1;
        }
        int b = seq.length();
        double c = 0;
        for (int i = 1; i <= 4; i++) {
            if (seq.charAt(i) == '1') {
                c += Math.pow(2, (4 - i));
            }
        }
        double d = 0;
        for (int i = 5; i <= 7; i++) {
            if (seq.charAt(i) == '1') {
                d += Math.pow(2, -(i - 5 + 1));
            }
        }
        d += 1;
        double Final = a * d * (Math.pow(2, c));
        int FinalFinal = (int) Final;
        System.out.println(FinalFinal);
        return 0;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
