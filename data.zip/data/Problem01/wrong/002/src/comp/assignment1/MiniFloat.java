package comp.assignment1;

public class MiniFloat {

    public static void main(String[] args) {
        // printIntegralMiniFloats();
        // String[] a=getValidMiniFloatBitSequences();
        float b = miniFloatFromString("00100110");
        System.out.println(b);
        int number = numIntegralMiniFloats();
        System.out.println(number);
    }

    public static float miniFloatFromString(String bitSequence) {
        String strExponent = bitSequence.substring(1, 5);
        String strSignificand = bitSequence.substring(5);
        int exponent = 0;
        for (int i = 0; i < 4; i++) {
            if (strExponent.charAt(i) == '1') {
                exponent += Math.pow(2, 3 - i);
            }
        }
        double significand = 0;
        for (int i = 0; i < 3; i++) {
            if (strSignificand.charAt(i) == '1') {
                significand += Math.pow(2, -1 - i);
            }
        }
        double minifloat = (1 + significand) * Math.pow(2, exponent);
        return (float) (bitSequence.startsWith("0") ? minifloat : (-1.0 * minifloat));
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            if (miniFloatFromString(s) % 1 == 0) {
                count++;
            }
        }
        return count;
    }

    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
