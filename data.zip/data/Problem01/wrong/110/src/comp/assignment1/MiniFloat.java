package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // get the sign of miniFloat
        int sign = bitSequence.codePointAt(0) - 48;
        int exponent1 = bitSequence.codePointAt(1) - 48;
        int exponent2 = bitSequence.codePointAt(2) - 48;
        int exponent3 = bitSequence.codePointAt(3) - 48;
        int exponent4 = bitSequence.codePointAt(4) - 48;
        int significand1 = bitSequence.codePointAt(5) - 48;
        int significand2 = bitSequence.codePointAt(6) - 48;
        int significand3 = bitSequence.codePointAt(7) - 48;
        // calculate exponent
        int exponent = exponent1 * 8 + exponent2 * 4 + exponent3 * 2 + exponent4;
        // calculate significand
        double significand = 1.0 + significand1 * 0.5 + significand2 * 0.25 + significand3 * 0.125;
        float result;
        if (sign == 0) {
            // positive
            result = (float) (significand * Math.pow(2, exponent));
        } else {
            // negative
            result = (float) (0 - (significand * Math.pow(2, exponent)));
        }
        return result;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] allCases = getValidMiniFloatBitSequences();
        // the number of all integral miniFloat values
        int number = 0;
        for (int i = 0; i < 256; i++) {
            // decimal number
            float value1 = miniFloatFromString(allCases[i]);
            int value2 = (int) value1;
            if (value1 == value2) {
                // miniFloat is an integral value
                number += 1;
            }
        }
        return number;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
