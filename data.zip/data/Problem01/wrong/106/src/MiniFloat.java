public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int sign = bitSequence.charAt(0) - 48;
        int exp = 0;
        double mantissa = 0;
        double significant;
        float whole_value;
        for (int i = 4; i > 0; i--) {
            int a = bitSequence.charAt(i) - 48;
            exp = exp + a * (int) (Math.pow(2, (4 - i)));
        }
        for (int i = 5; i < 8; i++) {
            int b = bitSequence.charAt(i) - 48;
            mantissa = mantissa + b * (Math.pow(2, (4 - i)));
        }
        significant = 1 + mantissa;
        if (sign == 0) {
            whole_value = (float) (significant * (Math.pow(2, exp)));
        } else {
            whole_value = (float) ((significant * (Math.pow(2, exp))) * (-1));
        }
        return whole_value;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int n = 0;
        for (int i = 0; i < 256; i++) {
            if (miniFloatFromString(getValidMiniFloatBitSequences()[i]) % 1 == 0) {
                n = n + 1;
            }
        }
        return n;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
