public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloat = 0;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // System.out.println(bitSequence);              //for checking variable
        boolean positive = false;
        int pow = 3;
        float exp = 0, sign = 1;
        for (int i = 0; i < bitSequence.length(); i++) {
            if (i == 0) {
                if (// check the first bit is positive or negative
                bitSequence.charAt(0) == '0') {
                    positive = true;
                }
            } else {
                if (i >= 1 && i <= 4) {
                    // calculate the exponent in second to fourth bit
                    if (bitSequence.charAt(i) == '1') {
                        exp += Math.pow(2, pow);
                    }
                    pow--;
                } else {
                    if (bitSequence.charAt(i) == '1') {
                        // calculate the significand in last three bit
                        sign += Math.pow(2, pow);
                    }
                    pow--;
                }
            }
        }
        /*
        System.out.println(positive);       //for checking variables
        System.out.println(exp);
        System.out.println(sign);
        */
        if (positive) {
            // determent the sign by variable (positive)
            miniFloat = (float) (sign * Math.pow(2, exp));
        } else {
            miniFloat = (float) (0 - (sign * Math.pow(2, exp)));
        }
        // System.out.println(miniFloat);       //for checking variable
        return miniFloat;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        return (int) miniFloat;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
