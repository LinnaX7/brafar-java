package comp.assignment1;

public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float minifloats;
        int sign = Integer.parseInt(bitSequence.charAt(0) + "");
        int exponent = Integer.parseInt(bitSequence.charAt(1) + "") * 8 + Integer.parseInt(bitSequence.charAt(2) + "") * 4 + Integer.parseInt(bitSequence.charAt(3) + "") * 2 + Integer.parseInt(bitSequence.charAt(4) + "");
        // System.out.println(exponent);
        double significant = 1 + Integer.parseInt(bitSequence.charAt(5) + "") * Math.pow(2, -1) + Integer.parseInt(bitSequence.charAt(6) + "") * Math.pow(2, -2) + Integer.parseInt(bitSequence.charAt(7) + "") * Math.pow(2, -3);
        // System.out.println(significant);
        minifloats = (float) (significant * Math.pow(2, exponent));
        if (sign == 1) {
            minifloats = -minifloats;
        }
        return minifloats;
    }

    public static float printIntegralMiniFloats() {
        // System.out.println(11111);
        String inputStr = "00100110";
        System.out.println(miniFloatFromString(inputStr));
        return 0;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            float judgeInt = miniFloatFromString(s);
            int judgeInt_ = (int) judgeInt;
            if ((float) judgeInt_ == judgeInt)
                count++;
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
