package comp.assignment1;

public class MiniFloat {

    public static float miniFloatFromString(String bitSequence) {
        int sum = 0;
        int decimalNo = 0;
        int power = 0;
        for (int i = 0; i < bitSequence.length(); i++) {
            /*here we check the whole String and do some maths in order to make it decimal*/
            sum = sum * 10;
            sum = sum + (int) bitSequence.charAt(i) - (int) '0';
        }
        while (sum != 0) {
            int rem = sum % 10;
            decimalNo = decimalNo + (int) (rem * Math.pow(2, power));
            power++;
            sum = sum / 10;
        }
        float average = (float) (decimalNo);
        return average;
        /* here we finally print and return the float value*/
    }
}
