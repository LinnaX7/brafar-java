public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        String signBit = bitSequence.substring(0, 1);
        String exponentBit = bitSequence.substring(1, 5);
        String mantissaBit = bitSequence.substring(5, 8);
        float exponent = new Float(0);
        exponent = Integer.parseInt(exponentBit, 2);
        // find significand
        String[] mantissa = mantissaBit.split("");
        float significand = new Float(0);
        for (int i = 0; i < 3; i++) {
            int intMantissa = Integer.parseInt(mantissa[i]);
            // System.out.println(intMantissa);
            significand += intMantissa * Math.pow(2, -i - 1);
        }
        significand += 1;
        // find miniFloat
        float miniFloat = new Float(0);
        if (signBit.equals("1")) {
            miniFloat = (float) (significand * Math.pow(2, exponent) * -1);
        } else {
            miniFloat = (float) (significand * Math.pow(2, exponent));
        }
        return miniFloat;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int number = 0;
        String[] getValidMiniFloatBitSequences = getValidMiniFloatBitSequences();
        for (int i = 0; i < 256; i++) {
            float miniFloatFromString = miniFloatFromString(getValidMiniFloatBitSequences[i]);
            if (miniFloatFromString != 0 && miniFloatFromString == (int) (miniFloatFromString)) {
                System.out.println(getValidMiniFloatBitSequences[i] + ',' + miniFloatFromString);
                number += 1;
            }
        }
        System.out.println(" The number of all integral miniFloat values is " + number);
        return number;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
