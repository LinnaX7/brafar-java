package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence"
        // Assign sign to +1
        int sign = 1;
        // if first character is 1, then make sign -1
        if (bitSequence.charAt(0) == '1') {
            sign = -1;
        }
        // assign exponent to 0
        int exponent = 0;
        // iterate through all 4 bits of exponent from index 1-4]
        for (int i = 1; i < 5; i++) {
            // if char at index = 1, increase exponent by 2^(i-1)
            if (bitSequence.charAt(i) == '1') {
                exponent += Math.pow(2, 4 - i);
            }
        }
        // assign mantissa to 1
        float mantissa = 1;
        // iterate through all 4 bits of mantissa from index 1-4]
        for (int i = 5; i < 8; i++) {
            // if char at index = 1, increase mantissa by 2^((i-4)*-1)
            if (bitSequence.charAt(i) == '1') {
                mantissa += Math.pow(2, (i - 4) * -1);
            }
        }
        // return the answer as float
        return (float) (sign * mantissa * Math.pow(2, exponent));
    }

    public static int numIntegralMiniFloats() {
        String[] values = getValidMiniFloatBitSequences();
        int count = 0;
        float temp;
        for (int i = 0; i < Math.pow(2, MINI_FLOAT_SIZE); i++) {
            temp = miniFloatFromString(values[i]);
            if ((temp - 48) == (int) temp) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
