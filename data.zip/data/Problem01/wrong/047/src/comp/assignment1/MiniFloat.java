package comp.assignment1;

public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    private static void printIntegralMiniFloats() {
        for (String s : getValidMiniFloatBitSequences()) {
            float check = miniFloatFromString(s);
            if (check == Math.ceil(check)) {
                System.out.println(check);
            }
        }
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        String strExpo = bitSequence.substring(1, 5);
        int intExpo = Integer.parseInt(strExpo, 2);
        String strSign = bitSequence.substring(5, 8);
        float sign = 0;
        for (int i = 0; i < 3; i++) {
            float intSign = Integer.parseInt(Character.toString(strSign.charAt(i)));
            sign += intSign * Math.pow(2, (-1 - i));
        }
        sign++;
        if (bitSequence.charAt(0) == '0') {
            return (float) (sign * Math.pow(2, intExpo));
        }
        return (float) (-1 * sign * Math.pow(2, intExpo));
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            float check = miniFloatFromString(s);
            if (check == Math.ceil(check)) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int MINI_FLOAT_SIZE = 8;
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static final int MINI_FLOAT_SIZE = 8;
}
