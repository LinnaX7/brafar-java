package comp.assignment1;

public class MiniFloat {

    /*
    public static void main(String[] args){
        printIntegralMiniFloats();
    }
    */
    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int[] s = new int[8];
        for (int i = 0; i < 8; i++) {
            s[i] = (int) bitSequence.charAt(i) - 48;
        }
        float ans = s[0] == 0 ? 1 : -1;
        ans *= Math.pow(2, (s[1] == '0' ? -8 : 0) + s[2] * 4 + s[3] * 2 + s[4]);
        ans *= 1 + s[5] * 0.5 + s[6] * 0.25 + s[7] * 0.125;
        return ans;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            float a = miniFloatFromString(s);
            if (Math.abs(a - Math.round(a)) < 1e-15) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
