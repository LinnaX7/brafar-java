package comp.assignment1;

public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        if (!(bitSequence.isEmpty() || bitSequence == null) && bitSequence.length() == 8) {
            boolean sign = bitSequence.charAt(0) == '0';
            String exponent_String = bitSequence.substring(1, 5);
            float exponent = Integer.parseInt(exponent_String, 2);
            String mantissa_String = bitSequence.substring(5, 8);
            float mantissa = 0;
            for (int i = 0; i < mantissa_String.length(); i++) {
                char temp = mantissa_String.charAt(i);
                if (temp == '1') {
                    mantissa += Math.pow(2, -(i + 1));
                } else {
                    mantissa += 0;
                }
            }
            float result = (float) Math.pow(2, exponent) * (1 + mantissa);
            return sign ? result : -1 * result;
        }
        return 0;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            float temp = miniFloatFromString(s);
            if (temp % 1 == 0) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
