public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // Task 1: compute the miniFloat value from "bitSequence";
        // transform the string array into int array
        int[] intValue = new int[8];
        for (int i = 0; i < 8; i++) {
            // Unicode 48 represents integer 0
            if (bitSequence.charAt(i) == 48) {
                intValue[i] = 0;
            } else {
                // Unicode 49 represents integer 1
                if (bitSequence.charAt(i) == 49) {
                    intValue[i] = 1;
                }
            }
        }
        // s is the sign value
        int s = intValue[0];
        // exp is exponent
        float exp = 0;
        for (int i = 1; i < 5; i++) {
            // the index of intValue is different from 2's exponent value
            // index~2's exponent: 1~3,2~2,3~1,4~0, so 2's exponent is absolute value of index-4;
            exp = exp + intValue[i] * (float) Math.pow(2, 4 - i);
        }
        float mantissa = 0;
        for (int i = 5; i < 8; i++) {
            // the index of intValue is different from 2's exponent value
            // index~2's exponent: 5~-1, 6~-2, 7~-3,so 2's exponent is absolute value of 4-index
            mantissa = mantissa + (intValue[i] * (float) Math.pow(2, 4 - i));
        }
        // fractional part is mantissa+1
        float frac = mantissa + 1;
        /*
         when s=0, the result is positive; s=1, the result is negative
         so the reult=(-1)^sign * fraction * 2^(exponent)
         */
        float result;
        if (s == 0) {
            result = (frac) * (float) Math.pow(2, exp);
        } else {
            result = -(frac) * (float) Math.pow(2, exp);
        }
        return result;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] miniFloatValues = getValidMiniFloatBitSequences();
        int len = miniFloatValues.length;
        int num = 0;
        for (int i = 0; i < len; i++) {
            float miniFloatResult = miniFloatFromString(miniFloatValues[i]);
            // test whether miniFloatResult is an integer
            int intminiFloatResult = (int) miniFloatResult;
            if (miniFloatResult - intminiFloatResult == 0) {
                num = num + 1;
            }
        }
        return num;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
