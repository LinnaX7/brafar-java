package comp.assignment1;

public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int sign = bitSequence.charAt(0) - '0';
        if (// first bit of the string determined positive or negative
        sign == 0) {
            sign = 1;
        } else {
            sign = -1;
        }
        String mantissa = bitSequence.substring(5, 8);
        String exponent = bitSequence.substring(1, 5);
        int dec_exponent = Integer.parseInt(exponent, 2);
        int signE = bitSequence.charAt(1) - '0';
        if (// the two's complement of exponent, pay attention to positive or negative exponent
        signE == 1) {
            dec_exponent = 1 - dec_exponent;
        }
        float dec_mantissa = bstr_to_dfloat(mantissa);
        float value = (float) (sign * dec_mantissa * Math.pow(2, dec_exponent));
        return value;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            float value = miniFloatFromString(s);
            if (value % 1 == 0) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    public static float bstr_to_dfloat(String bstr) {
        // convert the binary string into decimal float
        float dfloat = 0.0F;
        for (int i = 1; i < 4; i++) {
            char c = bstr.charAt(i - 1);
            int bit = c - '0';
            dfloat += Math.pow(2, -i) * bit;
        }
        return 1 + dfloat;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
