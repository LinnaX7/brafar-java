package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float MiniFloat = 0;
        int sign = 1;
        int exp = 0;
        float mantissa = 1;
        if (bitSequence.charAt(0) == '1') {
            sign = -1;
        }
        if (bitSequence.charAt(2) == '1') {
            exp += 4;
        }
        if (bitSequence.charAt(3) == '1') {
            exp += 2;
        }
        if (bitSequence.charAt(4) == '1') {
            exp += 1;
        }
        if (bitSequence.charAt(1) == '1') {
            exp = -(8 - exp);
        }
        if (bitSequence.charAt(5) == '1') {
            mantissa += 0.5;
        }
        if (bitSequence.charAt(6) == '1') {
            mantissa += 0.25;
        }
        if (bitSequence.charAt(7) == '1') {
            mantissa += 0.125;
        }
        MiniFloat = sign * mantissa;
        if (exp >= 0) {
            for (int i = 0; i < exp; i++) {
                MiniFloat = 2 * MiniFloat;
            }
        } else {
            for (int i = 0; i < -exp; i++) {
                MiniFloat = MiniFloat / 2;
            }
        }
        System.out.println(MiniFloat);
        return MiniFloat;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int num = 0;
        for (int i = 0; i < 256; i++) {
            int value = 1 << 8 | i;
            String res = Integer.toBinaryString(value);
            if (miniFloatFromString(res.substring(1)) % 1 == 0) {
                num += 1;
            }
        }
        return num;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
