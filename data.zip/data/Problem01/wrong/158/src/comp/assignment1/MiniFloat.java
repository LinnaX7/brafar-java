package comp.assignment1;

import javax.print.DocFlavor;
import java.util.Scanner;

public class MiniFloat {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.printf("Please input a string: ");
        String str = input.nextLine();
        // first function
        double i = miniFloatFromString(str);
        System.out.println("The value: " + i);
        input.close();
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        String s = bitSequence;
        int exptotal = 0;
        int count = 3;
        for (int i = 1; i <= 4; i++) {
            // first 4 digits
            char chartemp;
            chartemp = s.charAt(i);
            int inttemp = chartemp;
            inttemp = (inttemp - 48);
            exptotal = exptotal + inttemp * (2 * count);
            count = count - 1;
            // total = total * 10 + ((int)s.charAt(i) - 48);
            // total = (total*10) + (inttemp - 48);
        }
        double mtstotal = 0;
        int cunt = 4;
        for (int i = 5; i <= 7; i++) {
            // last 3 digits
            char chartemp = s.charAt(i);
            int inttemp = chartemp;
            inttemp = (inttemp - 48);
            mtstotal = mtstotal + inttemp * (2 * (1.0 / (cunt)));
            cunt = cunt + cunt;
        }
        mtstotal++;
        int sum = 1;
        for (int i = 1; i <= exptotal; i++) {
            // for significand value
            sum = sum * 2;
        }
        // calculating
        double finalsum = mtstotal * sum;
        if (s.charAt(0) == '1') {
            // first digit
            finalsum = finalsum * (-1);
        } else {
            finalsum = finalsum * (1);
        }
        return (float) finalsum;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            double i = miniFloatFromString(s);
            double sum = i % 1;
            if (sum > 0 || sum < 0) {
                // it is not integral
            } else {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
