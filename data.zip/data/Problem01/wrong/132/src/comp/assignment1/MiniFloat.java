package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        char sign = bitSequence.charAt(0);
        int s;
        if (sign == '0') {
            s = 1;
        } else {
            s = -1;
        }
        String exponent = bitSequence.substring(1, 5);
        String mantissa = bitSequence.substring(5, 8);
        int exp = Integer.valueOf(exponent, 2);
        float man = 1;
        for (int i = 0; i < 3; i++) {
            char m = mantissa.charAt(i);
            if (m == '1') {
                man = man + (float) Math.pow(0.5, i + 1);
            }
        }
        return man * (int) Math.pow(2, exp) * s;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] data = getValidMiniFloatBitSequences();
        int numIntegral = 0;
        for (int i = 0; i < data.length; i++) {
            float n = miniFloatFromString(data[i]);
            if (n == (int) n) {
                numIntegral = numIntegral + 1;
            }
        }
        return numIntegral;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
