public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        char[] bit = bitSequence.toCharArray();
        int sign = 1;
        if (bit[0] == '1') {
            sign = -1;
        }
        int exp = 0;
        for (int i = 1; i < 5; i++) {
            if (bit[i] == '1') {
                exp += (int) Math.pow(2, (4 - i));
            }
        }
        float mantissa = 1;
        for (int i = 5; i < 8; i++) {
            if (bit[i] == '1') {
                mantissa += (double) Math.pow(2, (4 - i));
            }
        }
        float ans = sign * mantissa * (int) Math.pow(2, exp);
        return ans;
    }

    public static int numIntegralMiniFloats(String bitSequence) {
        char[] bit = bitSequence.toCharArray();
        int sign = 1;
        if (bit[0] == '1') {
            sign = -1;
        }
        int exp = 0;
        for (int i = 1; i < 5; i++) {
            if (bit[i] == '1') {
                exp += (int) Math.pow(2, (4 - i));
            }
        }
        float mantissa = 1;
        for (int i = 5; i < 8; i++) {
            if (bit[i] == '1') {
                mantissa += (double) Math.pow(2, (4 - i));
            }
        }
        float ans = sign * mantissa * (int) Math.pow(2, exp);
        return (int) ans;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
