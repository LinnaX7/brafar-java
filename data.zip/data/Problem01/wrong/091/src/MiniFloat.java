public class MiniFloat {

    public static void main(String[] args) {
        printIntegralMiniFloats();
    }

    public static void printIntegralMiniFloats() {
        for (String s : getValidMiniFloatBitSequences()) // print out the integral miniFloats
        if (miniFloatFromString(s) - Math.floor(miniFloatFromString(s)) == 0)
            System.out.println(s + "=" + miniFloatFromString(s));
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // calculate sign, exponent, mantissa
        int sign = 1;
        if (bitSequence.charAt(0) == '1') {
            sign = -1;
        }
        int exponent = 0;
        for (int a = 1, b = 3; a <= 4; a++, b--) {
            exponent += Character.getNumericValue(bitSequence.charAt(a)) * Math.pow(2, b);
        }
        float mantissa = 1;
        for (int a = 5, b = -1; a <= 7; a++, b--) {
            mantissa += Character.getNumericValue(bitSequence.charAt(a)) * Math.pow(2, b);
        }
        // returns the value of the miniFloat as a float value
        return (float) (sign * mantissa * Math.pow(2, exponent));
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) if (miniFloatFromString(s) - Math.floor(miniFloatFromString(s)) == 0)
            count++;
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
