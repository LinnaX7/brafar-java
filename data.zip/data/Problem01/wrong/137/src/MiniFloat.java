public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // Store each bit in an array
        int[] eachBit = new int[8];
        for (int i = 0; i < 8; i++) {
            eachBit[i] = (int) bitSequence.charAt(i) - (int) '0';
        }
        // To find out it is a positive number or negative
        int signBit = 0;
        if (eachBit[0] == 1) {
            signBit = -1;
        } else {
            signBit = 1;
        }
        // To find out the mantissa
        float mantissa = 1;
        // Use for loop to simplify the mantissa+=1+eachBit[5]*Math.pow(2,-1)+eachBit[6]*Math.pow(2,-2)+eachBit[7]*Math.pow(2,-3)
        for (int i = 5; i < 8; i++) {
            mantissa += eachBit[i] * Math.pow(2, 4 - i);
        }
        // To find out the exponential bit
        float exBit = 0;
        // Use for loop to simplify the exBit+=eachBit[4]*Math.pow(2,0)+eachBit[3]*Math.pow(2,1)+eachBit[2]*Math.pow(2,2)+eachBit[1]*Math.pow(2,3)
        for (int i = 1; i < 5; i++) {
            exBit += eachBit[i] * Math.pow(2, 4 - i);
        }
        // To find out the final answer
        double answer = 0;
        answer = signBit * mantissa * Math.pow(2, exBit);
        answer = (int) answer;
        // translate the answer to the float
        // need to return float data the double is not accepted
        float realNumber = (float) answer;
        return realNumber;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] totalNum = new String[256];
        totalNum = getValidMiniFloatBitSequences();
        System.out.println(totalNum);
        int counter = 0;
        int numberLength = totalNum.length;
        // translate the string to float which is able to judge whether it is an integer
        for (int i = 0; i < numberLength; i++) {
            float legalNum = miniFloatFromString(totalNum[i]);
            // check whether it is an integer
            int numInt = (int) legalNum;
            // if not counter++
            if (legalNum > numInt) {
                counter++;
            }
        }
        int finalCounter = 256 - counter;
        return finalCounter;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
