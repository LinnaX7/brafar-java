package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float mantissa = 1;
        int exponent = 0;
        int sign;
        float result;
        int[] a = StringTointArray(bitSequence);
        for (int i = 5; i < 8; i++) {
            mantissa += a[i] * (float) Math.pow(2, (i - 4) * -1);
        }
        for (int i = 4; i > 0; i--) {
            exponent += a[i] * (int) Math.pow(2, (i - 4) * -1);
        }
        if (a[0] == 0) {
            sign = 1;
        } else {
            sign = -1;
        }
        result = sign * (float) Math.pow(2, exponent) * mantissa;
        return result;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int count = 0;
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = getValidMiniFloatBitSequences();
        for (int i = 0; i < nbrValues; i++) {
            if (miniFloatFromString(result[i]) % 1.0 == 0.0)
                count++;
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int[] StringTointArray(String n) {
        int[] num = new int[n.length()];
        for (int i = 0; i < n.length(); i++) {
            num[i] = n.charAt(i) - '0';
        }
        return num;
    }
}
