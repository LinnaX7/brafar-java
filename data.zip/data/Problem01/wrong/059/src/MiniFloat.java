public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float minifloat = 1, valofexponent = 0, mantissa = 1, count = 0, temp = 1;
        if (bitSequence.charAt(0) == '1') {
            minifloat *= -1;
        }
        for (int i = 4; i > 0; i--) {
            temp = 1;
            if (bitSequence.charAt(i) == '1') {
                for (int n = 0; n < count; n++) {
                    temp *= 2;
                }
                valofexponent += temp;
            }
            count++;
        }
        temp = 1;
        for (int k = 0; k < valofexponent; k++) {
            temp *= 2;
        }
        minifloat *= temp;
        count = 3;
        for (int u = 7; u > 4; u--) {
            temp = 1;
            if (bitSequence.charAt(u) == '1') {
                for (int i = 0; i < count; i++) {
                    temp *= 0.5;
                }
                mantissa += temp;
            }
            count--;
        }
        minifloat *= mantissa;
        return minifloat;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            float a = miniFloatFromString(s);
            if (a - (int) miniFloatFromString(s) == 0) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
