public class MiniFloat {

    public static float miniFloatFromString(String bitSequence) {
        int i;
        int sum = 0;
        float sum1 = 0;
        String exp = bitSequence.substring(1, 5);
        String man = bitSequence.substring(5, 8);
        int a = Integer.parseInt(exp);
        int b = Integer.parseInt(man);
        for (i = 0; i < exp.length(); i++) {
            if (a % 10 == 1) {
                sum = sum + (int) Math.pow(2, i);
            }
            a = a / 10;
        }
        for (i = 0; i < man.length(); i++) {
            if (b % 10 == 1) {
                sum1 = sum1 + (float) Math.pow(0.5, 3 - i);
            }
            b = b / 10;
        }
        sum1 = sum1 + 1;
        return sum1 * ((int) Math.pow(2, sum));
    }
}
