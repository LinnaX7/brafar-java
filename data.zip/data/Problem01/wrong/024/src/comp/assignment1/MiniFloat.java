package comp.assignment1;

import java.util.Scanner;

public class MiniFloat {

    public static void main(String[] args) {
        // Enter an 8-bit bitSequence.
        System.out.println("Please enter an 8-bit number: ");
        Scanner input = new Scanner(System.in);
        String bitSequence = input.nextLine();
        System.out.println("The converted result is: " + miniFloatFromString(bitSequence));
        numIntegralMiniFloats();
    }

    public static float miniFloatFromString(String bitSequence) {
        // Ensure the bitSequence is legal
        while (bitSequence.length() != 8) {
            System.out.println("Please enter a correct 8-bit number: ");
        }
        for (int i = 0; i < 8; i++) {
            if (bitSequence.charAt(i) != '1' && bitSequence.charAt(i) != '0') {
                System.out.println("Please enter a correct 8-bit number: ");
            }
        }
        // convert the bitSequence to number
        boolean sign;
        int Exp = 0;
        float flo = 0;
        if (bitSequence.charAt(0) == '0') {
            sign = false;
        } else {
            sign = true;
        }
        for (int j = 1; j < 5; j++) {
            if (j == 1 && bitSequence.charAt(j) == '1') {
                Exp += 1;
            } else {
                if (j == 2 && bitSequence.charAt(j) == '1') {
                    Exp += 2;
                } else {
                    if (j == 3 && bitSequence.charAt(j) == '1') {
                        Exp += 4;
                    } else {
                        if (j == 4 && bitSequence.charAt(j) == '1') {
                            Exp += 8;
                        } else {
                            Exp += 0;
                        }
                    }
                }
            }
        }
        for (int k = 5; k < 8; k++) {
            if (k == 5 && bitSequence.charAt(k) == '1') {
                flo += 0.5;
            } else {
                if (k == 6 && bitSequence.charAt(k) == '1') {
                    flo += 0.25;
                } else {
                    if (k == 7 && bitSequence.charAt(k) == '1') {
                        flo += 0.125;
                    } else {
                        flo += 0;
                    }
                }
            }
        }
        float num = 0;
        if (!sign) {
            num = (2 ^ Exp) * flo;
        } else {
            if (sign) {
                num = (2 ^ Exp) * flo;
            }
        }
        // Task 1: compute the miniFloat value from "bitSequence";
        return num;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            double s1 = miniFloatFromString(s);
            if ((int) s1 == s1) {
                count += 1;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
