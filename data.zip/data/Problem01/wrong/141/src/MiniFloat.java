public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static void main(String[] args) {
        numIntegralMiniFloats();
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float num = 0.0f;
        char[] ch = new char[bitSequence.length()];
        for (int i = 0; i < bitSequence.length(); i++) {
            ch[i] = bitSequence.charAt(i);
        }
        /*System.out.print("Bit sequence: ");
        for (char c : ch) {
            System.out.print(c);
        }

         */
        // Calculate the exponent.
        int exponent = 0;
        int power = 0;
        for (int i = 4; i >= 1; i--) {
            exponent += Math.pow(2, 4 - i) * ((int) ch[i] - 48);
        }
        // System.out.println("\nExponent: " + exponent);
        // Calculate the mantissa.
        float mantissa = 0.0f;
        float significand = 0.0f;
        for (int i = 5; i <= 7; i++) {
            mantissa += 1 / (Math.pow(2, i - 4)) * ((int) ch[i] - 48);
        }
        significand = mantissa + 1;
        // System.out.println("Mantissa: " + mantissa + "\nSignificand: " + significand);
        // Calculate the value.
        num = (float) (significand * Math.pow(2, exponent));
        // Determine whether the float is positive or negative.
        if (ch[0] == '1') {
            num = num * -1;
        }
        if (num < -240.0f || num > 240.0f) {
            return 0.0f;
        }
        return num;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] input = getValidMiniFloatBitSequences();
        float mini;
        int counter = 0;
        for (int i = 0; i <= 255; i++) {
            mini = miniFloatFromString(input[i]);
            if (mini % 1 == 0 && mini != 0) {
                // System.out.println((int) mini);
                counter++;
            }
        }
        System.out.println(counter);
        return counter;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
