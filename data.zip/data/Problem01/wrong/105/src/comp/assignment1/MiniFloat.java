package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float miniFloat;
        String exp = bitSequence.substring(1, 5);
        int a = 1;
        int exponent = 0;
        for (int i = 3; i >= 0; i--) {
            String Exp = exp.substring(i, i + 1);
            if (i == 3) {
                exponent = exponent + (1 * Integer.parseInt(Exp));
            } else {
                int pow = 1;
                for (int p = 0; p < a; p++) {
                    pow = pow * 2;
                }
                exponent = exponent + (pow * Integer.parseInt(Exp));
                a++;
            }
        }
        String M = bitSequence.substring(5);
        float b = 0.5f;
        float mantissa = 1;
        for (int i = 0; i < M.length(); i++) {
            String m = M.substring(i, i + 1);
            mantissa = mantissa + (b * Integer.parseInt(m));
            b = b / 2;
        }
        int e = 1;
        for (int i = 0; i < exponent; i++) {
            e = e * 2;
        }
        String s = bitSequence.substring(0, 1);
        int sign = Integer.parseInt(s);
        if (sign == 0) {
            miniFloat = e * mantissa;
        } else {
            miniFloat = e * mantissa;
            miniFloat = miniFloat * (-1);
        }
        return miniFloat;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] ValidMiniFloatBitSequences = getValidMiniFloatBitSequences();
        int size = ValidMiniFloatBitSequences.length;
        float a;
        int count = 0, b;
        for (int i = 0; i < size; i++) {
            a = miniFloatFromString(ValidMiniFloatBitSequences[i]);
            b = (int) a;
            if (a == b) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
