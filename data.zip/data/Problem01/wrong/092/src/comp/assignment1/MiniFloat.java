package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int e = 0;
        float s = 0;
        float result = 0;
        if (bitSequence.charAt(1) == '1') {
            e += 2 * 2 * 2;
        }
        if (bitSequence.charAt(2) == '1') {
            e += 2 * 2;
        }
        if (bitSequence.charAt(3) == '1') {
            e += 2;
        }
        if (bitSequence.charAt(4) == '1') {
            e += 1;
        }
        if (bitSequence.charAt(1) == '1' || bitSequence.charAt(2) == '1' || bitSequence.charAt(3) == '1' || bitSequence.charAt(4) == '1') {
            if (bitSequence.charAt(5) == '1') {
                s += 0.5f;
            }
            if (bitSequence.charAt(6) == '1') {
                s += 0.25f;
            }
            if (bitSequence.charAt(7) == '1') {
                s += 0.125f;
            }
            result += (1 + s) * Math.pow(2, e);
        } else {
            if (bitSequence.charAt(1) == '0' && bitSequence.charAt(2) == '0' && bitSequence.charAt(3) == '0' && bitSequence.charAt(4) == '0' && bitSequence.charAt(5) == '0' && bitSequence.charAt(6) == '0' && bitSequence.charAt(7) == '0') {
                result = (int) 1;
            } else {
                result += s * Math.pow(2, e);
            }
        }
        if (bitSequence.startsWith("1")) {
            System.out.println("-" + (int) result);
        } else {
            System.out.println((int) result);
        }
        return result;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] bS = getValidMiniFloatBitSequences();
        return (int) miniFloatFromString(bS[8]);
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
