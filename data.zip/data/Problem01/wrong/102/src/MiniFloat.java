public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        boolean sign = true;
        StringBuilder exp = new StringBuilder();
        StringBuilder man = new StringBuilder();
        float TenMantissa = 1;
        float TenExponent;
        // check the sign of the float
        char charAtZero = bitSequence.charAt(0);
        if (charAtZero != '0') {
            sign = false;
        }
        for (int i = 1; i < 5; i++) {
            // build a string of exponent
            char temp = bitSequence.charAt(i);
            exp.append(temp);
        }
        for (int i = 5; i < 8; i++) {
            // build a string of mantissa
            char temp = bitSequence.charAt(i);
            man.append(temp);
        }
        for (int i = 0; i < 3; i++) {
            // build a float of mantissa
            double temp = 1;
            if (man.charAt(i) == '1') {
                for (int j = 0; j <= i; j++) {
                    temp = temp * 0.5;
                }
                TenMantissa += temp;
            }
        }
        // build a float of exponent
        TenExponent = Integer.parseInt(exp.toString(), 2);
        /*
        System.out.println("sign is " + sign );
        System.out.println("mantissa is " + man + " ==> " + TenMantissa);
        System.out.println("Exponent is " + exp + " ==> " + TenExponent);
        */
        float answer = (float) (TenMantissa * Math.pow(2, TenExponent));
        if (!sign) {
            answer *= -1;
        }
        return answer;
    }

    /*
    public static int TotalValue(){
        String[] fin = getValidMiniFloatBitSequences();
        //System.out.println(Arrays.toString(fin));

        int length = fin.length;
        int counter = 0;

        for (int i = 0; i < length; i++){
            float temp = miniFloatFromString(fin[i]);
            counter += numIntegralMiniFloats(temp);
        }
        System.out.println("The number of all integral miniFloat values : " + counter);
        return counter;
    }
    */
    public static int numIntegralMiniFloats(float miniFloat) {
        // Task 2: return the number of integral miniFloat values
        // i am not sure the task needs me return the count number of integral float
        // or the the value of float if it is integer
        /*
        if (miniFloat % 1 == 0){
            return (int) miniFloat;
        }
        */
        String[] fin = getValidMiniFloatBitSequences();
        int length = fin.length;
        int numInteger = 0;
        for (int i = 0; i < length; i++) {
            float temp = miniFloatFromString(fin[i]);
            if (temp % 1 == 0) {
                numInteger++;
            }
        }
        System.out.println("The number of integral miniFloat values : " + numInteger);
        return numInteger;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
