package comp.assignment1;

public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
        System.out.println(miniFloatFromString("00100110"));
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // default value
        int sign_bit;
        String exp = "";
        String M = "";
        // check bit
        int exponent = 0;
        float mantissa = 0;
        if (bitSequence.charAt(0) == '1') {
            sign_bit = 1;
        } else {
            sign_bit = 0;
        }
        exp = bitSequence.substring(1, 5);
        M = bitSequence.substring(5);
        // positive exp case
        if (exp.charAt(0) == '0') {
            exponent = Integer.parseInt(exp, 2);
            // negative exp case
        } else {
            if (exp.charAt(0) == '1') {
                String temp = "";
                for (int i = 0; i < 4; i++) {
                    if (exp.charAt(i) == '1') {
                        temp += '0';
                    } else {
                        temp += '1';
                    }
                }
                exponent = (Integer.parseInt(exp, 2) + 1) * -1;
            }
        }
        // mantissa
        for (int j = 0; j < 3; j++) {
            if (M.charAt(j) == '1') {
                mantissa += 1 * Math.pow(2, -(j + 1));
            } else {
                mantissa += 0 * Math.pow(2, -(j + 1));
            }
        }
        // 1.mantissa x 2exponent
        float minifloat = (float) Math.pow(-1, sign_bit) * (1 + mantissa) * (float) Math.pow(2, exponent);
        return minifloat;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            if (miniFloatFromString(s) % 1 == 0) {
                count += 1;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
