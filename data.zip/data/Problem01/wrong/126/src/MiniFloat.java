public class MiniFloat {

    public static float DELTA = 1E-6f;

    public static void main(String[] args) {
    }

    public static float miniFloatFromString(String bitSequence) {
        int[] blk = new int[8];
        double ans, exp = 0, mantissa = 1;
        char[] chaRarr = bitSequence.toCharArray();
        for (int i = 0; i < 8; i++) {
            blk[i] = chaRarr[i] - '0';
        }
        if (blk[1] == 1) {
            exp = exp + 8;
        }
        if (blk[2] == 1) {
            exp = exp + 4;
        }
        if (blk[3] == 1) {
            exp = exp + 2;
        }
        if (blk[4] == 1) {
            exp = exp + 1;
        }
        if (blk[5] == 1) {
            mantissa += 0.5;
        }
        if (blk[6] == 1) {
            mantissa += 0.25;
        }
        if (blk[7] == 1) {
            mantissa += 0.125;
        }
        ans = mantissa * Math.pow(2, exp);
        if (blk[0] == 1) {
            ans = ans * (-1);
        }
        return (float) ans;
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        for (String s : getValidMiniFloatBitSequences()) {
            if (Math.abs((int) MiniFloat.miniFloatFromString(s) - miniFloatFromString(s)) < DELTA)
                count += 1;
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
