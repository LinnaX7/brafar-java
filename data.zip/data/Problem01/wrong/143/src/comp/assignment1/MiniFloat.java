package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int signNum = 0;
        String exponentNum = "";
        float significandNum = 1;
        float ans;
        // split bit sequence into array
        String[] intBit = bitSequence.split("");
        // get sign value
        if (Integer.parseInt(intBit[0]) == 0) {
            signNum = 1;
        } else {
            signNum = -1;
        }
        // get exponent part
        for (int i = 1; i < 5; i++) {
            exponentNum = exponentNum + intBit[i];
        }
        // get significand part
        if (Integer.parseInt(intBit[5]) == 1) {
            significandNum = (float) (significandNum + 0.5);
        }
        if (Integer.parseInt(intBit[6]) == 1) {
            significandNum = (float) (significandNum + 0.25);
        }
        if (Integer.parseInt(intBit[7]) == 1) {
            significandNum = (float) (significandNum + 0.125);
        }
        // convert exponentNum from bin to dec
        int exponentInt = Integer.parseInt(exponentNum, 2);
        // calculate answer
        ans = (float) (signNum * significandNum * Math.pow(2, exponentInt));
        return ans;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        // count the  number of all integral miniFloat values, miniFloat values that are integers.
        int count = 0;
        float temp;
        // get Valid MiniFloat BitSequences
        String[] validMiniFBS = getValidMiniFloatBitSequences();
        // loop to test all Valid MiniFloat BitSequences
        for (int i = 0; i < validMiniFBS.length; i++) {
            temp = miniFloatFromString(validMiniFBS[i]);
            // if is integer, print out and count
            if (temp == (int) temp) {
                System.out.println((int) temp);
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
