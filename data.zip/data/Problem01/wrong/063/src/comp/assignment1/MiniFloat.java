package comp.assignment1;

// import java.lang.Integer;
public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static void main(String[] args) {
        System.out.printf("\n");
        int numIntegrals = numIntegralMiniFloats();
        System.out.printf("\nNumber of integral miniFloat values: %d", numIntegrals);
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        float answer = 0;
        // System.out.println(bitSequence);
        // Calculate significand
        float significand = 1;
        int power = -1;
        for (int i = 5; i < 8; i++) {
            int bit = bitSequence.charAt(i);
            // System.out.println(bit - 48);
            significand += Math.pow(2, power) * (bit - 48);
            power--;
        }
        // System.out.printf("%f", significand);
        // Calculate exponent
        String exponentBinary = bitSequence.substring(1, 5);
        // System.out.printf("\nExp: %s\n", exponentBinary);
        String[] binValues = { "0000", "0001", "0010", "0011", "0100", "0111", "1000", "1001", "1010", "1011", "1100", "1101", "1100", "1101", "1110", "1111" };
        int exponent = -1;
        for (int i = 0; i < binValues.length; i++) {
            if (exponentBinary.equals(binValues[i])) {
                if (i > 7) {
                    exponent = i - 16;
                } else {
                    exponent = i;
                }
            }
        }
        int signBit = bitSequence.charAt(0);
        answer = (float) (significand * Math.pow(2, exponent));
        if (signBit == 49) {
            // If the sign bit is 1 (negative)
            answer *= -1;
        }
        return answer;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int integralCount = 0;
        String[] bitSequences = getValidMiniFloatBitSequences();
        for (String s : bitSequences) {
            float decimalValue = miniFloatFromString(s);
            if (decimalValue % 1 == 0) {
                System.out.println(s + "\t" + decimalValue);
                integralCount++;
            }
        }
        return integralCount;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        System.out.printf("RESULT: %s\n", result);
        return result;
    }
}
