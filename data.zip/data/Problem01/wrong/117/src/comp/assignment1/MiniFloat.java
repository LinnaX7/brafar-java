package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        char signBit_Binary = bitSequence.charAt(0);
        String Exponent_Binary = bitSequence.substring(1, 5);
        String Significand_Binary = bitSequence.substring(5, 8);
        int Exponent = 0;
        float Significand = 1;
        for (int i = 4; i > 0; i--) {
            Exponent += Character.getNumericValue(Exponent_Binary.charAt(i - 1)) * Math.pow(2, 4 - i);
        }
        for (int k = 0; k < 3; k++) {
            Significand += Character.getNumericValue(Significand_Binary.charAt(k)) * Math.pow(2, -k - 1);
        }
        // Float to decimal
        float result = Significand * (float) Math.pow(2, Exponent);
        if (signBit_Binary == '1') {
            result *= -1;
        }
        return result;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        int numIntegral = 0;
        String[] allValidSequence = getValidMiniFloatBitSequences();
        for (String s : allValidSequence) {
            float number = miniFloatFromString(s);
            if ((int) number == number)
                numIntegral++;
        }
        return numIntegral;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
