public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        char negative = bitSequence.charAt(0);
        float f = Float.parseFloat(bitSequence);
        if (negative == 1) {
            f *= -1;
        }
        return f;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] bitSequences = getValidMiniFloatBitSequences();
        // float mf = miniFloatFromString(bitSequences);
        String str = String.join("", bitSequences);
        char negative = str.charAt(0);
        char[] exp = new char[4];
        char[] sign = new char[3];
        for (int i = 0; i < 4; i++) {
            exp[i] = str.charAt(i + 1);
        }
        for (int i = 0; i < 3; i++) {
            sign[i] = str.charAt(i + 4);
        }
        if (negative == 1) {
            for (int j = 0; j < 3; j++) {
                if (exp[j] == '1') {
                    exp[j] = 0;
                } else {
                    exp[j] = 1;
                }
            }
        }
        int ex = 0;
        for (int i = 0; i < 3; i++) {
            if (exp[i] == '1')
                ex += Math.pow(2, (3 - i));
        }
        double s = 1;
        for (int i = 0; i < 2; i++) {
            if (sign[i] == 1)
                s += Math.pow(1 / 2, i);
        }
        double mf = ex * s;
        return (int) mf;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
