package comp.assignment1;

public class MiniFloat {

    public static void main(String[] args) {
        System.out.println(numIntegralMiniFloats());
    }

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // Get the sign bit
        int sign = 1;
        if (bitSequence.charAt(0) == '1') {
            sign = -1;
        }
        // Get the exponent part
        int exponent = 0;
        for (int i = 1; i <= 4; i++) {
            exponent += Math.pow(2, (4 - i)) * ((int) bitSequence.charAt(i) - 48);
        }
        // Get the significand
        float significandAfterZero = 0;
        for (int i = 5; i <= 7; i++) {
            significandAfterZero += Math.pow(2, (7 - i)) * ((int) bitSequence.charAt(i) - 48);
        }
        float significand = significandAfterZero / 8 + 1;
        // calculate the result
        return (float) (sign * significand * Math.pow(2, exponent));
    }

    public static int numIntegralMiniFloats() {
        int count = 0;
        // Task 2: return the number of integral miniFloat values
        for (String s : getValidMiniFloatBitSequences()) {
            float result = miniFloatFromString(s);
            if (result % 1 == 0) {
                count++;
            }
        }
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }

    private static int MINI_FLOAT_SIZE = 8;
}
