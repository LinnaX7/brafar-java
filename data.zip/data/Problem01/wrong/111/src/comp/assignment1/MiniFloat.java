package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        char[] search = bitSequence.toCharArray();
        boolean status = true;
        if (search[0] != '0') {
            status = false;
        }
        double exsum = 0;
        double cal = 0;
        int count = 4;
        if (search[1] == '0') {
            for (int v = 1; v <= 4; v++) {
                if (search[v] == '1') {
                    cal = Math.pow(2, count - 1);
                    exsum = exsum + cal;
                }
                count--;
            }
        } else {
            String taken = bitSequence.substring(1, 5);
            taken = taken.replace('0', 'p');
            taken = taken.replace('1', '0');
            taken = taken.replace('p', '1');
            exsum = Integer.parseInt(taken, 2);
            exsum++;
            exsum = -exsum;
        }
        float something = 0;
        float result = 0;
        if (search[5] == '1') {
            something = (float) (something + 0.5);
        }
        if (search[6] == '1') {
            something = (float) (something + 0.25);
        }
        if (search[7] == '1') {
            something = (float) (something + 0.125);
        }
        something = something + 1;
        result = (float) (something * Math.pow(2, exsum));
        if (status == false) {
            result = -result;
            System.out.println(bitSequence + " is " + result);
            return result;
        }
        if (status) {
            System.out.println(bitSequence + " is " + result);
            return result;
        }
        return 0;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] find = getValidMiniFloatBitSequences();
        int answer = 0;
        for (int f = 0; f < 256; f++) {
            float give = miniFloatFromString(find[f]);
            if (give == (int) give) {
                answer++;
            }
        }
        System.out.println("Total number of values = " + answer);
        return answer;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
