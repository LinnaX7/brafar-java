import static java.lang.Integer.parseInt;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        int sign = Integer.parseInt(bitSequence.substring(0, 1));
        int exponent = parseInt(bitSequence.substring(1, 5), 2);
        double mantissa = 1 + Integer.parseInt(bitSequence.substring(5, 6)) * Math.pow(2, -1) + Integer.parseInt(bitSequence.substring(6, 7)) * Math.pow(2, -2) + Integer.parseInt(bitSequence.substring(7, 8)) * Math.pow(2, -3);
        double totalVal = mantissa * Math.pow(2, exponent) * Math.pow(-1, sign);
        return (float) totalVal;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        String[] testValue = getValidMiniFloatBitSequences();
        int count = 0;
        for (int i = 0; i < testValue.length; i++) {
            if (miniFloatFromString(testValue[i]) % 1 == 0) {
                count++;
            }
        }
        System.out.print(count);
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
