package comp.assignment1;

public class MiniFloat {

    public static final int MINI_FLOAT_SIZE = 8;

    public static float miniFloatFromString(String bitSequence) {
        // Task 1: compute the miniFloat value from "bitSequence";
        // Checking the SIGN BIT
        boolean isSequencePositive = false;
        if (bitSequence.charAt(0) == '0') {
            isSequencePositive = true;
        } else {
            if (bitSequence.charAt(0) == '1') {
                isSequencePositive = false;
            }
        }
        // Evaluating the EXPONENT
        float exponent = 0;
        int binaryExponent = 3;
        for (int i = 1; i <= 4; i++) {
            char currentChar = bitSequence.charAt(i);
            int currentInt = currentChar - 48;
            exponent = (float) (exponent + (currentInt * Math.pow(2, binaryExponent)));
            binaryExponent--;
        }
        // Evaluating the MANTISSA/SIGNIFICAND
        float significand = 0;
        int binaryExponent2 = 0;
        // The structure of the mantissa is (1.*The last three bits of the sequence*) in binary form.
        // Upon converting to decimal, the first digit will always be 1*2^0.
        significand = (float) (significand + (1 * Math.pow(2, binaryExponent2)));
        binaryExponent2--;
        for (int i = 5; i <= 7; i++) {
            char currentChar = bitSequence.charAt(i);
            int currentInt = currentChar - 48;
            significand = (float) (significand + (currentInt * Math.pow(2, binaryExponent2)));
            binaryExponent2--;
        }
        // Evaluating the miniFloat
        float miniFloat = (float) (significand * Math.pow(2, exponent));
        // Add the positive/negative sign according to the evaluated sign bit
        if (isSequencePositive == true) {
            miniFloat = miniFloat * 1;
        } else {
            if (isSequencePositive == false) {
                miniFloat = miniFloat * -1;
            }
        }
        // System.out.println("miniFloat: " + miniFloat);
        return miniFloat;
    }

    public static int numIntegralMiniFloats() {
        // Task 2: return the number of integral miniFloat values
        // The debug logs are disabled.
        // System.out.println("The following are all the miniFloatsValues that is integral: ");
        String[] miniFloatsValues = getValidMiniFloatBitSequences();
        int count = 0;
        // For every miniFloatValues[i], evaluate the miniFloat equivalent then check if it's modulo divided by 1 is 0.
        // If it is 0, it implies it has no decimal places and is a decimal. A counter will then be incremented for every case.
        for (int i = 0; i < miniFloatsValues.length; i++) {
            if (miniFloatFromString(miniFloatsValues[i]) % 1 == 0) {
                count++;
                // System.out.println(miniFloatsValues[i] + " (which is the equivalent of "+ miniFloatFromString(miniFloatsValues[i]) + ")");
            }
        }
        System.out.println("Count: " + count);
        return count;
    }

    /**
     * Get all valid bit sequences for miniFloat values.
     */
    private static String[] getValidMiniFloatBitSequences() {
        int nbrValues = (int) Math.pow(2, MINI_FLOAT_SIZE);
        String[] result = new String[nbrValues];
        for (int i = 0; i < nbrValues; i++) {
            result[i] = String.format("%" + MINI_FLOAT_SIZE + "s", Integer.toBinaryString(i)).replace(' ', '0');
        }
        return result;
    }
}
